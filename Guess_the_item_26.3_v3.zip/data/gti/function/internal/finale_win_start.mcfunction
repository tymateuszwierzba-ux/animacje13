execute as @e[tag=gti.overlay.title,limit=1] run data modify entity @s text set value {"text":"TRAFIONE!","color":"#8BE28B","bold":true}
execute as @e[tag=gti.overlay.title,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:8,transformation:{scale:[2.7f,2.7f,2.7f],translation:[0f,0f,0f]}}
execute as @e[tag=gti.overlay.sub,limit=1] run data modify entity @s text set value {"text":"Świetna robota — zobacz podsumowanie","color":"#8FA8C8"}
execute as @e[tag=gti.overlay.sub,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:8,transformation:{scale:[0.9f,0.9f,0.9f],translation:[0f,0f,0f]}}
execute as @e[tag=gti.item,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:14,transformation:{scale:[21.6f,21.6f,0.001f],translation:[0f,0.4f,0f],left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f]}}
function gti:visual/halo
function gti:visual/confetti
execute as @a[tag=gti.player] at @s run playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 0.8 1.1
execute as @a[tag=gti.player] at @s run playsound minecraft:block.conduit.activate master @s ~ ~ ~ 0.6 1.5
