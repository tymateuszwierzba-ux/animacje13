execute if score #state gti.var matches 1 run function gti:internal/intro
execute if score #state gti.var matches 2 run function gti:internal/active
execute if score #state gti.var matches 3 run function gti:internal/finale
function gti:visual/tick
execute if score #clock gti.var matches 0 run function gti:internal/periodic
execute if score #ab_clock gti.var matches 0 run function gti:ui/actionbar
