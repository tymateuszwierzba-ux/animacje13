function gti:internal/hud
function gti:visual/bob
function gti:visual/pulse
execute if score #state gti.var matches 0..1 run function gti:visual/particles_idle
execute if score #idle_fx gti.var matches 1.. run function gti:internal/idle_fx
execute if score #idle_fx gti.var matches 1.. run scoreboard players remove #idle_fx gti.var 1
