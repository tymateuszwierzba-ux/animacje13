scoreboard players set #state gti.var 2
scoreboard players set #time gti.var 0
scoreboard players set #timer gti.var 0
function gti:visual/shutter_open_all
execute as @e[tag=gti.overlay.count,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:4,transformation:{scale:[0.01f,0.01f,0.01f],translation:[0f,0f,0f]}}
execute as @e[tag=gti.overlay.title,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:4,transformation:{scale:[0.01f,0.01f,0.01f],translation:[0f,0f,0f]}}
execute as @e[tag=gti.overlay.sub,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:4,transformation:{scale:[0.01f,0.01f,0.01f],translation:[0f,0f,0f]}}
title @a[tag=gti.player] times 4 30 10
title @a[tag=gti.player] subtitle {"text":"Odkrywaj piksele • zgaduj przedmiot z ręki","color":"gray"}
title @a[tag=gti.player] title {"text":"ZGADUJ!","color":"#8BE28B","bold":true}
execute as @a[tag=gti.player] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.7 1.5
execute if score #initial gti.var matches 1.. run function gti:internal/initial_reveal
data modify storage gti:tmp msg set value "Kliknij kafelek lub przycisk ODKRYJ."
function gti:visual/event with storage gti:tmp
tellraw @a[tag=gti.player] [{"text":"▶ Otwórz panel gry","color":"#45E9E0","bold":true,"click_event":{"action":"run_command","command":"trigger gti.play set 1"}},{"text":"   •   LPM/PPM na kafelku odsłania pobliskie pola","color":"gray"}]
function gti:internal/hud
