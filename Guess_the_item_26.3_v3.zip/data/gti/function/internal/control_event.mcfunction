execute if entity @s[tag=gti.control.reveal] on target run function gti:internal/pixel_request
execute if entity @s[tag=gti.control.guess] on target run function gti:internal/guess_request
execute if entity @s[tag=gti.control.hint] on target run function gti:internal/hint_request
execute if entity @s[tag=gti.control.pause] on target run function gti:ui/pause_click
execute if entity @s[tag=gti.control.menu] on target run function gti:ui/menu
execute if entity @s[tag=gti.control.menu] on target run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.6 1.2
data remove entity @s interaction
data remove entity @s attack
