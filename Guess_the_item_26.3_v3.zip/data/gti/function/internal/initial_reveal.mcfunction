scoreboard players set #free gti.var 1
execute store result storage gti:ctx batch int 1 run scoreboard players get #initial gti.var
execute at @e[tag=gti.anchor,limit=1] run function gti:internal/batch_random with storage gti:ctx
scoreboard players set #free gti.var 0
