$execute store result score #eq_guess gti.var run data get storage gti:items by_id."$(guess)" eq
execute if score #eq_answer gti.var matches 0.. if score #eq_guess gti.var = #eq_answer gti.var run scoreboard players set #same gti.var 1
