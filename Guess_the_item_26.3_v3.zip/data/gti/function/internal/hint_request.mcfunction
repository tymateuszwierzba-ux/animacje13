execute unless score #state gti.var matches 2 run return run tellraw @s {"text":"Podpowiedzi są dostępne w trakcie rundy.","color":"gray"}
execute if score #paused gti.var matches 1 run return run tellraw @s {"text":"Runda jest wstrzymana.","color":"yellow"}
execute if score #hints_enabled gti.var matches 0 run return run tellraw @s {"text":"Podpowiedzi są wyłączone w ustawieniach.","color":"yellow"}
execute if score #hint_stage gti.var matches 3.. run return run tellraw @s {"text":"Wykorzystano wszystkie 3 podpowiedzi w tej rundzie.","color":"yellow"}
scoreboard players add #hint_stage gti.var 1
scoreboard players add #hints_used gti.var 1
scoreboard players add #cost gti.var 8
function gti:internal/hint_text
title @s times 2 30 10
title @s subtitle {"text":"−8 punktów • podpowiedź","color":"gray"}
title @s title {"text":"PODPOWIEDŹ","color":"#F47BC6","bold":true}
execute at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 0.7 1.2
tellraw @s [{"text":"💡 ","color":"#F47BC6"},{"nbt":"hint","storage":"gti:cfg","color":"#F6CF84"}]
function gti:internal/hud
execute if score #limit gti.var matches 1.. if score #cost gti.var >= #limit gti.var run function gti:internal/lose
