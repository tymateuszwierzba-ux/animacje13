scoreboard players set #ten gti.var 10
scoreboard players set #twenty gti.var 20
scoreboard players set #sixty gti.var 60
scoreboard players set #eighty gti.var 80
scoreboard players set #hundred gti.var 100
scoreboard players set #thousand gti.var 1000
scoreboard players set #tenk gti.var 10000
scoreboard players set #two gti.var 2
scoreboard players set #three gti.var 3
scoreboard players set #twelve gti.var 12
scoreboard players set #eight gti.var 8
scoreboard players set #halo_max gti.var 36
scoreboard players set #maxpix gti.var 256
execute unless score #v3 gti.var matches 1 run function gti:internal/defaults
scoreboard players set #v3 gti.var 1
scoreboard players set #state gti.var 0
scoreboard players set #result gti.var 2
scoreboard players set #round gti.var 0
scoreboard players set #last_index gti.var -1
scoreboard players set #pixels gti.var 0
scoreboard players set #guesses gti.var 0
scoreboard players set #wrong gti.var 0
scoreboard players set #cost gti.var 0
scoreboard players set #time gti.var 0
scoreboard players set #timer gti.var 0
scoreboard players set #clock gti.var 0
scoreboard players set #anim gti.var 0
scoreboard players set #paused gti.var 0
scoreboard players set #hint_stage gti.var 0
scoreboard players set #hints_used gti.var 0
scoreboard players set #free gti.var 0
scoreboard players set #warned gti.var 0
scoreboard players set #summary_ready gti.var 0
scoreboard players set #pulse gti.var 0
scoreboard players set #bob gti.var 0
scoreboard players set #sway gti.var 0
scoreboard players set #scan gti.var 0
scoreboard players set #run0 gti.var 0
scoreboard players set #run1 gti.var 40
scoreboard players set #halo gti.var 0
scoreboard players set #shutter gti.var 0
scoreboard players set #idle_fx gti.var 0
scoreboard players set #team_best gti.var 2147483000
scoreboard players set #team_best_tries gti.var 0
scoreboard players set #team_best_pixels gti.var 0
scoreboard players set #ab_clock gti.var 0
data modify storage gti:config fixed set value {id:"minecraft:diamond",count:1}
data modify storage gti:cfg answer set value "minecraft:diamond"
data modify storage gti:cfg answer_key set value "item.minecraft.diamond"
data modify storage gti:cfg hint set value "BRAK PODPOWIEDZI"
data modify storage gti:ui guesses set value 0
data modify storage gti:ui pixels set value 0
data modify storage gti:ui wrong set value 0
data modify storage gti:ui batch set value 1
data modify storage gti:ui limit set value 0
data modify storage gti:ui cost set value 0
data modify storage gti:ui mins set value 0
data modify storage gti:ui secs set value 0
data modify storage gti:ui round set value 0
data modify storage gti:ui hint_stage set value 0
data modify storage gti:ui timer_seconds set value 0
data modify storage gti:ui mm0 set value ""
data modify storage gti:ui ss0 set value ""
data modify storage gti:ui limit_label set value "∞"
data modify storage gti:ui mode set value "RĘCZNIE"
data modify storage gti:ui status set value "GOTOWA"
data modify storage gti:ui time set value "0:00"
data modify storage gti:ui hint set value "BRAK PODPOWIEDZI"
data modify storage gti:ui answer set value "???"
data modify storage gti:ui answer_line set value "ODPOWIEDŹ: ???"
data modify storage gti:ui reveal_label set value "ODKRYJ ×1"
data modify storage gti:ui hint_label set value "PODPOWIEDŹ 0/3"
data modify storage gti:ui budget_label set value "0 / ∞"
data modify storage gti:ui progress_label set value "0 / 256"
data modify storage gti:ui round_label set value "RUNDA 0 • GOTOWA"
data modify storage gti:ui timer_label set value "RĘCZNIE"
