execute as @e[tag=gti.overlay.title,limit=1] run data modify entity @s text set value {"text":"KONIEC RUNDY","color":"#FF8996","bold":true}
execute as @e[tag=gti.overlay.title,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:8,transformation:{scale:[2.4f,2.4f,2.4f],translation:[0f,0f,0f]}}
execute as @e[tag=gti.overlay.sub,limit=1] run data modify entity @s text set value {"text":"Odpowiedź odsłonięta na planszy","color":"#8FA8C8"}
execute as @e[tag=gti.overlay.sub,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:8,transformation:{scale:[0.9f,0.9f,0.9f],translation:[0f,0f,0f]}}
execute as @e[tag=gti.item,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:16,transformation:{scale:[21.6f,21.6f,0.001f],translation:[0f,0.4f,0f],left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f]}}
execute at @e[tag=gti.anchor,limit=1] run particle minecraft:glow ~ ~ ~0.6 8 8 0.2 0.01 60 force @a[tag=gti.player]
execute as @a[tag=gti.player] at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.6 0.6
