execute if score #anim gti.var matches 1 as @e[tag=gti.mask,tag=gti.row0] run function gti:internal/final_shrink_lose
execute if score #anim gti.var matches 3 as @e[tag=gti.mask,tag=gti.row1] run function gti:internal/final_shrink_lose
execute if score #anim gti.var matches 5 as @e[tag=gti.mask,tag=gti.row2] run function gti:internal/final_shrink_lose
execute if score #anim gti.var matches 7 as @e[tag=gti.mask,tag=gti.row3] run function gti:internal/final_shrink_lose
execute if score #anim gti.var matches 9 as @e[tag=gti.mask,tag=gti.row4] run function gti:internal/final_shrink_lose
execute if score #anim gti.var matches 11 as @e[tag=gti.mask,tag=gti.row5] run function gti:internal/final_shrink_lose
execute if score #anim gti.var matches 13 as @e[tag=gti.mask,tag=gti.row6] run function gti:internal/final_shrink_lose
execute if score #anim gti.var matches 15 as @e[tag=gti.mask,tag=gti.row7] run function gti:internal/final_shrink_lose
execute if score #anim gti.var matches 17 as @e[tag=gti.mask,tag=gti.row8] run function gti:internal/final_shrink_lose
execute if score #anim gti.var matches 19 as @e[tag=gti.mask,tag=gti.row9] run function gti:internal/final_shrink_lose
execute if score #anim gti.var matches 21 as @e[tag=gti.mask,tag=gti.row10] run function gti:internal/final_shrink_lose
execute if score #anim gti.var matches 23 as @e[tag=gti.mask,tag=gti.row11] run function gti:internal/final_shrink_lose
execute if score #anim gti.var matches 25 as @e[tag=gti.mask,tag=gti.row12] run function gti:internal/final_shrink_lose
execute if score #anim gti.var matches 27 as @e[tag=gti.mask,tag=gti.row13] run function gti:internal/final_shrink_lose
execute if score #anim gti.var matches 29 as @e[tag=gti.mask,tag=gti.row14] run function gti:internal/final_shrink_lose
execute if score #anim gti.var matches 31 as @e[tag=gti.mask,tag=gti.row15] run function gti:internal/final_shrink_lose
execute if score #anim gti.var matches 100 run function gti:internal/end_finale
