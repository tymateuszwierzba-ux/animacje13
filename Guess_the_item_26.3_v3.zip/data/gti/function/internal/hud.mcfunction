scoreboard players operation #seconds gti.var = #time gti.var
scoreboard players operation #seconds gti.var /= #twenty gti.var
scoreboard players operation #mins gti.var = #seconds gti.var
scoreboard players operation #mins gti.var /= #sixty gti.var
scoreboard players operation #secs gti.var = #seconds gti.var
scoreboard players operation #secs gti.var %= #sixty gti.var
scoreboard players operation #remaining gti.var = #limit gti.var
scoreboard players operation #remaining gti.var -= #cost gti.var
execute if score #remaining gti.var matches ..-1 run scoreboard players set #remaining gti.var 0
execute store result storage gti:ui guesses int 1 run scoreboard players get #guesses gti.var
execute store result storage gti:ui pixels int 1 run scoreboard players get #pixels gti.var
execute store result storage gti:ui wrong int 1 run scoreboard players get #wrong gti.var
execute store result storage gti:ui batch int 1 run scoreboard players get #batch gti.var
execute store result storage gti:ui limit int 1 run scoreboard players get #limit gti.var
execute store result storage gti:ui cost int 1 run scoreboard players get #cost gti.var
execute store result storage gti:ui mins int 1 run scoreboard players get #mins gti.var
execute store result storage gti:ui secs int 1 run scoreboard players get #secs gti.var
execute store result storage gti:ui round int 1 run scoreboard players get #round gti.var
execute store result storage gti:ui hint_stage int 1 run scoreboard players get #hint_stage gti.var
data modify storage gti:ui mm0 set value ""
data modify storage gti:ui ss0 set value ""
execute if score #mins gti.var matches ..9 run data modify storage gti:ui mm0 set value "0"
execute if score #secs gti.var matches ..9 run data modify storage gti:ui ss0 set value "0"
data modify storage gti:ui limit_label set value "∞"
execute if score #limit gti.var matches 1.. run function gti:visual/set_limit_label with storage gti:ui
function gti:visual/set_time with storage gti:ui
data modify storage gti:ui mode set value "RĘCZNIE"
execute if score #reveal_mode gti.var matches 1 run data modify storage gti:ui mode set value "PO BŁĘDZIE"
execute if score #reveal_mode gti.var matches 2 run data modify storage gti:ui mode set value "AUTO"
data modify storage gti:ui status set value "GOTOWA"
execute if score #state gti.var matches 1 run data modify storage gti:ui status set value "INTRO"
execute if score #state gti.var matches 2 run data modify storage gti:ui status set value "LIVE"
execute if score #state gti.var matches 3 run data modify storage gti:ui status set value "FINALE"
execute if score #paused gti.var matches 1 run data modify storage gti:ui status set value "PAUZA"
scoreboard players set #timer_left gti.var 0
execute if score #reveal_mode gti.var matches 2 run scoreboard players operation #timer_left gti.var = #interval gti.var
execute if score #reveal_mode gti.var matches 2 run scoreboard players operation #timer_left gti.var -= #timer gti.var
execute if score #timer_left gti.var matches ..-1 run scoreboard players set #timer_left gti.var 0
scoreboard players operation #timer_left gti.var /= #twenty gti.var
execute store result storage gti:ui timer_seconds int 1 run scoreboard players get #timer_left gti.var
data modify storage gti:ui answer set from storage gti:cfg answer
data modify storage gti:ui hint set from storage gti:cfg hint
execute if score #hint_stage gti.var matches 0 run data modify storage gti:ui hint set value "BRAK PODPOWIEDZI"
execute if score #hints_enabled gti.var matches 0 run data modify storage gti:ui hint set value "PODPOWIEDZI WYŁĄCZONE"
data modify storage gti:ui timer_label set value "RĘCZNIE"
execute if score #reveal_mode gti.var matches 1 run data modify storage gti:ui timer_label set value "PO BŁĘDZIE"
execute if score #reveal_mode gti.var matches 2 run function gti:visual/fmt_timer with storage gti:ui
function gti:visual/fmt_labels with storage gti:ui
function gti:visual/hud_apply with storage gti:ui
function gti:visual/progress
function gti:visual/budget
execute if score #state gti.var matches 2..3 run function gti:internal/bossbars
