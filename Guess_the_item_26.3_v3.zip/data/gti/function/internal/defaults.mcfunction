scoreboard players set #source gti.var 0
scoreboard players set #reveal_mode gti.var 0
scoreboard players set #batch gti.var 1
scoreboard players set #seconds_cfg gti.var 6
scoreboard players set #initial gti.var 1
scoreboard players set #limit gti.var 0
scoreboard players set #aliases gti.var 1
scoreboard players set #hints_enabled gti.var 1
