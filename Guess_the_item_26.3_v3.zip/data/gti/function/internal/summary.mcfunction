execute store result storage gti:tmp round int 1 run scoreboard players get #round gti.var
execute store result storage gti:tmp tries int 1 run scoreboard players get #last_tries gti.var
execute store result storage gti:tmp pixels int 1 run scoreboard players get #last_pixels gti.var
execute store result storage gti:tmp wrong int 1 run scoreboard players get #last_wrong gti.var
execute store result storage gti:tmp secs int 1 run scoreboard players get #last_time gti.var
execute store result storage gti:tmp hints int 1 run scoreboard players get #last_hints gti.var
execute store result storage gti:tmp cost int 1 run scoreboard players get #last_cost gti.var
data modify storage gti:tmp key set from storage gti:cfg answer_key
execute if score #result gti.var matches 1 run function gti:internal/summary_win with storage gti:tmp
execute if score #result gti.var matches 0 run function gti:internal/summary_lose with storage gti:tmp
