execute unless score #state gti.var matches 2 run return 0
scoreboard players add #wrong gti.var 1
scoreboard players add #cost gti.var 4
scoreboard players set @s gti.streak 0
title @s times 2 22 8
title @s subtitle {"text":"−4 punkty • spróbuj ponownie","color":"gray"}
title @s title {"text":"NIE TEN ITEM","color":"#FF8996","bold":true}
execute at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.8 0.55
execute as @e[tag=gti.overlay.bad,limit=1] run data modify entity @s text set value {"text":"−4 PUNKTY","color":"#FF8996","bold":true}
execute as @e[tag=gti.overlay.bad,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:0,transformation:{scale:[0.4f,0.4f,0.4f],translation:[0f,0f,0f]}}
execute as @e[tag=gti.overlay.bad,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:4,transformation:{scale:[1.5f,1.5f,1.5f],translation:[0f,0f,0f]}}
execute at @e[tag=gti.anchor,limit=1] run particle minecraft:glow ~ ~ ~0.7 8 8 0.2 0.01 60 force @a[tag=gti.player]
execute at @e[tag=gti.anchor,limit=1] run particle minecraft:smoke ~ ~ ~0.7 6 6 0.2 0.02 25 force @a[tag=gti.player]
function gti:internal/hud
execute if score #limit gti.var matches 1.. if score #cost gti.var >= #limit gti.var run function gti:internal/lose
execute if score #state gti.var matches 2 if score #reveal_mode gti.var matches 1 run function gti:internal/auto_batch
