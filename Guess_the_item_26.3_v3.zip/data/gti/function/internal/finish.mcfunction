scoreboard players set #state gti.var 3
scoreboard players set #anim gti.var 0
scoreboard players operation #last_tries gti.var = #guesses gti.var
scoreboard players operation #last_pixels gti.var = #pixels gti.var
scoreboard players operation #last_wrong gti.var = #wrong gti.var
scoreboard players operation #last_time gti.var = #time gti.var
scoreboard players operation #last_time gti.var /= #twenty gti.var
scoreboard players operation #last_hints gti.var = #hints_used gti.var
scoreboard players operation #last_cost gti.var = #cost gti.var
scoreboard players operation #last_result gti.var = #result gti.var
scoreboard players set #shown_summary gti.var 0
scoreboard players set #summary_ready gti.var 1
kill @e[tag=gti.pixel]
kill @e[tag=gti.fx]
bossbar set gti:timer visible false
data modify storage gti:tmp key set from storage gti:cfg answer_key
function gti:visual/answer_caption with storage gti:tmp
data modify storage gti:tmp msg set value "Koniec rundy — podsumowanie za chwilę."
function gti:visual/event with storage gti:tmp
execute if score #result gti.var matches 1 run function gti:internal/finale_win_start
execute if score #result gti.var matches 0 run function gti:internal/finale_lose_start
function gti:internal/hud
