execute if score #paused gti.var matches 1 run return 0
scoreboard players add #time gti.var 1
execute if score #reveal_mode gti.var matches 2 run scoreboard players add #timer gti.var 1
execute if score #reveal_mode gti.var matches 2 if score #timer gti.var >= #interval gti.var run function gti:internal/auto_batch
execute if score #limit gti.var matches 1.. if score #remaining gti.var matches 1..8 if score #warned gti.var matches 0 run function gti:internal/warn
execute if score #limit gti.var matches 1.. if score #cost gti.var >= #limit gti.var run function gti:internal/lose
