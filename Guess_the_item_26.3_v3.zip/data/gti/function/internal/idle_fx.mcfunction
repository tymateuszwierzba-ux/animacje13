execute at @e[tag=gti.anchor,limit=1] run particle minecraft:end_rod ~ ~11.6 ~0.5 8.5 0.2 0.2 0.01 2 force @a[tag=gti.player]
execute at @e[tag=gti.anchor,limit=1] run particle minecraft:glow ~ ~ ~0.9 9.5 9.5 0.1 0.01 3 force @a[tag=gti.player]
