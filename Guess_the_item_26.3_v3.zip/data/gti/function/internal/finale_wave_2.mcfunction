function gti:visual/confetti
execute as @a[tag=gti.player] at @s run playsound minecraft:entity.firework_rocket.launch master @s ~ ~ ~ 0.7 1.6
