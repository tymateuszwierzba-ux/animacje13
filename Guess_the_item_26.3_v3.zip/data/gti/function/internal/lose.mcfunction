execute unless score #state gti.var matches 2 run return 0
scoreboard players set #result gti.var 0
title @a[tag=gti.player] times 5 60 15
title @a[tag=gti.player] subtitle {"text":"Budżet wyczerpany — odpowiedź na planszy","color":"gray"}
title @a[tag=gti.player] title {"text":"KONIEC RUNDY","color":"#FF8996","bold":true}
execute as @a[tag=gti.player] at @s run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 0.7 0.7
execute as @a[tag=gti.player] at @s run playsound minecraft:entity.villager.no master @s ~ ~ ~ 0.6 0.8
function gti:internal/finish
