summon interaction ~-5.625 ~9.375 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col3","gti.row0"]}
execute positioned ~-5.625 ~9.375 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 3
summon interaction ~-5.625 ~8.125 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col3","gti.row1"]}
execute positioned ~-5.625 ~8.125 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 19
summon interaction ~-5.625 ~6.875 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col3","gti.row2"]}
execute positioned ~-5.625 ~6.875 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 35
summon interaction ~-5.625 ~5.625 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col3","gti.row3"]}
execute positioned ~-5.625 ~5.625 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 51
summon interaction ~-5.625 ~4.375 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col3","gti.row4"]}
execute positioned ~-5.625 ~4.375 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 67
summon interaction ~-5.625 ~3.125 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col3","gti.row5"]}
execute positioned ~-5.625 ~3.125 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 83
summon interaction ~-5.625 ~1.875 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col3","gti.row6"]}
execute positioned ~-5.625 ~1.875 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 99
summon interaction ~-5.625 ~0.625 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col3","gti.row7"]}
execute positioned ~-5.625 ~0.625 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 115
summon interaction ~-5.625 ~-0.625 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col3","gti.row8"]}
execute positioned ~-5.625 ~-0.625 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 131
summon interaction ~-5.625 ~-1.875 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col3","gti.row9"]}
execute positioned ~-5.625 ~-1.875 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 147
summon interaction ~-5.625 ~-3.125 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col3","gti.row10"]}
execute positioned ~-5.625 ~-3.125 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 163
summon interaction ~-5.625 ~-4.375 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col3","gti.row11"]}
execute positioned ~-5.625 ~-4.375 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 179
summon interaction ~-5.625 ~-5.625 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col3","gti.row12"]}
execute positioned ~-5.625 ~-5.625 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 195
summon interaction ~-5.625 ~-6.875 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col3","gti.row13"]}
execute positioned ~-5.625 ~-6.875 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 211
summon interaction ~-5.625 ~-8.125 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col3","gti.row14"]}
execute positioned ~-5.625 ~-8.125 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 227
summon interaction ~-5.625 ~-9.375 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col3","gti.row15"]}
execute positioned ~-5.625 ~-9.375 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 243
