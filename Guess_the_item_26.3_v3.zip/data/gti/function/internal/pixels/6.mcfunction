summon interaction ~-1.875 ~9.375 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col6","gti.row0"]}
execute positioned ~-1.875 ~9.375 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 6
summon interaction ~-1.875 ~8.125 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col6","gti.row1"]}
execute positioned ~-1.875 ~8.125 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 22
summon interaction ~-1.875 ~6.875 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col6","gti.row2"]}
execute positioned ~-1.875 ~6.875 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 38
summon interaction ~-1.875 ~5.625 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col6","gti.row3"]}
execute positioned ~-1.875 ~5.625 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 54
summon interaction ~-1.875 ~4.375 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col6","gti.row4"]}
execute positioned ~-1.875 ~4.375 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 70
summon interaction ~-1.875 ~3.125 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col6","gti.row5"]}
execute positioned ~-1.875 ~3.125 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 86
summon interaction ~-1.875 ~1.875 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col6","gti.row6"]}
execute positioned ~-1.875 ~1.875 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 102
summon interaction ~-1.875 ~0.625 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col6","gti.row7"]}
execute positioned ~-1.875 ~0.625 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 118
summon interaction ~-1.875 ~-0.625 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col6","gti.row8"]}
execute positioned ~-1.875 ~-0.625 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 134
summon interaction ~-1.875 ~-1.875 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col6","gti.row9"]}
execute positioned ~-1.875 ~-1.875 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 150
summon interaction ~-1.875 ~-3.125 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col6","gti.row10"]}
execute positioned ~-1.875 ~-3.125 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 166
summon interaction ~-1.875 ~-4.375 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col6","gti.row11"]}
execute positioned ~-1.875 ~-4.375 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 182
summon interaction ~-1.875 ~-5.625 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col6","gti.row12"]}
execute positioned ~-1.875 ~-5.625 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 198
summon interaction ~-1.875 ~-6.875 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col6","gti.row13"]}
execute positioned ~-1.875 ~-6.875 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 214
summon interaction ~-1.875 ~-8.125 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col6","gti.row14"]}
execute positioned ~-1.875 ~-8.125 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 230
summon interaction ~-1.875 ~-9.375 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col6","gti.row15"]}
execute positioned ~-1.875 ~-9.375 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 246
