summon interaction ~-0.625 ~9.375 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col7","gti.row0"]}
execute positioned ~-0.625 ~9.375 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 7
summon interaction ~-0.625 ~8.125 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col7","gti.row1"]}
execute positioned ~-0.625 ~8.125 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 23
summon interaction ~-0.625 ~6.875 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col7","gti.row2"]}
execute positioned ~-0.625 ~6.875 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 39
summon interaction ~-0.625 ~5.625 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col7","gti.row3"]}
execute positioned ~-0.625 ~5.625 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 55
summon interaction ~-0.625 ~4.375 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col7","gti.row4"]}
execute positioned ~-0.625 ~4.375 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 71
summon interaction ~-0.625 ~3.125 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col7","gti.row5"]}
execute positioned ~-0.625 ~3.125 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 87
summon interaction ~-0.625 ~1.875 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col7","gti.row6"]}
execute positioned ~-0.625 ~1.875 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 103
summon interaction ~-0.625 ~0.625 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col7","gti.row7"]}
execute positioned ~-0.625 ~0.625 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 119
summon interaction ~-0.625 ~-0.625 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col7","gti.row8"]}
execute positioned ~-0.625 ~-0.625 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 135
summon interaction ~-0.625 ~-1.875 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col7","gti.row9"]}
execute positioned ~-0.625 ~-1.875 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 151
summon interaction ~-0.625 ~-3.125 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col7","gti.row10"]}
execute positioned ~-0.625 ~-3.125 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 167
summon interaction ~-0.625 ~-4.375 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col7","gti.row11"]}
execute positioned ~-0.625 ~-4.375 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 183
summon interaction ~-0.625 ~-5.625 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col7","gti.row12"]}
execute positioned ~-0.625 ~-5.625 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 199
summon interaction ~-0.625 ~-6.875 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col7","gti.row13"]}
execute positioned ~-0.625 ~-6.875 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 215
summon interaction ~-0.625 ~-8.125 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col7","gti.row14"]}
execute positioned ~-0.625 ~-8.125 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 231
summon interaction ~-0.625 ~-9.375 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col7","gti.row15"]}
execute positioned ~-0.625 ~-9.375 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 247
