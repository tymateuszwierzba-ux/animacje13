summon interaction ~0.625 ~9.375 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col8","gti.row0"]}
execute positioned ~0.625 ~9.375 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 8
summon interaction ~0.625 ~8.125 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col8","gti.row1"]}
execute positioned ~0.625 ~8.125 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 24
summon interaction ~0.625 ~6.875 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col8","gti.row2"]}
execute positioned ~0.625 ~6.875 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 40
summon interaction ~0.625 ~5.625 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col8","gti.row3"]}
execute positioned ~0.625 ~5.625 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 56
summon interaction ~0.625 ~4.375 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col8","gti.row4"]}
execute positioned ~0.625 ~4.375 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 72
summon interaction ~0.625 ~3.125 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col8","gti.row5"]}
execute positioned ~0.625 ~3.125 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 88
summon interaction ~0.625 ~1.875 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col8","gti.row6"]}
execute positioned ~0.625 ~1.875 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 104
summon interaction ~0.625 ~0.625 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col8","gti.row7"]}
execute positioned ~0.625 ~0.625 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 120
summon interaction ~0.625 ~-0.625 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col8","gti.row8"]}
execute positioned ~0.625 ~-0.625 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 136
summon interaction ~0.625 ~-1.875 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col8","gti.row9"]}
execute positioned ~0.625 ~-1.875 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 152
summon interaction ~0.625 ~-3.125 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col8","gti.row10"]}
execute positioned ~0.625 ~-3.125 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 168
summon interaction ~0.625 ~-4.375 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col8","gti.row11"]}
execute positioned ~0.625 ~-4.375 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 184
summon interaction ~0.625 ~-5.625 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col8","gti.row12"]}
execute positioned ~0.625 ~-5.625 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 200
summon interaction ~0.625 ~-6.875 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col8","gti.row13"]}
execute positioned ~0.625 ~-6.875 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 216
summon interaction ~0.625 ~-8.125 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col8","gti.row14"]}
execute positioned ~0.625 ~-8.125 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 232
summon interaction ~0.625 ~-9.375 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col8","gti.row15"]}
execute positioned ~0.625 ~-9.375 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 248
