summon interaction ~-3.125 ~9.375 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col5","gti.row0"]}
execute positioned ~-3.125 ~9.375 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 5
summon interaction ~-3.125 ~8.125 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col5","gti.row1"]}
execute positioned ~-3.125 ~8.125 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 21
summon interaction ~-3.125 ~6.875 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col5","gti.row2"]}
execute positioned ~-3.125 ~6.875 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 37
summon interaction ~-3.125 ~5.625 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col5","gti.row3"]}
execute positioned ~-3.125 ~5.625 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 53
summon interaction ~-3.125 ~4.375 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col5","gti.row4"]}
execute positioned ~-3.125 ~4.375 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 69
summon interaction ~-3.125 ~3.125 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col5","gti.row5"]}
execute positioned ~-3.125 ~3.125 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 85
summon interaction ~-3.125 ~1.875 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col5","gti.row6"]}
execute positioned ~-3.125 ~1.875 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 101
summon interaction ~-3.125 ~0.625 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col5","gti.row7"]}
execute positioned ~-3.125 ~0.625 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 117
summon interaction ~-3.125 ~-0.625 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col5","gti.row8"]}
execute positioned ~-3.125 ~-0.625 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 133
summon interaction ~-3.125 ~-1.875 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col5","gti.row9"]}
execute positioned ~-3.125 ~-1.875 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 149
summon interaction ~-3.125 ~-3.125 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col5","gti.row10"]}
execute positioned ~-3.125 ~-3.125 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 165
summon interaction ~-3.125 ~-4.375 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col5","gti.row11"]}
execute positioned ~-3.125 ~-4.375 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 181
summon interaction ~-3.125 ~-5.625 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col5","gti.row12"]}
execute positioned ~-3.125 ~-5.625 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 197
summon interaction ~-3.125 ~-6.875 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col5","gti.row13"]}
execute positioned ~-3.125 ~-6.875 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 213
summon interaction ~-3.125 ~-8.125 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col5","gti.row14"]}
execute positioned ~-3.125 ~-8.125 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 229
summon interaction ~-3.125 ~-9.375 ~0.34 {width:1.22f,height:1.22f,response:1b,Tags:["gti.entity","gti.pixel","gti.col5","gti.row15"]}
execute positioned ~-3.125 ~-9.375 ~0.34 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 245
