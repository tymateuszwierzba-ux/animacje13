data merge entity @s {start_interpolation:0,interpolation_duration:9,transformation:{scale:[0.02f,0.02f,0.06f],translation:[0f,0f,0.9f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute at @s run particle minecraft:firework ~0.63 ~0.63 ~0.25 0.35 0.35 0.05 0.12 6 force @a[tag=gti.player]
