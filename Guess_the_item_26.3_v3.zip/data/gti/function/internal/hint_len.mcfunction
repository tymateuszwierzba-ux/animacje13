$data modify storage gti:cfg hint set value "DŁUGOŚĆ: $(len) • PIERWSZA LITERA: $(first)"
