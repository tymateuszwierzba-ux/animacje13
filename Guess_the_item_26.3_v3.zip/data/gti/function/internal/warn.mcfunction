scoreboard players set #warned gti.var 1
title @a[tag=gti.player] actionbar [{"text":"⚠ NISKI BUDŻET","color":"red","bold":true}]
execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 1.4
