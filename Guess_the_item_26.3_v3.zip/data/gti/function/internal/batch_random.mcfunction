$execute as @e[tag=gti.pixel,tag=!gti.open,sort=random,limit=$(batch)] at @s run function gti:internal/reveal
execute at @e[tag=gti.anchor,limit=1] run playsound minecraft:block.amethyst_block.chime master @a[tag=gti.player] ~ ~ ~ 0.5 1.35
execute at @e[tag=gti.anchor,limit=1] run particle minecraft:electric_spark ~ ~ ~0.6 9 9 0.2 0.02 30 force @a[tag=gti.player]
