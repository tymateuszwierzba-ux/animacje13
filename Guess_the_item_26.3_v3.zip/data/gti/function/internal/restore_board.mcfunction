kill @e[tag=gti.pixel]
kill @e[tag=gti.fx]
execute as @e[tag=gti.mask] run data merge entity @s {block_state:{Name:"minecraft:black_concrete"},start_interpolation:0,interpolation_duration:0,transformation:{scale:[1.26f,1.26f,0.055f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute as @e[tag=gti.mask] run tag @s remove gti.fx
function gti:visual/halo_reset
function gti:visual/shutter_open_all
function gti:visual/answer_hidden
execute as @e[tag=gti.item,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:0,transformation:{scale:[20f,20f,0.001f],translation:[0f,0f,0f],left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f]}}
execute as @e[tag=gti.overlay.bad,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:3,transformation:{scale:[0.01f,0.01f,0.01f],translation:[0f,0f,0f]}}
bossbar set gti:budget visible false
bossbar set gti:timer visible false
