scoreboard players set #state gti.var 0
function gti:internal/restore_board
function gti:internal/hud
execute as @e[tag=gti.overlay.title,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:6,transformation:{scale:[0.01f,0.01f,0.01f],translation:[0f,0f,0f]}}
execute as @e[tag=gti.overlay.sub,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:6,transformation:{scale:[0.01f,0.01f,0.01f],translation:[0f,0f,0f]}}
data modify storage gti:tmp msg set value "Gotowe. Naciśnij START, aby zagrać ponownie."
function gti:visual/event with storage gti:tmp
scoreboard players set #idle_fx gti.var 5
