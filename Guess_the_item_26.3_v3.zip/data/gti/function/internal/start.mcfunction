scoreboard players set #state gti.var 1
scoreboard players set #anim gti.var 0
scoreboard players set #clock gti.var 0
scoreboard players set #result gti.var 2
scoreboard players set #paused gti.var 0
scoreboard players set #hint_stage gti.var 0
scoreboard players set #hints_used gti.var 0
scoreboard players set #cost gti.var 0
scoreboard players set #pixels gti.var 0
scoreboard players set #guesses gti.var 0
scoreboard players set #wrong gti.var 0
scoreboard players set #time gti.var 0
scoreboard players set #timer gti.var 0
scoreboard players set #shown_summary gti.var 0
scoreboard players set #new_record gti.var 0
scoreboard players set #free gti.var 0
scoreboard players set #warned gti.var 0
scoreboard players add #round gti.var 1
scoreboard players operation #interval gti.var = #seconds_cfg gti.var
scoreboard players operation #interval gti.var *= #twenty gti.var
scoreboard players set @a[tag=gti.player] gti.tries 0
scoreboard players set @a[tag=gti.player] gti.clicks 0
execute as @e[tag=gti.mask] run data merge entity @s {block_state:{Name:"minecraft:black_concrete"},start_interpolation:0,interpolation_duration:0,transformation:{scale:[1.26f,1.26f,0.055f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute as @e[tag=gti.mask] run tag @s remove gti.fx
kill @e[tag=gti.pixel]
function gti:internal/pixels/0
function gti:internal/pixels/1
function gti:internal/pixels/2
function gti:internal/pixels/3
function gti:internal/pixels/4
function gti:internal/pixels/5
function gti:internal/pixels/6
function gti:internal/pixels/7
function gti:internal/pixels/8
function gti:internal/pixels/9
function gti:internal/pixels/10
function gti:internal/pixels/11
function gti:internal/pixels/12
function gti:internal/pixels/13
function gti:internal/pixels/14
function gti:internal/pixels/15
kill @e[tag=gti.fx]
function gti:visual/halo_reset
function gti:visual/shutter_open_all
function gti:data/set_answer
function gti:visual/answer_hidden
execute as @e[tag=gti.overlay.title,limit=1] run data modify entity @s text set value {"text":"INICJALIZACJA","color":"#45E9E0","bold":true}
execute as @e[tag=gti.overlay.title,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:8,transformation:{scale:[1.9f,1.9f,1.9f],translation:[0f,0f,0f]}}
execute as @e[tag=gti.overlay.sub,limit=1] run data modify entity @s text set value {"text":"Losowanie przedmiotu z pełnej puli","color":"#8FA8C8"}
execute as @e[tag=gti.overlay.sub,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:8,transformation:{scale:[0.85f,0.85f,0.85f],translation:[0f,0f,0f]}}
execute as @e[tag=gti.overlay.count,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:0,transformation:{scale:[0.01f,0.01f,0.01f],translation:[0f,0f,0f]}}
execute as @e[tag=gti.overlay.bad,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:0,transformation:{scale:[0.01f,0.01f,0.01f],translation:[0f,0f,0f]}}
execute as @e[tag=gti.item,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:0,transformation:{scale:[20f,20f,0.001f],translation:[0f,0f,0f],left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f]}}
execute as @e[tag=gti.hud.answer,limit=1] run data modify entity @s text set value [{"text":"ODPOWIEDŹ UKRYTA","color":"#8FA8C8"}]
data modify storage gti:tmp msg set value "Runda startuje — losowanie hasła."
function gti:visual/event with storage gti:tmp
title @a[tag=gti.player] times 5 35 10
title @a[tag=gti.player] subtitle {"text":"Przygotuj się…","color":"gray"}
title @a[tag=gti.player] title {"text":"GUESS THE ITEM","color":"#45E9E0","bold":true}
execute as @a[tag=gti.player] at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.65 1.2
execute as @a[tag=gti.player] at @s run playsound minecraft:block.conduit.activate master @s ~ ~ ~ 0.5 1.4
function gti:internal/hud
