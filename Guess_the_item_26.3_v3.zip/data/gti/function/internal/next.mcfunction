execute unless score #state gti.var matches 0 run return run tellraw @s {"text":"Runda trwa. Przerwij ją: /function gti:stop","color":"red"}
tag @s add gti.player
execute at @e[tag=gti.anchor,limit=1] run function gti:internal/start
