execute unless score #state gti.var matches 1..3 run return run tellraw @s {"text":"Runda już stoi.","color":"gray"}
scoreboard players set #state gti.var 0
scoreboard players set #paused gti.var 0
scoreboard players set #result gti.var 2
function gti:internal/restore_board
execute as @e[tag=gti.overlay.count,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:0,transformation:{scale:[0.01f,0.01f,0.01f],translation:[0f,0f,0f]}}
execute as @e[tag=gti.overlay.title,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:3,transformation:{scale:[0.01f,0.01f,0.01f],translation:[0f,0f,0f]}}
execute as @e[tag=gti.overlay.sub,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:3,transformation:{scale:[0.01f,0.01f,0.01f],translation:[0f,0f,0f]}}
data modify storage gti:tmp msg set value "Runda przerwana."
function gti:visual/event with storage gti:tmp
function gti:internal/hud
