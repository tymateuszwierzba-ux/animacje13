scoreboard players add #anim gti.var 1
execute if score #result gti.var matches 1 run function gti:internal/finale_win
execute if score #result gti.var matches 0 run function gti:internal/finale_lose
execute if score #anim gti.var matches 70 if score #shown_summary gti.var matches 0 run function gti:internal/summary
execute if score #anim gti.var matches 70 run scoreboard players set #shown_summary gti.var 1
