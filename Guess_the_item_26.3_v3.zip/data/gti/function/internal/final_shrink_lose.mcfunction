data merge entity @s {start_interpolation:0,interpolation_duration:12,transformation:{scale:[0.02f,0.02f,0.06f],translation:[0f,-1.8f,0.6f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute at @s run particle minecraft:crit ~0.63 ~0.63 ~0.25 0.3 0.3 0.05 0 3 force @a[tag=gti.player]
