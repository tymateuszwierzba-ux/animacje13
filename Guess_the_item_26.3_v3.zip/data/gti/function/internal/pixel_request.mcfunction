execute unless score #state gti.var matches 2 run return run tellraw @s {"text":"Poczekaj na start rundy. Menu: /trigger gti.menu","color":"gray"}
execute if score #paused gti.var matches 1 run return run tellraw @s {"text":"Runda jest wstrzymana.","color":"yellow"}
execute unless entity @e[tag=gti.pixel,tag=!gti.open,limit=1] run return run tellraw @s {"text":"Wszystkie pola odkryte — zgaduj! Trzymaj przedmiot w ręce.","color":"yellow"}
tag @s add gti.player
scoreboard players add @s gti.clicks 1
execute store result storage gti:ctx batch int 1 run scoreboard players get #batch gti.var
execute at @e[tag=gti.anchor,limit=1] run function gti:internal/batch_random with storage gti:ctx
data modify storage gti:tmp msg set value "Odkryto paczkę pikseli."
function gti:visual/event with storage gti:tmp
function gti:internal/hud
