scoreboard players operation #remaining_boss gti.var = #limit gti.var
scoreboard players operation #remaining_boss gti.var -= #cost gti.var
execute if score #remaining_boss gti.var matches ..-1 run scoreboard players set #remaining_boss gti.var 0
execute if score #limit gti.var matches 0 run scoreboard players set #remaining_boss gti.var 1
execute if score #limit gti.var matches 1.. store result bossbar gti:budget max run scoreboard players get #limit gti.var
execute if score #limit gti.var matches 1.. store result bossbar gti:budget value run scoreboard players get #remaining_boss gti.var
execute if score #limit gti.var matches 0 run bossbar set gti:budget max 1
execute if score #limit gti.var matches 0 run bossbar set gti:budget value 1
bossbar set gti:budget players @a[tag=gti.player]
bossbar set gti:budget color green
execute if score #limit gti.var matches 1.. if score #remaining_boss gti.var matches ..8 run bossbar set gti:budget color red
execute if score #limit gti.var matches 1.. if score #remaining_boss gti.var matches 9..24 run bossbar set gti:budget color yellow
execute if score #limit gti.var matches 0 run bossbar set gti:budget visible false
execute if score #limit gti.var matches 1.. run bossbar set gti:budget visible true
execute if score #reveal_mode gti.var matches 2 run bossbar set gti:timer players @a[tag=gti.player]
execute if score #reveal_mode gti.var matches 2 run bossbar set gti:timer visible true
execute if score #reveal_mode gti.var matches 0..1 run bossbar set gti:timer visible false
bossbar set gti:timer max 100
scoreboard players set #timer_bar gti.var 0
execute if score #reveal_mode gti.var matches 2 run scoreboard players operation #timer_bar gti.var = #interval gti.var
execute if score #reveal_mode gti.var matches 2 run scoreboard players operation #timer_bar gti.var -= #timer gti.var
execute if score #reveal_mode gti.var matches 2 run scoreboard players operation #timer_bar gti.var *= #hundred gti.var
execute if score #reveal_mode gti.var matches 2 run scoreboard players operation #timer_bar gti.var /= #interval gti.var
execute if score #reveal_mode gti.var matches 2 store result bossbar gti:timer value run scoreboard players get #timer_bar gti.var
