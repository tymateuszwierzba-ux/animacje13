execute if score #hint_stage gti.var matches 1 run function gti:internal/hint_cat
execute if score #hint_stage gti.var matches 2 run function gti:internal/hint_len with storage gti:cfg meta
execute if score #hint_stage gti.var matches 3 run function gti:internal/hint_mask with storage gti:cfg meta
