execute unless score #state gti.var matches 2 run return run data remove entity @s interaction
execute if score #paused gti.var matches 1 run return run data remove entity @s interaction
execute on target run tag @s add gti.player
execute on target run scoreboard players add @s gti.clicks 1
execute store result storage gti:ctx batch int 1 run scoreboard players get #batch gti.var
function gti:internal/batch_near with storage gti:ctx
data remove entity @s interaction
data remove entity @s attack
function gti:internal/hud
