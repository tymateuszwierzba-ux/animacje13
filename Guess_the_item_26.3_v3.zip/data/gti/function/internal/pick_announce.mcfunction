execute as @e[tag=gti.overlay.title,limit=1] run data modify entity @s text set value {"text":"HASŁO WYLOSOWANE","color":"#F6CF84","bold":true}
execute as @e[tag=gti.overlay.sub,limit=1] run data modify entity @s text set value {"text":"Kliknij kafelek albo użyj panelu","color":"#8FA8C8"}
