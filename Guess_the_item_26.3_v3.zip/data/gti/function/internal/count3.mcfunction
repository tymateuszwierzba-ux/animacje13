execute as @e[tag=gti.overlay.title,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:5,transformation:{scale:[0.01f,0.01f,0.01f],translation:[0f,0f,0f]}}
execute as @e[tag=gti.overlay.sub,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:5,transformation:{scale:[0.01f,0.01f,0.01f],translation:[0f,0f,0f]}}
execute as @e[tag=gti.overlay.count,limit=1] run data modify entity @s text set value {"text":"3","color":"#F6CF84","bold":true}
execute as @e[tag=gti.overlay.count,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:0,transformation:{scale:[0.01f,0.01f,0.01f],translation:[0f,0f,0f]}}
execute as @e[tag=gti.overlay.count,limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:7,transformation:{scale:[5.6f,5.6f,5.6f],translation:[0f,0f,0f]}}
execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.8 1.0
execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 0.8
