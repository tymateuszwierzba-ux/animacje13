execute unless score #state gti.var matches 2 run return run tellraw @s {"text":"Poczekaj na start rundy.","color":"gray"}
execute if score #paused gti.var matches 1 run return run tellraw @s {"text":"Runda jest wstrzymana.","color":"yellow"}
execute unless items entity @s weapon.mainhand #gti:answers run return run tellraw @s {"text":"Trzymaj obsługiwany przedmiot w głównej ręce — pusta ręka nie nalicza próby.","color":"yellow"}
tag @s add gti.player
scoreboard players add @s gti.tries 1
scoreboard players add #guesses gti.var 1
data modify storage gti:ctx answer set from storage gti:cfg answer
data modify storage gti:ctx guess set from entity @s SelectedItem.id
scoreboard players set #same gti.var 0
function gti:internal/check_guess with storage gti:ctx
execute if score #same gti.var matches 0 if score #aliases gti.var matches 1 run function gti:internal/equiv with storage gti:ctx
execute if score #same gti.var matches 1 run function gti:internal/win
execute if score #same gti.var matches 0 run function gti:internal/wrong
function gti:internal/hud
