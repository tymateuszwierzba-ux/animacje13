$data modify storage gti:cfg hint set value "WZÓR: $(mask)"
