execute unless score #state gti.var matches 2 run return 0
execute if score #paused gti.var matches 1 run return 0
tag @s add gti.open
data remove entity @s interaction
data remove entity @s attack
scoreboard players add #pixels gti.var 1
execute if score #free gti.var matches 0 run scoreboard players add #cost gti.var 1
execute store result storage gti:ctx id int 1 run scoreboard players get @s gti.id
function gti:internal/shrink with storage gti:ctx
execute at @s run particle minecraft:glow ~ ~ ~0.2 0.5 0.5 0.15 0 8 force @a[tag=gti.player]
execute if score #limit gti.var matches 1.. if score #cost gti.var >= #limit gti.var run function gti:internal/lose
