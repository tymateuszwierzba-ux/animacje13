$execute as @e[tag=gti.pixel,tag=!gti.open,sort=nearest,limit=$(batch)] at @s run function gti:internal/reveal
execute at @e[tag=gti.anchor,limit=1] run playsound minecraft:block.amethyst_block.chime master @a[tag=gti.player] ~ ~ ~ 0.45 1.5
