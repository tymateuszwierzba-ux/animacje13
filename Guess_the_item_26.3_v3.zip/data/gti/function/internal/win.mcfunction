execute unless score #state gti.var matches 2 run return 0
scoreboard players add @s gti.wins 1
scoreboard players add @s gti.rounds 1
scoreboard players add @s gti.streak 1
execute if score @s gti.streak > @s gti.best_streak run scoreboard players operation @s gti.best_streak = @s gti.streak
scoreboard players operation #rank gti.var = #guesses gti.var
scoreboard players operation #rank gti.var *= #thousand gti.var
scoreboard players operation #rank gti.var += #pixels gti.var
scoreboard players set #new_record gti.var 0
execute unless score @s gti.best matches 1.. run scoreboard players set #new_record gti.var 1
execute if score #new_record gti.var matches 0 if score #rank gti.var < @s gti.best run scoreboard players set #new_record gti.var 1
execute if score #new_record gti.var matches 1 run scoreboard players operation @s gti.best = #rank gti.var
execute if score #new_record gti.var matches 1 if score #rank gti.var < #team_best gti.var run scoreboard players operation #team_best gti.var = #rank gti.var
execute if score #new_record gti.var matches 1 if score #rank gti.var < #team_best gti.var run scoreboard players operation #team_best_tries gti.var = #guesses gti.var
execute if score #new_record gti.var matches 1 if score #rank gti.var < #team_best gti.var run scoreboard players operation #team_best_pixels gti.var = #pixels gti.var
execute if score #new_record gti.var matches 1 run tellraw @s {"text":"★ NOWY REKORD! ★","color":"gold","bold":true}
scoreboard players set #result gti.var 1
title @a[tag=gti.player] times 5 55 12
title @a[tag=gti.player] subtitle [{"selector":"@s","color":"#F6CF84"},{"text":" odgaduje przedmiot!","color":"white"}]
title @a[tag=gti.player] title {"text":"TRAFIONE!","color":"#8BE28B","bold":true}
execute as @a[tag=gti.player] at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.75 1.05
execute as @a[tag=gti.player] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 0.5 1.4
function gti:internal/finish
