execute unless entity @s[tag=gti.host] run return run tellraw @s {"text":"Tylko gospodarz może zmieniać presety.","color":"red"}
execute unless score #state gti.var matches 0 run return run tellraw @s {"text":"Presety ustawisz między rundami.","color":"yellow"}
scoreboard players set #limit gti.var 0
scoreboard players set #reveal_mode gti.var 0
scoreboard players set #batch gti.var 4
scoreboard players set #seconds_cfg gti.var 8
scoreboard players set #initial gti.var 2
scoreboard players set #aliases gti.var 1
scoreboard players set #hints_enabled gti.var 1
scoreboard players operation #interval gti.var = #seconds_cfg gti.var
scoreboard players operation #interval gti.var *= #twenty gti.var
tellraw @s {"text":"Preset CHILL zapisany.","color":"#8BE28B"}
function gti:internal/hud
