function gti:ui/cat/all/init
function gti:ui/cat/blocks/init
function gti:ui/cat/equipment/init
function gti:ui/cat/food/init
function gti:ui/cat/mobs/init
function gti:ui/cat/materials/init
function gti:ui/cat/other/init
