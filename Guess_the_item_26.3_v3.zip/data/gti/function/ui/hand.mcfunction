execute unless entity @s[tag=gti.host] run return run tellraw @s {"text":"Tylko gospodarz wybiera hasło.","color":"red"}
execute unless score #state gti.var matches 0 run return run tellraw @s {"text":"Hasło zmienisz między rundami.","color":"yellow"}
execute unless items entity @s weapon.mainhand #gti:answers run return run tellraw @s {"text":"Trzymaj obsługiwany przedmiot w głównej ręce.","color":"yellow"}
data modify storage gti:tmp id set from entity @s SelectedItem.id
data modify storage gti:tmp manual set value 1b
function gti:data/set_fixed
