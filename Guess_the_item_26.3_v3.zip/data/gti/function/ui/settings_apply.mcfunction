$data modify storage gti:tmp args set value {batch:$(batch),limit:$(limit),mode:"$(mode)",initial:$(initial),hints:$(hints)}
execute store result score #batch gti.var run data get storage gti:tmp args.batch
execute store result score #limit gti.var run data get storage gti:tmp args.limit
execute store result score #initial gti.var run data get storage gti:tmp args.initial
execute if score #batch gti.var matches ..0 run scoreboard players set #batch gti.var 1
execute if score #batch gti.var matches 17.. run scoreboard players set #batch gti.var 16
execute if score #initial gti.var matches ..-1 run scoreboard players set #initial gti.var 0
execute if score #initial gti.var matches 33.. run scoreboard players set #initial gti.var 32
execute if score #limit gti.var matches ..-1 run scoreboard players set #limit gti.var 0
scoreboard players set #reveal_mode gti.var 0
execute if data storage gti:tmp args {mode:"error"} run scoreboard players set #reveal_mode gti.var 1
execute if data storage gti:tmp args {mode:"auto"} run scoreboard players set #reveal_mode gti.var 2
scoreboard players set #hints_enabled gti.var 0
execute if data storage gti:tmp args {hints:1b} run scoreboard players set #hints_enabled gti.var 1
scoreboard players operation #interval gti.var = #seconds_cfg gti.var
scoreboard players operation #interval gti.var *= #twenty gti.var
tellraw @s {"text":"✔ Ustawienia zapisane.","color":"green"}
function gti:internal/hud
