execute unless entity @s[tag=gti.host] run return run tellraw @s {"text":"Tylko gospodarz wybiera hasło.","color":"red"}
execute unless score #state gti.var matches 0 run return run tellraw @s {"text":"Hasło zmienisz między rundami.","color":"yellow"}
data remove storage gti:tmp id
$execute if data storage gti:items by_id."$(id)" run data modify storage gti:tmp id set value "$(id)"
$execute if data storage gti:items by_id."minecraft:$(id)" run data modify storage gti:tmp id set value "minecraft:$(id)"
execute unless data storage gti:tmp id run return run tellraw @s {"text":"Nieznany identyfikator. Użyj np. diamond lub minecraft:stone.","color":"red"}
data modify storage gti:tmp manual set value 0b
function gti:data/set_fixed
dialog clear @s
