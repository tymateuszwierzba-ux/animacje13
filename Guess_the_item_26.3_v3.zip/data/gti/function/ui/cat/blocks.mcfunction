data modify storage gti:cat blocks set value []
