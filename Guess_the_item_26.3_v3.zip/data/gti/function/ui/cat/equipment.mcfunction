data modify storage gti:cat equipment set value []
