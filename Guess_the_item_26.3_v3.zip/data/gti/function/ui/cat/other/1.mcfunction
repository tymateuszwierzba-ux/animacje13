data modify storage gti:cat other append value "minecraft:written_book"
data modify storage gti:cat other append value "minecraft:yellow_bundle"
data modify storage gti:cat other append value "minecraft:yellow_harness"
