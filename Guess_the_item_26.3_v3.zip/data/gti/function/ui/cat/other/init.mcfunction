function gti:ui/cat/other
function gti:ui/cat/other/0
function gti:ui/cat/other/1
