function gti:ui/cat/materials
function gti:ui/cat/materials/0
