data modify storage gti:cat other set value []
