data modify storage gti:cat materials set value []
