data modify storage gti:cat food set value []
