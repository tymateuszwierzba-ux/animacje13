function gti:ui/cat/equipment
function gti:ui/cat/equipment/0
