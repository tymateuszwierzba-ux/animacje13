function gti:ui/cat/mobs
function gti:ui/cat/mobs/0
