data modify storage gti:cat mobs set value []
