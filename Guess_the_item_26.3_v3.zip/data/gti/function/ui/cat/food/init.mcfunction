function gti:ui/cat/food
function gti:ui/cat/food/0
