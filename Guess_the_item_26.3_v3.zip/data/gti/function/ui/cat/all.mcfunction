data modify storage gti:cat all set value []
