function gti:internal/defaults
scoreboard players operation #interval gti.var = #seconds_cfg gti.var
scoreboard players operation #interval gti.var *= #twenty gti.var
tellraw @s {"text":"✔ Przywrócono ustawienia domyślne.","color":"green"}
function gti:internal/hud
