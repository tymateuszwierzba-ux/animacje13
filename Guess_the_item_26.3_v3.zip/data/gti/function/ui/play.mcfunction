execute unless score #state gti.var matches 0 run return run tellraw @s {"text":"Runda trwa.","color":"gray"}
execute in minecraft:overworld unless entity @e[tag=gti.anchor] run return run tellraw @s {"text":"Brak planszy — /function gti:setup","color":"red"}
tag @s add gti.player
function gti:internal/start
