execute unless entity @s[tag=gti.host] run return run tellraw @s {"text":"Tylko gospodarz wybiera hasło.","color":"red"}
execute unless score #state gti.var matches 0 run return run tellraw @s {"text":"Hasło zmienisz między rundami.","color":"yellow"}
scoreboard players set #source gti.var 0
data modify storage gti:tmp msg set value "Hasło: losowane z pełnej puli."
function gti:visual/event with storage gti:tmp
tellraw @s {"text":"✔ Hasło będzie losowane.","color":"green"}
