execute if score #summary_ready gti.var matches 1 run function gti:internal/summary
execute unless score #summary_ready gti.var matches 1 run dialog show @s gti:summary
