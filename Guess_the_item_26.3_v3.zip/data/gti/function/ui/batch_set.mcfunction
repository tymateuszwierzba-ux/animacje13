$scoreboard players set #batch gti.var $(value)
function gti:internal/hud
