execute unless entity @s[type=player] run return 0
execute unless entity @s[tag=gti.host] run return run tellraw @s {"text":"Pauzę może włączyć gospodarz.","color":"red"}
execute unless score #state gti.var matches 2 run return run tellraw @s {"text":"Pauza działa tylko w trakcie rundy.","color":"gray"}
execute if score #paused gti.var matches 0 run scoreboard players set #paused gti.var 1
execute if score #paused gti.var matches 1 run scoreboard players set #paused gti.var 0
execute if score #paused gti.var matches 1 run tellraw @a[tag=gti.player] {"text":"⏸ Runda wstrzymana.","color":"yellow"}
execute if score #paused gti.var matches 0 run tellraw @a[tag=gti.player] {"text":"▶ Runda wznowiona.","color":"green"}
execute if score #paused gti.var matches 1 run title @a[tag=gti.player] actionbar [{"text":"⏸ PAUZA","color":"yellow","bold":true}]
execute if score #paused gti.var matches 0 run title @a[tag=gti.player] actionbar [{"text":"▶ WZNOWIONO","color":"green","bold":true}]
function gti:internal/hud
