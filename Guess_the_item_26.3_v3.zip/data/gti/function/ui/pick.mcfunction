execute unless score #state gti.var matches 0 run return run tellraw @s {"text":"Hasło zmienisz między rundami.","color":"yellow"}
scoreboard players operation #pick gti.var = @s gti.pick
scoreboard players remove #pick gti.var 1
scoreboard players operation #cat gti.var = #pick gti.var
scoreboard players operation #cat gti.var /= #tenk gti.var
scoreboard players operation #idx gti.var = #pick gti.var
scoreboard players operation #idx gti.var %= #tenk gti.var
execute store result storage gti:tmp index int 1 run scoreboard players get #idx gti.var
data modify storage gti:tmp cat set value "all"
execute if score #cat gti.var matches 1 run data modify storage gti:tmp cat set value "blocks"
execute if score #cat gti.var matches 2 run data modify storage gti:tmp cat set value "equipment"
execute if score #cat gti.var matches 3 run data modify storage gti:tmp cat set value "food"
execute if score #cat gti.var matches 4 run data modify storage gti:tmp cat set value "mobs"
execute if score #cat gti.var matches 5 run data modify storage gti:tmp cat set value "materials"
execute if score #cat gti.var matches 6 run data modify storage gti:tmp cat set value "other"
execute unless data storage gti:cat all run function gti:ui/cat/all/init
function gti:ui/pick_lookup with storage gti:tmp
data modify storage gti:tmp manual set value 0b
function gti:data/set_fixed
dialog clear @s
