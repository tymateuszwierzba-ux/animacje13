function gti:ui/settings
