function gti:ui/menu
