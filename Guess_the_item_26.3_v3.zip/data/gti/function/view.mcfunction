execute unless entity @s[type=player] run return 0
execute in minecraft:overworld unless entity @e[tag=gti.anchor] run return run tellraw @s {"text":"Brak planszy — /function gti:setup","color":"red"}
tp @s ~ ~ ~ 180 -17
tag @s add gti.player
