execute unless entity @s[type=player] run return 0
execute in minecraft:overworld unless entity @e[tag=gti.anchor] run return run tellraw @s {"text":"Najpierw /function gti:setup.","color":"red"}
execute unless score #state gti.var matches 0 run return run tellraw @s {"text":"Runda trwa. /function gti:stop ją przerwie.","color":"red"}
tag @s add gti.player
execute at @e[tag=gti.anchor,limit=1] run tag @a[distance=..64] add gti.player
execute at @e[tag=gti.anchor,limit=1] run function gti:internal/start
