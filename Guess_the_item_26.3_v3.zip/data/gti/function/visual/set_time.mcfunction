$data modify storage gti:ui time set value "$(mm0)$(mins):$(ss0)$(secs)"
