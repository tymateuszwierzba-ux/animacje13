execute as @e[tag=gti.halo] run data modify entity @s transformation.scale set value [0.01f,0.01f,0.001f]
scoreboard players set #halo gti.var 0
