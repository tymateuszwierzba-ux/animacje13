scoreboard players add #halo gti.var 1
scoreboard players operation #halo gti.var %= #halo_max gti.var
execute store result storage gti:fx frame int 1 run scoreboard players get #halo gti.var
function gti:visual/halo_pick with storage gti:fx
function gti:visual/halo_apply
