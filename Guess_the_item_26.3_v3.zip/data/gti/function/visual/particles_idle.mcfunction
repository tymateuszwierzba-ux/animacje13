execute at @e[tag=gti.anchor,limit=1] run particle minecraft:electric_spark ~ ~ ~0.5 9.8 9.8 0.3 0.01 4 force @a[tag=gti.player]
execute at @e[tag=gti.anchor,limit=1] run particle minecraft:end_rod ~ ~9.8 ~0.4 9.5 0.2 0.05 0.003 2 force @a[tag=gti.player]
