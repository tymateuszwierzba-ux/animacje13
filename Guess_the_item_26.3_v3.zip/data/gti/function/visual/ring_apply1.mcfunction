$execute at @e[tag=gti.anchor,limit=1] run tp @e[tag=gti.run1,limit=1] ~$(x) ~$(y) ~0.58
