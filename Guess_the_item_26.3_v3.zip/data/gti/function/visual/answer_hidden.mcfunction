data modify entity @e[tag=gti.hud.answer,limit=1] text set value [{"text":"ODPOWIEDŹ UKRYTA","color":"#8FA8C8"}]
