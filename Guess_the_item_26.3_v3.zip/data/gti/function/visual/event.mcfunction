$data modify entity @e[tag=gti.hud.event,limit=1] text set value [{"text":"$(msg)","color":"#8FA8C8"}]
