scoreboard players add #bob gti.var 1
scoreboard players operation #bob gti.var %= #eight gti.var
execute store result storage gti:fx frame int 1 run scoreboard players get #bob gti.var
function gti:visual/bob_pick with storage gti:fx
function gti:visual/bob_apply
