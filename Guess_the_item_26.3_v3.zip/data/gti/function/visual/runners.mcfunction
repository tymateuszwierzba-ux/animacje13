scoreboard players add #run0 gti.var 1
scoreboard players operation #run1 gti.var = #run0 gti.var
scoreboard players add #run1 gti.var 40
scoreboard players operation #run0 gti.var %= #eighty gti.var
scoreboard players operation #run1 gti.var %= #eighty gti.var
execute store result storage gti:fx frame int 1 run scoreboard players get #run0 gti.var
function gti:visual/ring_pick with storage gti:fx
function gti:visual/ring_apply0 with storage gti:fx args
execute store result storage gti:fx frame int 1 run scoreboard players get #run1 gti.var
function gti:visual/ring_pick with storage gti:fx
function gti:visual/ring_apply1 with storage gti:fx args
