scoreboard players add #sway gti.var 1
scoreboard players operation #sway gti.var %= #twelve gti.var
execute store result storage gti:fx frame int 1 run scoreboard players get #sway gti.var
function gti:visual/sway_pick with storage gti:fx
function gti:visual/sway_apply
