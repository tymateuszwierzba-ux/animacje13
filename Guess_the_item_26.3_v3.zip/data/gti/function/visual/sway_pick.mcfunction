$data modify storage gti:fx quat set from storage gti:fx sway[$(frame)]
