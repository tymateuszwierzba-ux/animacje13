$data modify storage gti:fx bobargs set from storage gti:fx bob[$(frame)]
