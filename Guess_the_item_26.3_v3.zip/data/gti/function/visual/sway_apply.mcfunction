data modify entity @e[tag=gti.item,limit=1] transformation.left_rotation set from storage gti:fx quat
