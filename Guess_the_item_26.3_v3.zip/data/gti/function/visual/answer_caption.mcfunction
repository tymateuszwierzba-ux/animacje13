$data modify entity @e[tag=gti.hud.answer,limit=1] text set value [{"text":"ODPOWIEDŹ: ","color":"#8FA8C8","bold":true},{"translate":"$(key)","color":"#F6CF84","bold":true}]
