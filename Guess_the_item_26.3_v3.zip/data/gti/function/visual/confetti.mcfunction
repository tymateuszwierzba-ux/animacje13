execute at @e[tag=gti.anchor,limit=1] run particle minecraft:firework ~ ~10.5 ~0.9 9.5 2.5 0.4 0.2 90 force @a[tag=gti.player]
execute at @e[tag=gti.anchor,limit=1] run particle minecraft:crit ~ ~8 ~0.9 9.5 4 0.4 0.08 45 force @a[tag=gti.player]
execute at @e[tag=gti.anchor,limit=1] run particle minecraft:happy_villager ~ ~6 ~0.9 9 3.5 0.4 0.03 25 force @a[tag=gti.player]
execute at @e[tag=gti.anchor,limit=1] run particle minecraft:electric_spark ~ ~11 ~0.9 10 1 0.2 0.1 25 force @a[tag=gti.player]
