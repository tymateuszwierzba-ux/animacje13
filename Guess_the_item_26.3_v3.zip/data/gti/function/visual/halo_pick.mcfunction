$data modify storage gti:fx args set from storage gti:fx halo[$(frame)]
