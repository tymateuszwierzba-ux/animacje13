execute unless score #state gti.var matches 2..3 run function gti:visual/scan
execute if score #state gti.var matches 0..2 run function gti:visual/runners
execute if score #state gti.var matches 3 run function gti:visual/finale_fx
execute if score #clock gti.var matches 0 unless score #state gti.var matches 1 run function gti:visual/sway
