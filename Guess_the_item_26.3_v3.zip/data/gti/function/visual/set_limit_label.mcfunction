$data modify storage gti:ui limit_label set value "$(limit)"
