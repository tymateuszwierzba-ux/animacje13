scoreboard players add #scan gti.var 3
execute if score #scan gti.var matches 200.. run scoreboard players set #scan gti.var 0
scoreboard players operation #scan_y gti.var = #scan gti.var
execute if score #scan gti.var matches 101.. run scoreboard players set #scan_y gti.var 200
execute if score #scan gti.var matches 101.. run scoreboard players operation #scan_y gti.var -= #scan gti.var
scoreboard players operation #scan_y gti.var *= #ten gti.var
scoreboard players remove #scan_y gti.var 1000
execute store result entity @e[tag=gti.scan,limit=1] transformation.translation[1] float 0.01 run scoreboard players get #scan_y gti.var
