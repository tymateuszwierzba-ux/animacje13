scoreboard players set #filled gti.var 10
execute if score #limit gti.var matches 1.. run scoreboard players operation #filled gti.var = #remaining gti.var
execute if score #limit gti.var matches 1.. run scoreboard players operation #filled gti.var *= #ten gti.var
execute if score #limit gti.var matches 1.. run scoreboard players operation #filled gti.var /= #limit gti.var
execute if score #filled gti.var matches 11.. run scoreboard players set #filled gti.var 10
execute if score #filled gti.var matches ..-1 run scoreboard players set #filled gti.var 0
execute if score #filled gti.var matches 1.. run data modify entity @e[tag=gti.budgetseg,scores={gti.id=0},limit=1] block_state.Name set value "minecraft:lime_concrete"
execute if score #filled gti.var matches ..0 run data modify entity @e[tag=gti.budgetseg,scores={gti.id=0},limit=1] block_state.Name set value "minecraft:black_concrete"
execute if score #filled gti.var matches 2.. run data modify entity @e[tag=gti.budgetseg,scores={gti.id=1},limit=1] block_state.Name set value "minecraft:lime_concrete"
execute if score #filled gti.var matches ..1 run data modify entity @e[tag=gti.budgetseg,scores={gti.id=1},limit=1] block_state.Name set value "minecraft:black_concrete"
execute if score #filled gti.var matches 3.. run data modify entity @e[tag=gti.budgetseg,scores={gti.id=2},limit=1] block_state.Name set value "minecraft:lime_concrete"
execute if score #filled gti.var matches ..2 run data modify entity @e[tag=gti.budgetseg,scores={gti.id=2},limit=1] block_state.Name set value "minecraft:black_concrete"
execute if score #filled gti.var matches 4.. run data modify entity @e[tag=gti.budgetseg,scores={gti.id=3},limit=1] block_state.Name set value "minecraft:yellow_concrete"
execute if score #filled gti.var matches ..3 run data modify entity @e[tag=gti.budgetseg,scores={gti.id=3},limit=1] block_state.Name set value "minecraft:black_concrete"
execute if score #filled gti.var matches 5.. run data modify entity @e[tag=gti.budgetseg,scores={gti.id=4},limit=1] block_state.Name set value "minecraft:yellow_concrete"
execute if score #filled gti.var matches ..4 run data modify entity @e[tag=gti.budgetseg,scores={gti.id=4},limit=1] block_state.Name set value "minecraft:black_concrete"
execute if score #filled gti.var matches 6.. run data modify entity @e[tag=gti.budgetseg,scores={gti.id=5},limit=1] block_state.Name set value "minecraft:yellow_concrete"
execute if score #filled gti.var matches ..5 run data modify entity @e[tag=gti.budgetseg,scores={gti.id=5},limit=1] block_state.Name set value "minecraft:black_concrete"
execute if score #filled gti.var matches 7.. run data modify entity @e[tag=gti.budgetseg,scores={gti.id=6},limit=1] block_state.Name set value "minecraft:orange_concrete"
execute if score #filled gti.var matches ..6 run data modify entity @e[tag=gti.budgetseg,scores={gti.id=6},limit=1] block_state.Name set value "minecraft:black_concrete"
execute if score #filled gti.var matches 8.. run data modify entity @e[tag=gti.budgetseg,scores={gti.id=7},limit=1] block_state.Name set value "minecraft:orange_concrete"
execute if score #filled gti.var matches ..7 run data modify entity @e[tag=gti.budgetseg,scores={gti.id=7},limit=1] block_state.Name set value "minecraft:black_concrete"
execute if score #filled gti.var matches 9.. run data modify entity @e[tag=gti.budgetseg,scores={gti.id=8},limit=1] block_state.Name set value "minecraft:red_concrete"
execute if score #filled gti.var matches ..8 run data modify entity @e[tag=gti.budgetseg,scores={gti.id=8},limit=1] block_state.Name set value "minecraft:black_concrete"
execute if score #filled gti.var matches 10.. run data modify entity @e[tag=gti.budgetseg,scores={gti.id=9},limit=1] block_state.Name set value "minecraft:red_concrete"
execute if score #filled gti.var matches ..9 run data modify entity @e[tag=gti.budgetseg,scores={gti.id=9},limit=1] block_state.Name set value "minecraft:black_concrete"
