scoreboard players add #pulse gti.var 1
scoreboard players operation #pulse gti.var %= #two gti.var
execute if score #pulse gti.var matches 0 as @e[tag=gti.pulse.b] run data modify entity @s block_state.Name set value "minecraft:purple_concrete"
execute if score #pulse gti.var matches 1 as @e[tag=gti.pulse.b] run data modify entity @s block_state.Name set value "minecraft:magenta_concrete"
execute if score #pulse gti.var matches 0 as @e[tag=gti.pulse.c] run data modify entity @s block_state.Name set value "minecraft:cyan_concrete"
execute if score #pulse gti.var matches 1 as @e[tag=gti.pulse.c] run data modify entity @s block_state.Name set value "minecraft:light_blue_concrete"
