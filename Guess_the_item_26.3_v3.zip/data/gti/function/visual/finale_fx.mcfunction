execute if score #result gti.var matches 1 run function gti:visual/halo
execute if score #result gti.var matches 1 if score #anim gti.var matches 30 run function gti:visual/confetti
execute if score #result gti.var matches 1 if score #anim gti.var matches 55 run function gti:visual/confetti
execute if score #result gti.var matches 1 if score #anim gti.var matches 80 run function gti:visual/confetti
