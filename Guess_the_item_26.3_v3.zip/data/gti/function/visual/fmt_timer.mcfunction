$data modify storage gti:ui timer_label set value "AUTO • $(timer_seconds)s"
