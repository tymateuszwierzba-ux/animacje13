execute unless entity @s[type=player] run return run tellraw @a {"text":"Setup uruchom jako gracz.","color":"red"}
execute unless dimension minecraft:overworld run return run tellraw @s {"text":"Planszę zbuduj w Overworldzie.","color":"red"}
function gti:remove
execute align xyz positioned ~ ~11 ~-30 run function gti:internal/build
tp @s ~ ~ ~ 180 -17
tag @a remove gti.host
tag @s add gti.host
tag @s add gti.player
scoreboard players set #state gti.var 0
scoreboard players set #result gti.var 2
scoreboard players set #round gti.var 0
execute at @e[tag=gti.anchor,limit=1] run function gti:internal/hud
execute at @e[tag=gti.anchor,limit=1] run function gti:visual/particles_idle
tellraw @s [{"text":"Plansza gotowa. ","color":"#8BE28B"},{"text":"/function gti:start","color":"#61EDE5","click_event":{"action":"run_command","command":"function gti:start"}},{"text":" lub wybierz ruch w panelu.","color":"gray"}]
dialog show @s gti:menu
