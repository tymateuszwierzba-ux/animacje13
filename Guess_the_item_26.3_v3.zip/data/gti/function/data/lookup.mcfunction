$data modify storage gti:ctx meta set from storage gti:items by_id."$(id)"
data modify storage gti:cfg meta set from storage gti:ctx meta
data modify storage gti:cfg answer_key set from storage gti:ctx meta.key
execute store result score #eq_answer gti.var run data get storage gti:ctx meta.eq
execute store result score #hint_cat gti.var run data get storage gti:ctx meta.cat
