function gti:data/random_index
function gti:data/pick with storage gti:ctx
data modify storage gti:cfg answer set from storage gti:ctx id
function gti:data/lookup with storage gti:ctx
function gti:data/apply with storage gti:ctx
