scoreboard players set #hint_stage gti.var 0
scoreboard players set #eq_answer gti.var -1
data modify storage gti:cfg hint set value "BRAK PODPOWIEDZI"
execute if score #source gti.var matches 0 run function gti:data/random_answer
execute if score #source gti.var matches 1 run function gti:data/fixed_answer
