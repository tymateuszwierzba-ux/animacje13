data modify storage gti:ctx id set from storage gti:config fixed.id
function gti:data/lookup with storage gti:ctx
data modify storage gti:cfg answer set from storage gti:config fixed.id
data modify entity @e[tag=gti.item,limit=1] item set from storage gti:config fixed
execute as @e[tag=gti.item] run data modify entity @s transformation set value {scale:[20f,20f,0.001f],translation:[0f,0f,0f],left_rotation:[0f,1f,0f,0f],right_rotation:[0f,0f,0f,1f]}
