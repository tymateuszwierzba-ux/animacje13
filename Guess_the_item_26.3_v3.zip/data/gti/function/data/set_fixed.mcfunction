scoreboard players set #source gti.var 1
data modify storage gti:config fixed.id set from storage gti:tmp id
data modify storage gti:config fixed.count set value 1
data modify storage gti:tmp msg set value ""
execute if data storage gti:tmp {manual:1b} run data modify storage gti:tmp msg set value "Ustawiono hasło z ręki."
execute if data storage gti:tmp {manual:0b} run data modify storage gti:tmp msg set value "Ustawiono hasło z katalogu."
function gti:visual/event with storage gti:tmp
tellraw @s [{"text":"✔ ","color":"#8BE28B"},{"nbt":"msg","storage":"gti:tmp","color":"#F2F7FF"},{"text":" Hasło: ","color":"gray"},{"nbt":"id","storage":"gti:tmp","color":"#61EDE5"}]
