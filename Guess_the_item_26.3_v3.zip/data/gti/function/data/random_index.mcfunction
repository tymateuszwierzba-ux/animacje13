execute store result score #random gti.var run random value 0..1656
scoreboard players operation #random gti.var %= #data_count gti.var
scoreboard players add #random gti.var 1
execute if score #random gti.var = #last_index gti.var run scoreboard players add #random gti.var 1
execute if score #random gti.var > #data_count gti.var run scoreboard players set #random gti.var 1
scoreboard players operation #last_index gti.var = #random gti.var
scoreboard players remove #random gti.var 1
execute store result storage gti:ctx index int 1 run scoreboard players get #random gti.var
