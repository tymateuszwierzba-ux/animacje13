function gti:ui/random
