function gti:ui/stats
