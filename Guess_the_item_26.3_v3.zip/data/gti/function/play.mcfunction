function gti:ui/play
