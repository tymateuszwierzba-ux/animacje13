execute in minecraft:overworld run kill @e[tag=gti.entity]
scoreboard players set #state gti.var 0
scoreboard players set #result gti.var 2
scoreboard players set #paused gti.var 0
scoreboard players set #halo gti.var 0
bossbar set gti:budget visible false
bossbar set gti:timer visible false
tag @a remove gti.player
tag @a remove gti.host
dialog clear @a
tellraw @s {"text":"Plansza i efekty usunięte.","color":"gray"}
