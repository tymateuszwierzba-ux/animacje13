execute unless score #state gti.var matches 0 run return run tellraw @s {"text":"Zmień tryb między rundami.","color":"red"}
scoreboard players set #limit gti.var 48
tellraw @a[tag=gti.player] {"text":"Tryb: HARD • 48",color:"#61EDE5"}
function gti:internal/hud
