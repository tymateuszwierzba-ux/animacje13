function gti:internal/stop
