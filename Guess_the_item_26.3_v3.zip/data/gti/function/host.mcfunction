tag @a remove gti.host
tag @s add gti.host
function gti:ui/host
