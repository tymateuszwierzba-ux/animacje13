scoreboard players add #clock gti.var 1
execute if score #clock gti.var matches 4.. run scoreboard players set #clock gti.var 0
scoreboard players add #ab_clock gti.var 1
execute if score #ab_clock gti.var matches 10.. run scoreboard players set #ab_clock gti.var 0
execute as @a[scores={gti.menu=1..}] at @s run function gti/ui/menu
scoreboard players set @a[scores={gti.menu=1..}] gti.menu 0
scoreboard players enable @a gti.menu
execute as @a[scores={gti.play=1..}] at @s run function gti/ui/play
scoreboard players set @a[scores={gti.play=1..}] gti.play 0
scoreboard players enable @a gti.play
execute as @a[scores={gti.pixel=1..}] at @s run function gti/internal/pixel_request
scoreboard players set @a[scores={gti.pixel=1..}] gti.pixel 0
scoreboard players enable @a gti.pixel
execute as @a[scores={gti.guess=1..}] at @s run function gti/internal/guess_request
scoreboard players set @a[scores={gti.guess=1..}] gti.guess 0
scoreboard players enable @a gti.guess
execute as @a[scores={gti.hint=1..}] at @s run function gti/internal/hint_request
scoreboard players set @a[scores={gti.hint=1..}] gti.hint 0
scoreboard players enable @a gti.hint
execute as @a[scores={gti.next=1..}] at @s run function gti/internal/next
scoreboard players set @a[scores={gti.next=1..}] gti.next 0
scoreboard players enable @a gti.next
execute as @a[scores={gti.stats=1..}] at @s run function gti/ui/stats
scoreboard players set @a[scores={gti.stats=1..}] gti.stats 0
scoreboard players enable @a gti.stats
execute as @a[scores={gti.settings=1..}] at @s run function gti/ui/settings
scoreboard players set @a[scores={gti.settings=1..}] gti.settings 0
scoreboard players enable @a gti.settings
execute as @a[scores={gti.browser=1..}] at @s run function gti/ui/browser
scoreboard players set @a[scores={gti.browser=1..}] gti.browser 0
scoreboard players enable @a gti.browser
execute as @a[scores={gti.hand=1..}] at @s run function gti/ui/hand
scoreboard players set @a[scores={gti.hand=1..}] gti.hand 0
scoreboard players enable @a gti.hand
execute as @a[scores={gti.random=1..}] at @s run function gti/ui/random
scoreboard players set @a[scores={gti.random=1..}] gti.random 0
scoreboard players enable @a gti.random
execute as @a[scores={gti.stop=1..}] at @s run function gti/internal/stop
scoreboard players set @a[scores={gti.stop=1..}] gti.stop 0
scoreboard players enable @a gti.stop
execute as @a[scores={gti.hostmenu=1..}] at @s run function gti/ui/host
scoreboard players set @a[scores={gti.hostmenu=1..}] gti.hostmenu 0
scoreboard players enable @a gti.hostmenu
execute as @a[scores={gti.pick=1..}] at @s run function gti/ui/pick
scoreboard players set @a[scores={gti.pick=1..}] gti.pick 0
scoreboard players enable @a gti.pick
execute as @a[scores={gti.pause=1..}] at @s run function gti/ui/pause_click
scoreboard players set @a[scores={gti.pause=1..}] gti.pause 0
scoreboard players enable @a gti.pause
execute as @a[scores={gti.summary=1..}] at @s run function gti/ui/summary
scoreboard players set @a[scores={gti.summary=1..}] gti.summary 0
scoreboard players enable @a gti.summary
execute as @e[tag=gti.control] at @s if data entity @s interaction run function gti:internal/control_event
execute as @e[tag=gti.pixel,tag=!gti.open] at @s if data entity @s interaction run function gti:internal/pixel_event
execute as @e[tag=gti.pixel,tag=!gti.open] at @s if data entity @s attack run function gti:internal/pixel_attack
scoreboard players add @e[tag=gti.fx] gti.age 1
kill @e[tag=gti.fx,scores={gti.age=8..}]
execute in minecraft:overworld at @e[tag=gti.anchor,limit=1] run function gti:internal/tick
