# GUESS THE ITEM 3.0
### HOLO-PLANSZA • DIALOG GUI • Minecraft Java 26.3

Zgadnij ukryty przedmiot po fragmentach jego ikony. **1657 przedmiotów**, animowana
holograficzna plansza 16×16, osiem ekranów GUI, katalog wszystkich ID, podpowiedzi,
budżet punktów i trzy tryby odkrywania. Bez modów, pluginów i resource packa.

## Co nowego względem 2.0

- **Holograficzna plansza 3D** — rama z neonów, narożne klejnoty, animowany skaner,
  dwa świetliki krążące po obwodzie, unoszące się litery tytułu.
- **Prawdziwe animacje** — migawka (shutter), fala kolorów na kafelkach, wielkie
  odliczanie 3–2–1, fajerwerki i konfetti na koniec, pierścień gwiazd w finale.
- **Nowy panel gry** — sześć liczników, pasek budżetu, pasek postępu, cztery przyciski
  z ikonami i podpowiedzią pod ręką.
- **Więcej GUI** — menu, panel gospodarza, formularz ustawień z suwakami, zasady,
  statystyki, katalog (kategorie + strony), wpisywanie ID, dynamiczne podsumowanie rundy.
- **Podpowiedzi** — kategoria, długość i pierwsza litera, wzór nazwy.
- **Budżet punktów** z paskiem i bossbarem, tryb AUTO z bossbarem odliczania.
- **Statystyki i rekordy** — wygrane, rekord, seria, liczba prób, celność.

## Instalacja

1. Włóż ZIP (bez rozpakowywania) do:
   - singleplayer: `.minecraft/saves/NAZWA_ŚWIATA/datapacks/`
   - serwer: `NAZWA_ŚWIATA/datapacks/`
2. W Overworldzie znajdź duże otwarte miejsce i wpisz jako operator:
   ```mcfunction
   /reload
   /function gti:setup
   ```
3. Plansza pojawi się 30 klocków przed Tobą, 11 klocków nad ziemią. Kamera obróci się w jej stronę.
4. Wybierz hasło i ustawienia, potem **Rozpocznij rundę** w panelu gospodarza.

`/function gti:remove` usuwa planszę i wszystkie efekty. `/function gti:view` ustawia kamerę.

## Sterowanie

| Akcja | Jak |
|---|---|
| Odsłoń paczkę wokół klikniętego pola | LPM / PPM na kafelku |
| Odsłoń paczkę losowo | przycisk **ODKRYJ** lub `/trigger gti.pixel set 1` |
| Zgadnij | przedmiot w głównej ręce + **ZGADUJ** lub `/trigger gti.guess set 1` |
| Podpowiedź | **PODPOWIEDŹ** lub `/trigger gti.hint set 1` |
| Menu | **MENU**, `/trigger gti.menu` lub `/dialog show @s gti:menu` |
| Nowa runda | `/trigger gti.next set 1` lub `/function gti:start` |
| Stop | `/function gti:stop` |
| Pauza | przycisk **II** w panelu (gospodarz) |

Każdy gracz w promieniu 64 klocków od planszy jest widzem i może zgadywać.

## Punktacja

- Odkryty piksel: **1 punkt**.
- Błędna odpowiedź: **4 punkty** oraz licznik prób.
- Podpowiedź: **8 punktów**.
- Budżet ustawiasz suwakiem; 0 = brak limitu.
- Wygrywa mniej prób; przy remisie mniej odkrytych pikseli. Rekord gracza to
  `próby × 1000 + piksele` — mniejszy jest lepszy.
- Przedmioty z tej samej grupy (np. `copper_block` i `waxed_copper_block`,
  `stone_bricks` i `infested_stone_bricks`) są równoważne.

## Katalog

Katalog zawiera wszystkie 1657 ID w kategoriach:

- **BLOKI I BUDOWANIE** — 1134
- **BROŃ, NARZĘDZIA, PANCERZ** — 95
- **JEDZENIE I ROŚLINY** — 52
- **MOBY I JAJKA** — 94
- **SUROWCE I SKŁADNIKI** — 79
- **POZOSTAŁE PRZEDMIOTY** — 203

Strony mają po 24 pozycje. Kliknięcie nazwy ustawia stałe hasło na następną rundę.
Nazwy są tłumaczone przez klienta; identyfikator jest w podpowiedzi.

## Komendy

```mcfunction
/function gti:setup            # zbuduj planszę
/function gti:remove           # usuń wszystko
/function gti:view             # popraw kamerę
/function gti:start | gti:stop
/function gti:mode/chill | easy | normal | hard
/function gti:preset/chill | normal | hard
/function gti:ui/menu | host | settings | stats | browser
/dialog show @s gti:menu
```

## Kompatybilność

- **Java 26.3**, data pack format `121.0`.
- Wymaga cheats/uprawnień operatora do budowy planszy i formularzy.
- Pakiety dla 1.21.11, 26.2 i 26.3 mają identyczną mechanikę i różnią się listą przedmiotów
  oraz formatem packa.

## Uwagi

- Plansza jest w pełni świetlista, więc działa też nocą i pod ziemią.
- Dialogi nie zatrzymują świata (`pause:false`), dzięki czemu runda działa w tle.
- Pierwsze `/reload` ładuje 1657 przedmiotów do pamięci gry (jednorazowo).
- Nie instaluj jednocześnie kilku wersji tego packa — używają tej samej przestrzeni nazw `gti`.

Miłej gry!
