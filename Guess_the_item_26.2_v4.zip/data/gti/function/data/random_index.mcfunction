execute store result score #random gti.var run random value 0..1535
scoreboard players operation #random gti.var %= #data_count gti.var
execute store result storage gti:tmp index int 1 run scoreboard players get #random gti.var
