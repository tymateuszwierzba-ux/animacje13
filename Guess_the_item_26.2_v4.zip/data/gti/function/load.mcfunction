scoreboard objectives add gti_next trigger
scoreboard objectives add gti_reveal trigger
scoreboard objectives add gti_guess trigger
scoreboard objectives add gti_hint trigger
scoreboard objectives add gti_menu trigger
scoreboard objectives add gti_host trigger
scoreboard objectives add gti_settings trigger
scoreboard objectives add gti_stats trigger
scoreboard objectives add gti_browse trigger
scoreboard objectives add gti_summary trigger
scoreboard objectives add gti_rules trigger
scoreboard objectives add gti_stop trigger
scoreboard objectives add gti_hand trigger
scoreboard objectives add gti_random trigger
scoreboard objectives add gti_pick trigger
scoreboard objectives add gti_easy trigger
scoreboard objectives add gti_normal trigger
scoreboard objectives add gti_hard trigger
scoreboard objectives add gti_default trigger
scoreboard objectives add gti.var dummy
scoreboard objectives add gti.id dummy
scoreboard objectives add gti.age dummy
scoreboard objectives add gti.wins dummy
scoreboard objectives add gti.best dummy
scoreboard objectives add gti.tries dummy
scoreboard objectives add gti.rounds dummy
scoreboard objectives add gti.streak dummy
scoreboard objectives add gti.best_streak dummy
bossbar add gti:timer {"text":"TIME LEFT","color":"red"}
execute unless score #data_ver gti.var matches 4 run function gti:init
scoreboard players set #data_ver gti.var 4
function gti:init/fast
tellraw @a [{"text":"[Guess the Item] ","color":"#45E9E0","bold":true},{"text":"4.0  •  26.2  •  1536 items","color":"gray"}]
tellraw @a [{"text":"/function gti:setup","color":"#61EDE5","click_event":{"action":"suggest_command","command":"/function gti:setup"}},{"text":"   •   ","color":"dark_gray"},{"text":"/function gti:menu","color":"#F47BC6","click_event":{"action":"run_command","command":"function gti:menu"}},{"text":"  (dialogs without OP use /trigger gti_menu)","color":"gray"}]
