function gti:view
