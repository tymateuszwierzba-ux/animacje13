function gti:remove
