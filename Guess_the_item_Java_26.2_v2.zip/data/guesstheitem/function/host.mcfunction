function gti:host
