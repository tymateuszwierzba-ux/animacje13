function gti:stop
