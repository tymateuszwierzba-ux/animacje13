function gti:setup
