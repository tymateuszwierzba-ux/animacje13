function gti:ui/hostmenu
