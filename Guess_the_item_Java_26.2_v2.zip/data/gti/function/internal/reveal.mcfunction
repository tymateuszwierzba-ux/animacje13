execute unless score #state gti.var matches 2 run return 0
execute if entity @s[tag=gti.open] run return 0
tag @s add gti.open
data remove entity @s interaction
data remove entity @s attack
scoreboard players add #pixels gti.var 1
scoreboard players add #cost gti.var 1
execute store result storage gti:ctx id int 1 run scoreboard players get @s gti.id
function gti:internal/shrink with storage gti:ctx
particle minecraft:electric_spark ~ ~.5 ~.1 .2 .2 .01 0.03 8 force @a[tag=gti.player]
execute as @a[tag=gti.player] at @s run playsound minecraft:block.amethyst_block.hit master @s ~ ~ ~ 0.6 1.5
function gti:internal/hud
execute if score #limit gti.var matches 1.. if score #cost gti.var >= #limit gti.var run function gti:internal/lose
