execute if entity @s[tag=gti.control.pixel] on target run function gti:internal/pixel_request
execute if entity @s[tag=gti.control.guess] on target run function gti:internal/guess_request
execute if entity @s[tag=gti.control.menu] on target run function gti:help
data remove entity @s interaction
