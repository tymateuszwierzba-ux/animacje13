execute if score #source gti.var matches 0 run function gti:internal/random
execute if score #source gti.var matches 1 run data modify entity @e[tag=gti.item,limit=1] item set from storage gti:config fixed
