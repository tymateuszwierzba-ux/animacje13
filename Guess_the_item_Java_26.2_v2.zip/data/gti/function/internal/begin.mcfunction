scoreboard players set #state gti.var 2
title @a[tag=gti.player] subtitle {"text":"Odkrywaj piksele • podaj przedmiot w ręce","color":"gray"}
title @a[tag=gti.player] title {"text":"ZGADUJ!","color":"green"}
execute as @a[tag=gti.player] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.65 1.4
tellraw @a[tag=gti.player] {"text":"[ Otwórz panel gry ]","color":"aqua","click_event":{"action":"show_dialog","dialog":"gti:menu"}}
execute store result storage gti:ctx batch int 1 run scoreboard players get #initial gti.var
execute if score #initial gti.var matches 1.. run function gti:internal/batch_random with storage gti:ctx
function gti:internal/hud
