scoreboard players add #wrong gti.var 1
scoreboard players add #cost gti.var 4
title @s times 2 22 8
title @s subtitle {"text":"−4 punkty • spróbuj ponownie","color":"gray"}
title @s title {"text":"NIE TEN ITEM","color":"red"}
execute at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.7 0.6
execute at @e[tag=gti.anchor,limit=1] run particle minecraft:dust{color:[1.0,0.1,0.15],scale:1.4} ~ ~ ~.5 5 5 .1 0 65 force @a[tag=gti.player]
function gti:internal/hud
execute if score #limit gti.var matches 1.. if score #cost gti.var >= #limit gti.var run function gti:internal/lose
execute if score #state gti.var matches 2 if score #reveal_mode gti.var matches 1 at @e[tag=gti.anchor,limit=1] run function gti:internal/auto_batch
