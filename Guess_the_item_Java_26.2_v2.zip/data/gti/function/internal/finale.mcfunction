scoreboard players add #anim gti.var 1
execute if score #anim gti.var matches 1 as @e[tag=gti.mask,tag=gti.col0,tag=!gti.fade] run function gti:internal/final_shrink
execute if score #anim gti.var matches 3 as @e[tag=gti.mask,tag=gti.col1,tag=!gti.fade] run function gti:internal/final_shrink
execute if score #anim gti.var matches 5 as @e[tag=gti.mask,tag=gti.col2,tag=!gti.fade] run function gti:internal/final_shrink
execute if score #anim gti.var matches 7 as @e[tag=gti.mask,tag=gti.col3,tag=!gti.fade] run function gti:internal/final_shrink
execute if score #anim gti.var matches 9 as @e[tag=gti.mask,tag=gti.col4,tag=!gti.fade] run function gti:internal/final_shrink
execute if score #anim gti.var matches 11 as @e[tag=gti.mask,tag=gti.col5,tag=!gti.fade] run function gti:internal/final_shrink
execute if score #anim gti.var matches 13 as @e[tag=gti.mask,tag=gti.col6,tag=!gti.fade] run function gti:internal/final_shrink
execute if score #anim gti.var matches 15 as @e[tag=gti.mask,tag=gti.col7,tag=!gti.fade] run function gti:internal/final_shrink
execute if score #anim gti.var matches 17 as @e[tag=gti.mask,tag=gti.col8,tag=!gti.fade] run function gti:internal/final_shrink
execute if score #anim gti.var matches 19 as @e[tag=gti.mask,tag=gti.col9,tag=!gti.fade] run function gti:internal/final_shrink
execute if score #anim gti.var matches 21 as @e[tag=gti.mask,tag=gti.col10,tag=!gti.fade] run function gti:internal/final_shrink
execute if score #anim gti.var matches 23 as @e[tag=gti.mask,tag=gti.col11,tag=!gti.fade] run function gti:internal/final_shrink
execute if score #anim gti.var matches 25 as @e[tag=gti.mask,tag=gti.col12,tag=!gti.fade] run function gti:internal/final_shrink
execute if score #anim gti.var matches 27 as @e[tag=gti.mask,tag=gti.col13,tag=!gti.fade] run function gti:internal/final_shrink
execute if score #anim gti.var matches 29 as @e[tag=gti.mask,tag=gti.col14,tag=!gti.fade] run function gti:internal/final_shrink
execute if score #anim gti.var matches 31 as @e[tag=gti.mask,tag=gti.col15,tag=!gti.fade] run function gti:internal/final_shrink
execute if score #result gti.var matches 1 if score #anim gti.var matches 2 run particle minecraft:firework ~ ~ ~.5 7 6 .2 0.07 70 force @a[tag=gti.player]
execute if score #result gti.var matches 1 if score #anim gti.var matches 2 run execute as @a[tag=gti.player] at @s run playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 0.65 0.8285714285714286
execute if score #result gti.var matches 1 if score #anim gti.var matches 12 run particle minecraft:firework ~ ~ ~.5 7 6 .2 0.07 70 force @a[tag=gti.player]
execute if score #result gti.var matches 1 if score #anim gti.var matches 12 run execute as @a[tag=gti.player] at @s run playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 0.65 0.9714285714285715
execute if score #result gti.var matches 1 if score #anim gti.var matches 22 run particle minecraft:firework ~ ~ ~.5 7 6 .2 0.07 70 force @a[tag=gti.player]
execute if score #result gti.var matches 1 if score #anim gti.var matches 22 run execute as @a[tag=gti.player] at @s run playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 0.65 1.1142857142857143
execute if score #result gti.var matches 1 if score #anim gti.var matches 32 run particle minecraft:firework ~ ~ ~.5 7 6 .2 0.07 70 force @a[tag=gti.player]
execute if score #result gti.var matches 1 if score #anim gti.var matches 32 run execute as @a[tag=gti.player] at @s run playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 0.65 1.2571428571428571
execute if score #result gti.var matches 1 if score #anim gti.var matches 42 run particle minecraft:firework ~ ~ ~.5 7 6 .2 0.07 70 force @a[tag=gti.player]
execute if score #result gti.var matches 1 if score #anim gti.var matches 42 run execute as @a[tag=gti.player] at @s run playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 0.65 1.4
execute if score #result gti.var matches 1 if score #anim gti.var matches 52 run particle minecraft:firework ~ ~ ~.5 7 6 .2 0.07 70 force @a[tag=gti.player]
execute if score #result gti.var matches 1 if score #anim gti.var matches 52 run execute as @a[tag=gti.player] at @s run playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 0.65 1.542857142857143
execute if score #anim gti.var matches 60.. run function gti:internal/finished
