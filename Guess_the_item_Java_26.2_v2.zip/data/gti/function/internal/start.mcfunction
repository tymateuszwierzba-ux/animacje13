kill @e[tag=gti.mask]
execute as @e[tag=gti.frame] run data modify entity @s block_state.Name set value "minecraft:cyan_concrete"
kill @e[tag=gti.pixel]
scoreboard players set #pixels gti.var 0
scoreboard players set #guesses gti.var 0
scoreboard players set #wrong gti.var 0
scoreboard players set #cost gti.var 0
scoreboard players set #time gti.var 0
scoreboard players set #timer gti.var 0
scoreboard players set #anim gti.var 0
scoreboard players set @a[tag=gti.player] gti.tries 0
scoreboard players set @a[tag=gti.player] gti.clicks 0
scoreboard players set #state gti.var 1
bossbar set gti:budget players @a[tag=gti.player]
bossbar set gti:budget color blue
bossbar set gti:budget max 100
bossbar set gti:budget value 0
bossbar set gti:budget visible true
title @a[tag=gti.player] times 5 35 10
title @a[tag=gti.player] subtitle {"text":"Przygotuj się…","color":"gray"}
title @a[tag=gti.player] title {"text":"GUESS THE ITEM","color":"aqua","bold":true}
execute as @a[tag=gti.player] at @s run playsound minecraft:block.beacon.activate master @s ~ ~ ~ 0.65 1.2
