scoreboard players add #clock gti.var 1
execute as @e[tag=gti.control] at @s if data entity @s interaction run function gti:internal/control_event
execute if score #state gti.var matches 0 if score #clock gti.var matches 1 run function gti:internal/idle_fx
execute if score #clock gti.var matches 20.. run scoreboard players set #clock gti.var 0
execute if score #state gti.var matches 1 run function gti:internal/intro
execute if score #state gti.var matches 2 run function gti:internal/active
execute if score #state gti.var matches 3 run function gti:internal/finale
scoreboard players add @e[tag=gti.fade] gti.age 1
kill @e[tag=gti.fade,scores={gti.age=9..}]
execute if score #clock gti.var matches 0 run function gti:internal/hud
execute as @e[tag=gti.submit] if data entity @s interaction run function gti:internal/submit_event
execute as @e[tag=gti.pixel,tag=!gti.open] at @s if data entity @s interaction run function gti:internal/pixel_event
execute as @e[tag=gti.pixel,tag=!gti.open] at @s if data entity @s attack run function gti:internal/pixel_attack
