scoreboard players set #timer gti.var 0
execute store result storage gti:ctx batch int 1 run scoreboard players get #batch gti.var
function gti:internal/batch_random with storage gti:ctx
