execute if score #state gti.var matches 2 on target run function gti:internal/guess_request
data remove entity @s interaction
