data merge entity @s {start_interpolation:0,interpolation_duration:7,transformation:{scale:[0f,0f,0.05f],translation:[0.4925f,0.4925f,0f]}}
tag @s add gti.fade
scoreboard players set @s gti.age 0
