loot replace entity @e[tag=gti.item,limit=1] contents loot gti:random
