$execute as @e[tag=gti.pixel,tag=!gti.open,sort=random,limit=$(batch)] at @s run function gti:internal/reveal
