scoreboard players add @s gti.wins 1
# Record = shared round answers * 1000 + revealed pixels; lower is better.
scoreboard players set #thousand gti.var 1000
scoreboard players operation #rank gti.var = #guesses gti.var
scoreboard players operation #rank gti.var *= #thousand gti.var
scoreboard players operation #rank gti.var += #pixels gti.var
execute unless score @s gti.best matches 1.. run scoreboard players operation @s gti.best = #rank gti.var
execute if score #rank gti.var < @s gti.best run tellraw @s {"text":"★ NOWY REKORD! ★","color":"gold","bold":true}
execute if score #rank gti.var < @s gti.best run scoreboard players operation @s gti.best = #rank gti.var
title @a[tag=gti.player] times 5 60 15
title @a[tag=gti.player] subtitle [{"selector":"@s","color":"yellow"},{"text":" odgaduje przedmiot!","color":"white"}]
title @a[tag=gti.player] title {"text":"TRAFIONE!","color":"green","bold":true}
tellraw @a[tag=gti.player] [{"text":"★ ","color":"gold"},{"selector":"@s","color":"aqua"},{"text":" • własne próby: ","color":"gray"},{"score":{"name":"@s","objective":"gti.tries"},"color":"white"},{"text":" • próby drużyny: ","color":"gray"},{"score":{"name":"#guesses","objective":"gti.var"},"color":"white"},{"text":" • piksele: ","color":"gray"},{"score":{"name":"#pixels","objective":"gti.var"},"color":"aqua"}]
scoreboard players set #result gti.var 1
execute as @a[tag=gti.player] at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.65 1
function gti:internal/finish
