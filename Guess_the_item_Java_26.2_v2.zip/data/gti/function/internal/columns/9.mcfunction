summon block_display ~1 ~-8 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col9"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~1 ~-8 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 144
summon interaction ~1.5 ~-8 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col9"]}
execute positioned ~1.5 ~-8 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 144
summon block_display ~1 ~-7 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col9"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~1 ~-7 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 145
summon interaction ~1.5 ~-7 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col9"]}
execute positioned ~1.5 ~-7 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 145
summon block_display ~1 ~-6 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col9"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~1 ~-6 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 146
summon interaction ~1.5 ~-6 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col9"]}
execute positioned ~1.5 ~-6 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 146
summon block_display ~1 ~-5 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col9"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~1 ~-5 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 147
summon interaction ~1.5 ~-5 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col9"]}
execute positioned ~1.5 ~-5 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 147
summon block_display ~1 ~-4 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col9"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~1 ~-4 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 148
summon interaction ~1.5 ~-4 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col9"]}
execute positioned ~1.5 ~-4 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 148
summon block_display ~1 ~-3 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col9"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~1 ~-3 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 149
summon interaction ~1.5 ~-3 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col9"]}
execute positioned ~1.5 ~-3 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 149
summon block_display ~1 ~-2 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col9"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~1 ~-2 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 150
summon interaction ~1.5 ~-2 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col9"]}
execute positioned ~1.5 ~-2 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 150
summon block_display ~1 ~-1 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col9"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~1 ~-1 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 151
summon interaction ~1.5 ~-1 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col9"]}
execute positioned ~1.5 ~-1 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 151
summon block_display ~1 ~0 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col9"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~1 ~0 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 152
summon interaction ~1.5 ~0 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col9"]}
execute positioned ~1.5 ~0 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 152
summon block_display ~1 ~1 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col9"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~1 ~1 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 153
summon interaction ~1.5 ~1 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col9"]}
execute positioned ~1.5 ~1 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 153
summon block_display ~1 ~2 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col9"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~1 ~2 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 154
summon interaction ~1.5 ~2 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col9"]}
execute positioned ~1.5 ~2 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 154
summon block_display ~1 ~3 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col9"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~1 ~3 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 155
summon interaction ~1.5 ~3 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col9"]}
execute positioned ~1.5 ~3 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 155
summon block_display ~1 ~4 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col9"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~1 ~4 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 156
summon interaction ~1.5 ~4 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col9"]}
execute positioned ~1.5 ~4 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 156
summon block_display ~1 ~5 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col9"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~1 ~5 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 157
summon interaction ~1.5 ~5 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col9"]}
execute positioned ~1.5 ~5 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 157
summon block_display ~1 ~6 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col9"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~1 ~6 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 158
summon interaction ~1.5 ~6 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col9"]}
execute positioned ~1.5 ~6 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 158
summon block_display ~1 ~7 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col9"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~1 ~7 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 159
summon interaction ~1.5 ~7 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col9"]}
execute positioned ~1.5 ~7 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 159
