summon block_display ~-8 ~-8 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col0"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-8 ~-8 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 0
summon interaction ~-7.5 ~-8 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col0"]}
execute positioned ~-7.5 ~-8 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 0
summon block_display ~-8 ~-7 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col0"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-8 ~-7 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 1
summon interaction ~-7.5 ~-7 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col0"]}
execute positioned ~-7.5 ~-7 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 1
summon block_display ~-8 ~-6 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col0"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-8 ~-6 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 2
summon interaction ~-7.5 ~-6 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col0"]}
execute positioned ~-7.5 ~-6 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 2
summon block_display ~-8 ~-5 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col0"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-8 ~-5 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 3
summon interaction ~-7.5 ~-5 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col0"]}
execute positioned ~-7.5 ~-5 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 3
summon block_display ~-8 ~-4 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col0"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-8 ~-4 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 4
summon interaction ~-7.5 ~-4 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col0"]}
execute positioned ~-7.5 ~-4 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 4
summon block_display ~-8 ~-3 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col0"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-8 ~-3 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 5
summon interaction ~-7.5 ~-3 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col0"]}
execute positioned ~-7.5 ~-3 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 5
summon block_display ~-8 ~-2 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col0"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-8 ~-2 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 6
summon interaction ~-7.5 ~-2 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col0"]}
execute positioned ~-7.5 ~-2 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 6
summon block_display ~-8 ~-1 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col0"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-8 ~-1 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 7
summon interaction ~-7.5 ~-1 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col0"]}
execute positioned ~-7.5 ~-1 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 7
summon block_display ~-8 ~0 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col0"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-8 ~0 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 8
summon interaction ~-7.5 ~0 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col0"]}
execute positioned ~-7.5 ~0 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 8
summon block_display ~-8 ~1 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col0"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-8 ~1 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 9
summon interaction ~-7.5 ~1 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col0"]}
execute positioned ~-7.5 ~1 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 9
summon block_display ~-8 ~2 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col0"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-8 ~2 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 10
summon interaction ~-7.5 ~2 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col0"]}
execute positioned ~-7.5 ~2 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 10
summon block_display ~-8 ~3 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col0"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-8 ~3 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 11
summon interaction ~-7.5 ~3 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col0"]}
execute positioned ~-7.5 ~3 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 11
summon block_display ~-8 ~4 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col0"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-8 ~4 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 12
summon interaction ~-7.5 ~4 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col0"]}
execute positioned ~-7.5 ~4 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 12
summon block_display ~-8 ~5 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col0"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-8 ~5 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 13
summon interaction ~-7.5 ~5 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col0"]}
execute positioned ~-7.5 ~5 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 13
summon block_display ~-8 ~6 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col0"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-8 ~6 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 14
summon interaction ~-7.5 ~6 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col0"]}
execute positioned ~-7.5 ~6 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 14
summon block_display ~-8 ~7 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col0"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-8 ~7 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 15
summon interaction ~-7.5 ~7 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col0"]}
execute positioned ~-7.5 ~7 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 15
