summon block_display ~-6 ~-8 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col2"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-6 ~-8 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 32
summon interaction ~-5.5 ~-8 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col2"]}
execute positioned ~-5.5 ~-8 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 32
summon block_display ~-6 ~-7 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col2"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-6 ~-7 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 33
summon interaction ~-5.5 ~-7 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col2"]}
execute positioned ~-5.5 ~-7 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 33
summon block_display ~-6 ~-6 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col2"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-6 ~-6 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 34
summon interaction ~-5.5 ~-6 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col2"]}
execute positioned ~-5.5 ~-6 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 34
summon block_display ~-6 ~-5 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col2"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-6 ~-5 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 35
summon interaction ~-5.5 ~-5 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col2"]}
execute positioned ~-5.5 ~-5 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 35
summon block_display ~-6 ~-4 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col2"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-6 ~-4 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 36
summon interaction ~-5.5 ~-4 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col2"]}
execute positioned ~-5.5 ~-4 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 36
summon block_display ~-6 ~-3 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col2"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-6 ~-3 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 37
summon interaction ~-5.5 ~-3 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col2"]}
execute positioned ~-5.5 ~-3 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 37
summon block_display ~-6 ~-2 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col2"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-6 ~-2 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 38
summon interaction ~-5.5 ~-2 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col2"]}
execute positioned ~-5.5 ~-2 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 38
summon block_display ~-6 ~-1 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col2"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-6 ~-1 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 39
summon interaction ~-5.5 ~-1 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col2"]}
execute positioned ~-5.5 ~-1 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 39
summon block_display ~-6 ~0 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col2"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-6 ~0 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 40
summon interaction ~-5.5 ~0 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col2"]}
execute positioned ~-5.5 ~0 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 40
summon block_display ~-6 ~1 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col2"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-6 ~1 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 41
summon interaction ~-5.5 ~1 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col2"]}
execute positioned ~-5.5 ~1 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 41
summon block_display ~-6 ~2 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col2"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-6 ~2 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 42
summon interaction ~-5.5 ~2 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col2"]}
execute positioned ~-5.5 ~2 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 42
summon block_display ~-6 ~3 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col2"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-6 ~3 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 43
summon interaction ~-5.5 ~3 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col2"]}
execute positioned ~-5.5 ~3 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 43
summon block_display ~-6 ~4 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col2"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-6 ~4 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 44
summon interaction ~-5.5 ~4 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col2"]}
execute positioned ~-5.5 ~4 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 44
summon block_display ~-6 ~5 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col2"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-6 ~5 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 45
summon interaction ~-5.5 ~5 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col2"]}
execute positioned ~-5.5 ~5 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 45
summon block_display ~-6 ~6 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col2"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-6 ~6 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 46
summon interaction ~-5.5 ~6 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col2"]}
execute positioned ~-5.5 ~6 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 46
summon block_display ~-6 ~7 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col2"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-6 ~7 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 47
summon interaction ~-5.5 ~7 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col2"]}
execute positioned ~-5.5 ~7 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 47
