summon block_display ~-1 ~-8 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col7"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-1 ~-8 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 112
summon interaction ~-0.5 ~-8 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col7"]}
execute positioned ~-0.5 ~-8 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 112
summon block_display ~-1 ~-7 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col7"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-1 ~-7 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 113
summon interaction ~-0.5 ~-7 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col7"]}
execute positioned ~-0.5 ~-7 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 113
summon block_display ~-1 ~-6 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col7"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-1 ~-6 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 114
summon interaction ~-0.5 ~-6 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col7"]}
execute positioned ~-0.5 ~-6 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 114
summon block_display ~-1 ~-5 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col7"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-1 ~-5 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 115
summon interaction ~-0.5 ~-5 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col7"]}
execute positioned ~-0.5 ~-5 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 115
summon block_display ~-1 ~-4 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col7"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-1 ~-4 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 116
summon interaction ~-0.5 ~-4 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col7"]}
execute positioned ~-0.5 ~-4 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 116
summon block_display ~-1 ~-3 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col7"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-1 ~-3 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 117
summon interaction ~-0.5 ~-3 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col7"]}
execute positioned ~-0.5 ~-3 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 117
summon block_display ~-1 ~-2 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col7"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-1 ~-2 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 118
summon interaction ~-0.5 ~-2 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col7"]}
execute positioned ~-0.5 ~-2 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 118
summon block_display ~-1 ~-1 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col7"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-1 ~-1 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 119
summon interaction ~-0.5 ~-1 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col7"]}
execute positioned ~-0.5 ~-1 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 119
summon block_display ~-1 ~0 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col7"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-1 ~0 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 120
summon interaction ~-0.5 ~0 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col7"]}
execute positioned ~-0.5 ~0 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 120
summon block_display ~-1 ~1 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col7"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-1 ~1 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 121
summon interaction ~-0.5 ~1 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col7"]}
execute positioned ~-0.5 ~1 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 121
summon block_display ~-1 ~2 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col7"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-1 ~2 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 122
summon interaction ~-0.5 ~2 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col7"]}
execute positioned ~-0.5 ~2 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 122
summon block_display ~-1 ~3 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col7"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-1 ~3 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 123
summon interaction ~-0.5 ~3 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col7"]}
execute positioned ~-0.5 ~3 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 123
summon block_display ~-1 ~4 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col7"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-1 ~4 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 124
summon interaction ~-0.5 ~4 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col7"]}
execute positioned ~-0.5 ~4 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 124
summon block_display ~-1 ~5 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col7"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-1 ~5 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 125
summon interaction ~-0.5 ~5 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col7"]}
execute positioned ~-0.5 ~5 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 125
summon block_display ~-1 ~6 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col7"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-1 ~6 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 126
summon interaction ~-0.5 ~6 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col7"]}
execute positioned ~-0.5 ~6 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 126
summon block_display ~-1 ~7 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col7"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~-1 ~7 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 127
summon interaction ~-0.5 ~7 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col7"]}
execute positioned ~-0.5 ~7 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 127
