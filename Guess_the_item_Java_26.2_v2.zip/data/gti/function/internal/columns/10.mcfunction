summon block_display ~2 ~-8 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col10"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~2 ~-8 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 160
summon interaction ~2.5 ~-8 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col10"]}
execute positioned ~2.5 ~-8 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 160
summon block_display ~2 ~-7 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col10"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~2 ~-7 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 161
summon interaction ~2.5 ~-7 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col10"]}
execute positioned ~2.5 ~-7 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 161
summon block_display ~2 ~-6 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col10"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~2 ~-6 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 162
summon interaction ~2.5 ~-6 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col10"]}
execute positioned ~2.5 ~-6 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 162
summon block_display ~2 ~-5 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col10"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~2 ~-5 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 163
summon interaction ~2.5 ~-5 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col10"]}
execute positioned ~2.5 ~-5 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 163
summon block_display ~2 ~-4 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col10"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~2 ~-4 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 164
summon interaction ~2.5 ~-4 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col10"]}
execute positioned ~2.5 ~-4 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 164
summon block_display ~2 ~-3 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col10"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~2 ~-3 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 165
summon interaction ~2.5 ~-3 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col10"]}
execute positioned ~2.5 ~-3 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 165
summon block_display ~2 ~-2 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col10"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~2 ~-2 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 166
summon interaction ~2.5 ~-2 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col10"]}
execute positioned ~2.5 ~-2 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 166
summon block_display ~2 ~-1 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col10"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~2 ~-1 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 167
summon interaction ~2.5 ~-1 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col10"]}
execute positioned ~2.5 ~-1 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 167
summon block_display ~2 ~0 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col10"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~2 ~0 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 168
summon interaction ~2.5 ~0 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col10"]}
execute positioned ~2.5 ~0 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 168
summon block_display ~2 ~1 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col10"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~2 ~1 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 169
summon interaction ~2.5 ~1 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col10"]}
execute positioned ~2.5 ~1 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 169
summon block_display ~2 ~2 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col10"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~2 ~2 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 170
summon interaction ~2.5 ~2 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col10"]}
execute positioned ~2.5 ~2 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 170
summon block_display ~2 ~3 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col10"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~2 ~3 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 171
summon interaction ~2.5 ~3 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col10"]}
execute positioned ~2.5 ~3 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 171
summon block_display ~2 ~4 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col10"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~2 ~4 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 172
summon interaction ~2.5 ~4 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col10"]}
execute positioned ~2.5 ~4 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 172
summon block_display ~2 ~5 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col10"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~2 ~5 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 173
summon interaction ~2.5 ~5 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col10"]}
execute positioned ~2.5 ~5 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 173
summon block_display ~2 ~6 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col10"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~2 ~6 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 174
summon interaction ~2.5 ~6 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col10"]}
execute positioned ~2.5 ~6 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 174
summon block_display ~2 ~7 ~0.12 {"Tags":["gti.entity","gti.mask","gti.col10"],"block_state":{"Name":"minecraft:black_concrete"},"brightness":{"sky":15,"block":15},"view_range":2,"transformation":{"scale":[1.001,1.001,0.05],"translation":[0,0,0],"left_rotation":[0,0,0,1],"right_rotation":[0,0,0,1]}}
execute positioned ~2 ~7 ~.12 run scoreboard players set @e[tag=gti.mask,sort=nearest,limit=1] gti.id 175
summon interaction ~2.5 ~7 ~.32 {"width":0.98,"height":0.985,"response":true,"Tags":["gti.entity","gti.pixel","gti.col10"]}
execute positioned ~2.5 ~7 ~.32 run scoreboard players set @e[tag=gti.pixel,sort=nearest,limit=1] gti.id 175
