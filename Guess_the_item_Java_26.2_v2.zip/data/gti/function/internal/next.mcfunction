execute unless score #state gti.var matches 0 run return run tellraw @s {"text":"Runda już trwa. Dokończ ją; administrator może użyć gti:stop.","color":"red"}
tag @s add gti.player
function gti:start
