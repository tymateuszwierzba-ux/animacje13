$execute as @e[tag=gti.pixel,tag=!gti.open,sort=nearest,limit=$(batch)] at @s run function gti:internal/reveal
