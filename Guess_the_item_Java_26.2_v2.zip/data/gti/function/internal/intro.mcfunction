scoreboard players add #anim gti.var 1
execute if score #anim gti.var matches 4 run function gti:internal/random
execute if score #anim gti.var matches 4 run execute as @a[tag=gti.player] at @s run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.65 0.75
execute if score #anim gti.var matches 8 run function gti:internal/random
execute if score #anim gti.var matches 8 run execute as @a[tag=gti.player] at @s run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.65 0.7999999999999999
execute if score #anim gti.var matches 12 run function gti:internal/random
execute if score #anim gti.var matches 12 run execute as @a[tag=gti.player] at @s run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.65 0.85
execute if score #anim gti.var matches 16 run function gti:internal/random
execute if score #anim gti.var matches 16 run execute as @a[tag=gti.player] at @s run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.65 0.8999999999999999
execute if score #anim gti.var matches 20 run function gti:internal/random
execute if score #anim gti.var matches 20 run execute as @a[tag=gti.player] at @s run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.65 0.95
execute if score #anim gti.var matches 24 run function gti:internal/random
execute if score #anim gti.var matches 24 run execute as @a[tag=gti.player] at @s run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.65 1.0
execute if score #anim gti.var matches 28 run function gti:internal/random
execute if score #anim gti.var matches 28 run execute as @a[tag=gti.player] at @s run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.65 1.0499999999999998
execute if score #anim gti.var matches 32 run function gti:internal/random
execute if score #anim gti.var matches 32 run execute as @a[tag=gti.player] at @s run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.65 1.1
execute if score #anim gti.var matches 36 run function gti:internal/random
execute if score #anim gti.var matches 36 run execute as @a[tag=gti.player] at @s run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.65 1.15
execute if score #anim gti.var matches 40 run function gti:internal/random
execute if score #anim gti.var matches 40 run execute as @a[tag=gti.player] at @s run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.65 1.2
execute if score #anim gti.var matches 44 run function gti:internal/random
execute if score #anim gti.var matches 44 run execute as @a[tag=gti.player] at @s run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.65 1.25
execute if score #anim gti.var matches 48 run function gti:internal/random
execute if score #anim gti.var matches 48 run execute as @a[tag=gti.player] at @s run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.65 1.2999999999999998
execute if score #anim gti.var matches 50 run function gti:internal/columns/0
execute if score #anim gti.var matches 50 run execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.65 0.8
execute if score #anim gti.var matches 52 run function gti:internal/columns/1
execute if score #anim gti.var matches 52 run execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.65 0.8500000000000001
execute if score #anim gti.var matches 54 run function gti:internal/columns/2
execute if score #anim gti.var matches 54 run execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.65 0.9
execute if score #anim gti.var matches 56 run function gti:internal/columns/3
execute if score #anim gti.var matches 56 run execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.65 0.9500000000000001
execute if score #anim gti.var matches 58 run function gti:internal/columns/4
execute if score #anim gti.var matches 58 run execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.65 1.0
execute if score #anim gti.var matches 60 run function gti:internal/columns/5
execute if score #anim gti.var matches 60 run execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.65 1.05
execute if score #anim gti.var matches 62 run function gti:internal/columns/6
execute if score #anim gti.var matches 62 run execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.65 1.1
execute if score #anim gti.var matches 64 run function gti:internal/columns/7
execute if score #anim gti.var matches 64 run execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.65 1.15
execute if score #anim gti.var matches 66 run function gti:internal/columns/8
execute if score #anim gti.var matches 66 run execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.65 1.2000000000000002
execute if score #anim gti.var matches 68 run function gti:internal/columns/9
execute if score #anim gti.var matches 68 run execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.65 1.25
execute if score #anim gti.var matches 70 run function gti:internal/columns/10
execute if score #anim gti.var matches 70 run execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.65 1.3
execute if score #anim gti.var matches 72 run function gti:internal/columns/11
execute if score #anim gti.var matches 72 run execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.65 1.35
execute if score #anim gti.var matches 74 run function gti:internal/columns/12
execute if score #anim gti.var matches 74 run execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.65 1.4
execute if score #anim gti.var matches 76 run function gti:internal/columns/13
execute if score #anim gti.var matches 76 run execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.65 1.4500000000000002
execute if score #anim gti.var matches 78 run function gti:internal/columns/14
execute if score #anim gti.var matches 78 run execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.65 1.5
execute if score #anim gti.var matches 80 run function gti:internal/columns/15
execute if score #anim gti.var matches 80 run execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 0.65 1.55
execute if score #anim gti.var matches 82 run function gti:internal/select_final
execute if score #anim gti.var matches 84 run title @a[tag=gti.player] subtitle {"text":"Zgadnij przy jak najmniejszej liczbie prób!","color":"gray"}
execute if score #anim gti.var matches 84 run title @a[tag=gti.player] title {"text":"3","color":"yellow"}
execute if score #anim gti.var matches 84 run execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.65 1
execute if score #anim gti.var matches 104 run title @a[tag=gti.player] subtitle {"text":"Zgadnij przy jak najmniejszej liczbie prób!","color":"gray"}
execute if score #anim gti.var matches 104 run title @a[tag=gti.player] title {"text":"2","color":"yellow"}
execute if score #anim gti.var matches 104 run execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.65 1
execute if score #anim gti.var matches 124 run title @a[tag=gti.player] subtitle {"text":"Zgadnij przy jak najmniejszej liczbie prób!","color":"gray"}
execute if score #anim gti.var matches 124 run title @a[tag=gti.player] title {"text":"1","color":"yellow"}
execute if score #anim gti.var matches 124 run execute as @a[tag=gti.player] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 0.65 1
execute if score #anim gti.var matches 144.. run function gti:internal/begin
