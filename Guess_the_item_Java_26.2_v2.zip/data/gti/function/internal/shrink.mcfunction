$data merge entity @e[tag=gti.mask,scores={gti.id=$(id)},limit=1] {start_interpolation:0,interpolation_duration:7,transformation:{scale:[1f,1f,0.025f],left_rotation:[0f,0.7071068f,0f,0.7071068f],translation:[0.5f,0f,0.04f]}}
$tag @e[tag=gti.mask,scores={gti.id=$(id)}] add gti.fade
$scoreboard players set @e[tag=gti.mask,scores={gti.id=$(id)}] gti.age 0
