data modify entity @e[tag=gti.hud,limit=1] text set value [{"text":"PRÓBY\n","color":"#f6cf84","bold":true},{"score":{"name":"#guesses","objective":"gti.var"},"color":"white"},{"text":"\n\nPIKSELE\n","color":"#61ede5","bold":true},{"score":{"name":"#pixels","objective":"gti.var"},"color":"white"},{"text":" / 256\n\nBŁĘDY\n","color":"#9fb1cc"},{"score":{"name":"#wrong","objective":"gti.var"},"color":"#ff8996"},{"text":"\n\nPACZKA  × ","color":"#b7a3ff"},{"score":{"name":"#batch","objective":"gti.var"},"color":"white"}]
execute if score #state gti.var matches 2 run title @a[tag=gti.player] actionbar [{"text":"PRÓBY ","color":"gold"},{"score":{"name":"#guesses","objective":"gti.var"},"color":"white"},{"text":"   •   PIKSELE ","color":"aqua"},{"score":{"name":"#pixels","objective":"gti.var"},"color":"white"},{"text":"   •   PACZKA × ","color":"light_purple"},{"score":{"name":"#batch","objective":"gti.var"},"color":"white"}]
execute if score #state gti.var matches 1 run return 0
execute if score #limit gti.var matches 1.. store result bossbar gti:budget max run scoreboard players get #limit gti.var
scoreboard players operation #remaining gti.var = #limit gti.var
scoreboard players operation #remaining gti.var -= #cost gti.var
execute if score #remaining gti.var matches ..-1 run scoreboard players set #remaining gti.var 0
execute if score #limit gti.var matches 1.. store result bossbar gti:budget value run scoreboard players get #remaining gti.var
bossbar set gti:budget players @a[tag=gti.player]
bossbar set gti:budget name [{"text":"Guess the item  •  koszt ","color":"aqua"},{"score":{"name":"#cost","objective":"gti.var"},"color":"white"},{"text":" / ","color":"gray"},{"score":{"name":"#limit","objective":"gti.var"},"color":"white"}]
execute if score #limit gti.var matches 0 run bossbar set gti:budget name {"text":"TRYB CHILL • bez limitu • liczą się próby i piksele","color":"aqua"}
execute if score #limit gti.var matches 0 run bossbar set gti:budget max 1
execute if score #limit gti.var matches 0 run bossbar set gti:budget value 1
bossbar set gti:budget color blue
execute if score #limit gti.var matches 1.. if score #remaining gti.var matches ..16 run bossbar set gti:budget color yellow
execute if score #limit gti.var matches 1.. if score #remaining gti.var matches ..8 run bossbar set gti:budget color red
