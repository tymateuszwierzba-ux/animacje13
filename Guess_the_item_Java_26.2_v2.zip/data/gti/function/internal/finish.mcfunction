scoreboard players set #state gti.var 3
scoreboard players set #anim gti.var 0
kill @e[tag=gti.pixel]
execute store result score #seconds gti.var run scoreboard players get #time gti.var
scoreboard players set #twenty gti.var 20
scoreboard players operation #seconds gti.var /= #twenty gti.var
tellraw @a[tag=gti.player] [{"text":"Czas: ","color":"gray"},{"score":{"name":"#seconds","objective":"gti.var"},"color":"white"},{"text":" s • próby: ","color":"gray"},{"score":{"name":"#guesses","objective":"gti.var"},"color":"white"},{"text":" • odkryte piksele: ","color":"gray"},{"score":{"name":"#pixels","objective":"gti.var"},"color":"aqua"}]
execute at @e[tag=gti.anchor,limit=1] run function gti:internal/hud
