scoreboard players set #v2 gti.var 1
scoreboard players set #batch gti.var 1
scoreboard players set #reveal_mode gti.var 0
scoreboard players set #seconds_cfg gti.var 5
scoreboard players set #interval gti.var 100
scoreboard players set #timer gti.var 0
scoreboard players set #initial gti.var 1
scoreboard players set #source gti.var 0
scoreboard players set #aliases gti.var 1
scoreboard players set #limit gti.var 0
data modify storage gti:config fixed set value {id:"minecraft:diamond",count:1}
