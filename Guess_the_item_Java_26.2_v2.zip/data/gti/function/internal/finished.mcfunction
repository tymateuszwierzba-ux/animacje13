scoreboard players set #state gti.var 0
kill @e[tag=gti.mask]
bossbar set gti:budget visible false
data modify storage gti:ctx shown set from entity @e[tag=gti.item,limit=1] item.id
tellraw @a[tag=gti.player] [{"text":"Odpowiedź: ","color":"gray"},{"nbt":"shown","storage":"gti:ctx","color":"aqua"}]
tellraw @a[tag=gti.player] {"text":"[ Następna runda / menu ]","color":"aqua","click_event":{"action":"show_dialog","dialog":"gti:menu"}}
