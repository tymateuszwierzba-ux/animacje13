execute unless dimension minecraft:overworld run return 0
execute unless entity @e[tag=gti.anchor] run return 0
execute unless score #state gti.var matches 2 run return run tellraw @s {"text":"Poczekaj na rozpoczęcie rundy.","color":"gray"}
execute unless items entity @s weapon.mainhand #gti:answers run return run tellraw @s {"text":"Trzymaj obsługiwany przedmiot w głównej ręce! AIR i pusta ręka nie są odpowiedziami. Nie naliczono próby.","color":"yellow"}
tag @s add gti.player
scoreboard players add @s gti.tries 1
scoreboard players add #guesses gti.var 1
data modify storage gti:ctx answer set from entity @e[tag=gti.item,limit=1] item.id
execute store success score #different gti.var run data modify storage gti:ctx answer set from entity @s SelectedItem.id
execute if score #aliases gti.var matches 1 if score #different gti.var matches 1 run function gti:internal/equivalent
execute if score #different gti.var matches 0 run function gti:internal/win
execute if score #different gti.var matches 1 run function gti:internal/wrong
