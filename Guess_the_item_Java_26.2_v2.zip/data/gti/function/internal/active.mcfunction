scoreboard players add #time gti.var 1
execute if score #limit gti.var matches 1.. if score #cost gti.var >= #limit gti.var run function gti:internal/lose
execute unless score #state gti.var matches 2 run return 0
execute if score #reveal_mode gti.var matches 2 run scoreboard players add #timer gti.var 1
execute if score #reveal_mode gti.var matches 2 if score #timer gti.var >= #interval gti.var run function gti:internal/auto_batch
