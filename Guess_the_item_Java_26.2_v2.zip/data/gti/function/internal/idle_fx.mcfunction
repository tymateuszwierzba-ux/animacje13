particle minecraft:end_rod ~ ~8.6 ~.25 7 .02 .02 .005 4 force @a[tag=gti.player]
