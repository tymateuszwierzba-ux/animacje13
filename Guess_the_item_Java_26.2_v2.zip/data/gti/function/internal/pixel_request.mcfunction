execute unless dimension minecraft:overworld run return 0
execute unless score #state gti.var matches 2 run return run tellraw @s {"text":"Poczekaj na rozpoczęcie rundy.","color":"gray"}
execute unless entity @e[tag=gti.anchor] run return 0
execute unless entity @e[tag=gti.pixel,tag=!gti.open] run return run tellraw @s {"text":"Wszystkie pola są odkryte — zgaduj!","color":"yellow"}
tag @s add gti.player
scoreboard players add @s gti.clicks 1
execute store result storage gti:ctx batch int 1 run scoreboard players get #batch gti.var
execute at @e[tag=gti.anchor,limit=1] run function gti:internal/batch_random with storage gti:ctx
