execute unless score #state gti.var matches 2 run return 0
scoreboard players set #result gti.var 0
title @a[tag=gti.player] times 5 60 15
title @a[tag=gti.player] subtitle {"text":"Budżet wyczerpany. Następnym razem się uda!","color":"gray"}
title @a[tag=gti.player] title {"text":"KONIEC RUNDY","color":"red"}
execute as @a[tag=gti.player] at @s run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 0.65 0.7
function gti:internal/finish
