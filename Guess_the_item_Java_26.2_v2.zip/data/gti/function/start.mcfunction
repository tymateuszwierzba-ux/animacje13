execute in minecraft:overworld unless entity @e[tag=gti.anchor] run return run tellraw @s {"text":"Najpierw /function gti:setup. Plansza musi być załadowana.","color":"red"}
execute unless score #state gti.var matches 0 run return run tellraw @s {"text":"Runda już trwa. /function gti:stop ją przerwie.","color":"red"}
execute if entity @s[type=player] run tag @s add gti.player
execute in minecraft:overworld at @e[tag=gti.anchor,limit=1] run function gti:internal/start
