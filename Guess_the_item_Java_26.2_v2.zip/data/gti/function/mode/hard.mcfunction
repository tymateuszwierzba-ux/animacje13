execute unless score #state gti.var matches 0 run return run tellraw @s {"text":"Zmień tryb między rundami.","color":"red"}
scoreboard players set #limit gti.var 32
tellraw @a[tag=gti.player] {"text":"Tryb: HARD • 32 pkt","color":"aqua"}
