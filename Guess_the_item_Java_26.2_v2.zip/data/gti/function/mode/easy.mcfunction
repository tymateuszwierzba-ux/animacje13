execute unless score #state gti.var matches 0 run return run tellraw @s {"text":"Zmień tryb między rundami.","color":"red"}
scoreboard players set #limit gti.var 128
tellraw @a[tag=gti.player] {"text":"Tryb: EASY • 128 pkt","color":"aqua"}
