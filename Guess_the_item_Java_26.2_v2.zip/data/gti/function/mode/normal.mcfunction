execute unless score #state gti.var matches 0 run return run tellraw @s {"text":"Zmień tryb między rundami.","color":"red"}
scoreboard players set #limit gti.var 64
tellraw @a[tag=gti.player] {"text":"Tryb: NORMAL • 64 pkt","color":"aqua"}
