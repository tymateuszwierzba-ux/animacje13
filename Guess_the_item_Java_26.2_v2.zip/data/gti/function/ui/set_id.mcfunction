execute unless entity @s[tag=gti.host] run return run function gti:ui/denied
execute unless score #state gti.var matches 0 run return run function gti:ui/busy
scoreboard players set #valid gti.var 0
$execute store success score #valid gti.var run loot replace entity @e[tag=gti.item,limit=1] contents loot {pools:[{rolls:1,entries:[{type:"minecraft:item",name:"$(id)"}]}]}
execute unless score #valid gti.var matches 1 run return run tellraw @s {"text":"Nieprawidłowy identyfikator lub brak planszy. Użyj katalogu przedmiotów.","color":"red"}
execute unless items entity @e[tag=gti.item,limit=1] contents #gti:answers run return run tellraw @s {"text":"AIR jest pusty — wybierz widoczny przedmiot.","color":"red"}
data modify storage gti:config fixed set from entity @e[tag=gti.item,limit=1] item
scoreboard players set #source gti.var 1
tellraw @s [{"text":"Ustawiono: ","color":"gold"},{"nbt":"fixed.id","storage":"gti:config","color":"white"}]
dialog show @s gti:settings
