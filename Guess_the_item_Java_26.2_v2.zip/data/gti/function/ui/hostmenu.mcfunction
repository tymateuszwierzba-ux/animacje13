execute unless entity @s[tag=gti.host] run return run function gti:ui/denied
dialog show @s gti:settings
