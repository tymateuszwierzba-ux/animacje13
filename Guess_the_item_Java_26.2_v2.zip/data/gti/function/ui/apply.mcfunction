execute unless entity @s[tag=gti.host] run return run function gti:ui/denied
execute unless score #state gti.var matches 0 run return run function gti:ui/busy
$scoreboard players set #source gti.var $(source)
$scoreboard players set #reveal_mode gti.var $(mode)
$scoreboard players set #batch gti.var $(batch)
$scoreboard players set #seconds_cfg gti.var $(seconds)
$scoreboard players set #initial gti.var $(initial)
$scoreboard players set #limit gti.var $(limit)
$scoreboard players set #aliases gti.var $(aliases)
function gti:ui/validate
scoreboard players operation #interval gti.var = #seconds_cfg gti.var
scoreboard players set #twenty gti.var 20
scoreboard players operation #interval gti.var *= #twenty gti.var
execute at @e[tag=gti.anchor,limit=1] run function gti:internal/hud
tellraw @s {"text":"✓ Ustawienia zapisane.","color":"green"}
dialog show @s gti:settings
