execute unless entity @s[tag=gti.host] run return run function gti:ui/denied
execute unless score #state gti.var matches 0 run return run function gti:ui/busy
execute unless items entity @s weapon.mainhand #gti:answers run return run tellraw @s {"text":"Weź niepusty przedmiot z 26.2 do głównej ręki.","color":"red"}
data modify storage gti:config fixed set from entity @s SelectedItem
data modify storage gti:config fixed.count set value 1
scoreboard players set #source gti.var 1
tellraw @s [{"text":"Wybrano z ręki: ","color":"gold"},{"nbt":"fixed.id","storage":"gti:config","color":"white"}]
dialog show @s gti:settings
