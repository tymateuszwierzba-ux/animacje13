execute unless entity @s[tag=gti.host] run return run function gti:ui/denied
execute unless score #state gti.var matches 0 run return run function gti:ui/busy
scoreboard players set #source gti.var 0
tellraw @s {"text":"⟳ Następna runda: losowy przedmiot z całej puli 1536 ID.","color":"aqua"}
dialog show @s gti:settings
