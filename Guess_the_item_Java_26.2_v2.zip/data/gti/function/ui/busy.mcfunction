tellraw @s {"text":"Najpierw zakończ albo przerwij rundę. Ustawienia są dostępne między rundami.","color":"yellow"}
