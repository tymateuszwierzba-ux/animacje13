execute unless score #source gti.var matches 0..1 run scoreboard players set #source gti.var 0
execute unless score #reveal_mode gti.var matches 0..2 run scoreboard players set #reveal_mode gti.var 0
execute unless score #batch gti.var matches 1..32 run scoreboard players set #batch gti.var 1
execute unless score #seconds_cfg gti.var matches 1..30 run scoreboard players set #seconds_cfg gti.var 5
execute unless score #initial gti.var matches 0..32 run scoreboard players set #initial gti.var 1
execute unless score #limit gti.var matches 0..256 run scoreboard players set #limit gti.var 0
execute unless score #aliases gti.var matches 0..1 run scoreboard players set #aliases gti.var 1
