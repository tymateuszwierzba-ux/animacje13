execute unless entity @s[tag=gti.host] run return run function gti:ui/denied
execute unless score #state gti.var matches 0 run return run function gti:ui/busy
execute unless score @s gti.pick matches 1..1536 run return 0
function gti:catalogue/pick
scoreboard players set #source gti.var 1
tellraw @s [{"text":"Wybrano hasło: ","color":"gold"},{"nbt":"fixed.id","storage":"gti:config","color":"white"}]
dialog show @s gti:settings
