tellraw @s {"text":"Tylko gospodarz planszy może zmieniać ustawienia. Operator może użyć /function gti:host.","color":"red"}
