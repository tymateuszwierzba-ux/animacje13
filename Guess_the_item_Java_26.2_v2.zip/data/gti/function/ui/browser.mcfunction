execute unless entity @s[tag=gti.host] run return run function gti:ui/denied
execute unless score #state gti.var matches 0 run return run function gti:ui/busy
dialog show @s gti:catalogue/index
