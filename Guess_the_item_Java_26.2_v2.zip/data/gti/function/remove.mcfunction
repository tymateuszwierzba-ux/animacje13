execute in minecraft:overworld run kill @e[tag=gti.entity]
scoreboard players set #state gti.var 0
bossbar set gti:budget visible false
tag @a remove gti.player
