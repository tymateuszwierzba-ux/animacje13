$data modify storage gti:config fixed.id set from storage gti:catalogue ids[$(index)]
