scoreboard players operation #pick gti.var = @s gti.pick
scoreboard players remove #pick gti.var 1
execute store result storage gti:ui index int 1 run scoreboard players get #pick gti.var
data modify storage gti:config fixed set value {id:"minecraft:diamond",count:1}
function gti:catalogue/pick_macro with storage gti:ui
