execute unless score @s gti.wins matches 1.. run return run tellraw @s {"text":"Nie masz jeszcze wygranej. /trigger gti.menu","color":"gray"}
scoreboard players set #thousand gti.var 1000
scoreboard players operation #best_tries gti.var = @s gti.best
scoreboard players operation #best_tries gti.var /= #thousand gti.var
scoreboard players operation #best_pixels gti.var = @s gti.best
scoreboard players operation #best_pixels gti.var %= #thousand gti.var
tellraw @s [{"text":"Twoje wygrane: ","color":"gold"},{"score":{"name":"@s","objective":"gti.wins"},"color":"white"},{"text":" • rekord: ","color":"gray"},{"score":{"name":"#best_tries","objective":"gti.var"},"color":"white"},{"text":" prób drużyny, ","color":"gray"},{"score":{"name":"#best_pixels","objective":"gti.var"},"color":"aqua"},{"text":" odkrytych pikseli.","color":"gray"}]
