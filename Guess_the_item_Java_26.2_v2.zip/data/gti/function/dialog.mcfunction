function gti:help
