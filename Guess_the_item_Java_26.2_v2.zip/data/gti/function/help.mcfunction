tag @s add gti.player
dialog show @s gti:menu
