scoreboard objectives add gti.settings trigger
scoreboard objectives add gti.pick trigger
scoreboard objectives add gti.hand trigger
scoreboard objectives add gti.random trigger
scoreboard objectives add gti.stop trigger
scoreboard objectives add gti.hostmenu trigger
scoreboard objectives add gti.browser trigger
scoreboard objectives add gti.var dummy
scoreboard objectives add gti.id dummy
scoreboard objectives add gti.age dummy
scoreboard objectives add gti.guess trigger
scoreboard objectives add gti.pixel trigger
scoreboard objectives add gti.next trigger
scoreboard objectives add gti.menu trigger
scoreboard objectives add gti.stats trigger
scoreboard objectives add gti.wins dummy
scoreboard objectives add gti.best dummy
scoreboard objectives add gti.tries dummy
scoreboard objectives add gti.clicks dummy
execute unless score #init gti.var matches 1 run function gti:internal/init
bossbar add gti:budget {"text":"Guess the item","color":"aqua"}
execute if score #state gti.var matches 0 run bossbar set gti:budget visible false
execute if score #state gti.var matches 1..3 run bossbar set gti:budget visible true
tellraw @a [{"text":"[Guess the item] ","color":"aqua","bold":true},{"text":"26.2 • /function gti:setup • /trigger gti.menu","color":"gray"}]

execute unless score #v2 gti.var matches 1 run function gti:internal/init_v2

function gti:catalogue/init
