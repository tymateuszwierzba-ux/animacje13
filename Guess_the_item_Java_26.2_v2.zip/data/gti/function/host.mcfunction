tag @a remove gti.host
tag @s add gti.host
dialog show @s gti:settings
