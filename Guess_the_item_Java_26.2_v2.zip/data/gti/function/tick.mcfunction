execute as @a[scores={gti.browser=1..}] at @s run function gti:ui/browser
scoreboard players set @a[scores={gti.browser=1..}] gti.browser 0
scoreboard players enable @a gti.browser
execute as @a[scores={gti.hostmenu=1..}] at @s run function gti:ui/hostmenu
scoreboard players set @a[scores={gti.hostmenu=1..}] gti.hostmenu 0
scoreboard players enable @a gti.hostmenu
execute as @a[scores={gti.stop=1..}] at @s run function gti:ui/stop
scoreboard players set @a[scores={gti.stop=1..}] gti.stop 0
scoreboard players enable @a gti.stop
execute as @a[scores={gti.random=1..}] at @s run function gti:ui/random
scoreboard players set @a[scores={gti.random=1..}] gti.random 0
scoreboard players enable @a gti.random
execute as @a[scores={gti.hand=1..}] at @s run function gti:ui/hand
scoreboard players set @a[scores={gti.hand=1..}] gti.hand 0
scoreboard players enable @a gti.hand
execute as @a[scores={gti.pick=1..}] at @s run function gti:ui/pick
scoreboard players set @a[scores={gti.pick=1..}] gti.pick 0
scoreboard players enable @a gti.pick
execute as @a[scores={gti.settings=1..}] at @s run function gti:ui/settings
scoreboard players set @a[scores={gti.settings=1..}] gti.settings 0
scoreboard players enable @a gti.settings
execute as @a[scores={gti.stats=1..}] at @s run function gti:stats
scoreboard players set @a[scores={gti.stats=1..}] gti.stats 0
scoreboard players enable @a gti.stats
execute as @a[scores={gti.menu=1..}] at @s run function gti:help
scoreboard players set @a[scores={gti.menu=1..}] gti.menu 0
scoreboard players enable @a gti.menu
execute as @a[scores={gti.next=1..}] at @s run function gti:internal/next
scoreboard players set @a[scores={gti.next=1..}] gti.next 0
scoreboard players enable @a gti.next
execute as @a[scores={gti.guess=1..}] at @s run function gti:internal/guess_request
scoreboard players set @a[scores={gti.guess=1..}] gti.guess 0
scoreboard players enable @a gti.guess
execute as @a[scores={gti.pixel=1..}] at @s run function gti:internal/pixel_request
scoreboard players set @a[scores={gti.pixel=1..}] gti.pixel 0
scoreboard players enable @a gti.pixel
execute in minecraft:overworld at @e[tag=gti.anchor,limit=1] run function gti:internal/tick
