execute unless entity @s[type=player] run return 0
execute in minecraft:overworld unless entity @e[tag=gti.anchor] run return run tellraw @s {"text":"Brak załadowanej planszy. /function gti:setup","color":"red"}
execute in minecraft:overworld at @e[tag=gti.anchor,limit=1] run tp @s ~3 ~-11 ~24 180 -21
tag @s add gti.player
