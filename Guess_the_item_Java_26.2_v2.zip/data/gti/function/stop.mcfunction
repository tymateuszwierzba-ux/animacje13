execute in minecraft:overworld run kill @e[tag=gti.mask]
execute in minecraft:overworld run kill @e[tag=gti.pixel]
scoreboard players set #state gti.var 0
bossbar set gti:budget visible false
tellraw @a[tag=gti.player] {"text":"Runda przerwana. /function gti:start","color":"gray"}
