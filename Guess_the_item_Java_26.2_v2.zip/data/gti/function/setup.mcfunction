execute unless entity @s[type=player] run return run tellraw @a {"text":"Setup uruchom jako gracz.","color":"red"}
execute unless dimension minecraft:overworld run return run tellraw @s {"text":"Planszę utwórz w Overworldzie.","color":"red"}
function gti:remove
execute align xyz positioned ~ ~11 ~-22 run function gti:internal/build
tag @s add gti.player
scoreboard players set #state gti.var 0
function gti:view
tag @a remove gti.host
tag @s add gti.host
execute at @e[tag=gti.anchor,limit=1] run function gti:internal/hud
function gti:help
