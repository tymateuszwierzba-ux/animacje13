# GUESS THE ITEM 2.0
### ALL ITEMS • Dialog GUI • Minecraft Java 26.2

Zgaduj przedmiot po fragmentach jego ikony. **1536 niepustych ID**, prawdziwe okna `/dialog`, wybór hasła, paczki pikseli i trzy tryby odkrywania. Bez modów, pluginów i resource packa.

## Instalacja / aktualizacja z v1

**Nie instaluj obu wersji jednocześnie** — używają tego samego namespace.

1. Jeśli używasz starej wersji, stań przy jej planszy i wykonaj `/function gti:remove`.
2. Usuń stary ZIP z `datapacks`.
3. Włóż **Guess_the_item_Java_26.2_v2.zip**, bez rozpakowywania, do:
   - singleplayer: `.minecraft/saves/NAZWA_ŚWIATA/datapacks/`
   - serwer: `NAZWA_ŚWIATA/datapacks/`
4. W Overworldzie wybierz duże otwarte miejsce, najlepiej płaski świat. Jako operator wpisz:
   ```mcfunction
   /reload
   /gamemode creative
   /function gti:setup
   /dialog show @s gti:settings
   ```
5. Ustaw przedmiot i odkrywanie. W panelu kliknij **Rozpocznij rundę**.

Przed instalacją w ważnym świecie wykonaj kopię zapasową. Wygrane i rekordy z v1 pozostają w scoreboardach. Pierwsze uruchomienie v2 ustawia nowe domyślne opcje: losowe hasło, ręczne odkrywanie, paczka 1, jeden piksel na start, brak limitu punktów.

## Prawdziwe GUI — `/dialog`, nie `/dialogue`

Vanilla używa komendy **`/dialog`**. Sam datapack nie może zarejestrować nowej głównej komendy `/dialogue`.

```mcfunction
/dialog show @s gti:menu
/dialog show @s gti:settings
```

- `gti:menu` — panel gry: odkryj paczkę, zgaduj, nowa runda, statystyki i zasady.
- `gti:settings` — panel gospodarza: formularz ustawień, katalog, przedmiot z ręki, losowanie, wpisywanie ID i sterowanie rundą.
- `/trigger gti.menu` otwiera to samo GUI także **bez OP**.
- Menu jest też dodane do wbudowanych **Szybkich akcji** Minecrafta.
- Są również aliasy `/function gti:dialog` i `/function gti:dialogue` — to funkcje, nie nowe główne komendy.

Okna mają natywny wygląd Minecrafta. Kolory, nagłówki, podgląd przedmiotu i układ są dostosowane, ale sam datapack nie zmienia tekstur systemowych przycisków GUI.

## Wybór przedmiotu

W panelu gospodarza dostępne są cztery sposoby:

1. **Katalog** — wszystkie 1536 ID, kategorie, przeglądanie stron po 24 pozycje. Kliknięcie nazwy ustawia konkretne hasło. Nazwy wyświetlają się w języku Twojego klienta; identyfikator jest w podpowiedzi.
2. **Przedmiot z ręki** — kopiuje stos z głównej ręki, wraz z komponentami, bez zabierania go graczowi.
3. **Wpisz identyfikator** — np. `diamond`, `minecraft:stone`, `copper_chest`. Wymaga OP. Nieprawidłowy identyfikator może wywołać błąd walidacji komendy i nie ustawia nowego hasła.
4. **Losowy przedmiot** — każda nowa runda losuje z pełnej puli.

Formularz ustawień ma wybór **Losowy / Konkretny**. Stałe hasło pozostaje zapamiętane po przełączeniu na losowanie. Przedmiot zagadki jest ustawiany dopiero po całkowitym zasłonięciu ekranu.

**AIR jest jedynym pominiętym ID** — oznacza pusty stos i nie ma widocznej ikony. Warianty mikstur, map, zaklęć, nazw i innych komponentów jednego ID nie stanowią osobnych haseł w losowaniu. Odpowiedź jest sprawdzana po ID, nie po komponentach.

## Odkrywanie — wszystkie zamówione warianty

W formularzu ustawień wybierz **tryb**, **rozmiar paczki**, **odstęp automatu**, **piksele na start**, **budżet** i **identyczne odpowiedniki**. Kliknij **Zapisz ustawienia**.

| Tryb | Co się dzieje |
|---|---|
| **Ręcznie** | Jedno naciśnięcie „Odkryj paczkę” odkrywa ustawioną liczbę losowych pól. |
| **Po błędnej odpowiedzi** | Każdy nietrafiony, obsługiwany guess odsłania całą paczkę. Poprawny guess kończy rundę. |
| **Co ustawiony czas** | Paczka odsłania się automatycznie co 1–30 sekund. |

Rozmiary paczki: **1, 2, 5, 10, 16 lub 32**. Każda paczka wybiera różne, jeszcze zakryte pola. Przy końcu planszy odsłania tylko pozostałe pola. Przy limicie punktów może zostać skrócona, jeśli wcześniej skończy się budżet.

### Gotowe przykłady

- **Ręcznie 2 naraz:** tryb `Ręcznie`, paczka `2`.
- **Ręcznie 10 naraz:** tryb `Ręcznie`, paczka `10`.
- **10 po nietrafionym guessie:** tryb `Automatycznie po błędnej odpowiedzi`, paczka `10`.
- **Automatycznie 10 co 5 sekund:** tryb `Automatycznie co ustawiony czas`, paczka `10`, odstęp `5`.
- **Konkretne hasło — diament:** w katalogu wybierz diament albo wpisz `diamond`; źródło `Konkretny`.
- **Nowy losowy item co rundę:** źródło `Losowy z pełnej puli`.

Przycisk ręcznego odkrycia pozostaje dostępny również w obu trybach automatycznych.

### Wskazywanie pól na ekranie

Podleć w zwykły zasięg interakcji gracza i kliknij pole LPM lub PPM. Paczka odsłoni **kliknięte pole oraz najbliższe pozostałe pola** — przykładowo 2 lub 10 łącznie. Przycisk GUI wybiera natomiast pozycje losowo.

Kafelki obracają się na osi Y, a następnie znikają. Ten sam piksel nie jest naliczany ponownie.

## Zgadywanie i punktacja

Weź odpowiedni przedmiot do **głównej ręki** i kliknij **Zgaduj z ręki** w GUI lub na panelu przy planszy.

- **PRÓBY** = wszystkie obsługiwane odpowiedzi, również poprawna.
- **PIKSELE** = wszystkie odkryte pola, w tym startowe i automatyczne.
- **BŁĘDY** = nietrafione odpowiedzi.
- Pusta ręka nie nalicza próby.
- Przedmioty nie są zużywane.
- Odkrycie kosztuje 1 punkt; błędny guess dodatkowo 4 punkty.
- Budżet: **bez limitu**, 32, 64, 128 lub 256 punktów. Domyślnie bez limitu.

Gdy włączysz **identyczne odpowiedniki**, poprawne są także pary o dokładnie identycznej definicji ikony vanilla — 67 grup, m.in. miedź / woskowana miedź i kamień / zainfekowany kamień. Po wyłączeniu wymagany jest dokładny ID. Ta opcja nie traktuje wszystkich podobnych wizualnie przedmiotów jako identycznych.

## Wszystkie itemy a „piksele”

- Pula pochodzi z rejestru przedmiotów **oficjalnej Java 26.2**: 1537 wpisów minus AIR = **1536**.
- Obejmuje bloki, narzędzia, jedzenie, zbroje, jajka przyzywające i przedmioty techniczne.
- Dla płaskich ikon 16×16 pola odpowiadają siatce ikony.
- Dla modeli 3D, np. bloków, pola odsłaniają **fragmenty spłaszczonej ikony GUI**. Nie są próbkowaniem pikseli pojedynczego pliku tekstury bloku. Sam datapack nie potrafi odczytać i rasteryzować tekstury klienta.
- Przezroczyste fragmenty ikony również można odkryć.
- Używaj domyślnych zasobów klienta. Resource packi o innym układzie modeli lub rozdzielczości mogą zmienić wygląd zagadki.

Pełna lista ID jest w `LISTA_PRZEDMIOTOW.txt`.

## Nowa plansza i animacje

Nowy ekran ma warstwową ramę, turkusowo-fioletowe akcenty, gradientowy nagłówek oraz boczny panel z licznikami i trzema przyciskami. Pozostały losowanie, animowana przesłona, odliczanie, iskry, reakcja na pomyłkę, falowe odsłonięcie odpowiedzi i konfetti po wygranej. Odkrywane kafelki są teraz obracane, zamiast tylko pomniejszane.

## Gospodarz i multiplayer

- Jedna wspólna plansza w **Overworldzie**. Próby, piksele, timer i budżet są wspólne.
- Gracz wywołujący setup zostaje gospodarzem.
- Operator może przejąć panel bez przebudowy planszy: `/function gti:host`.
- Wybór hasła i ustawienia są blokowane podczas rundy. Najpierw ją zakończ lub użyj **Przerwij rundę**.
- Pełny formularz i wpisywanie ID wymagają OP, ponieważ native dialog uruchamia polecenia z uprawnieniami gracza. Przyciski rozgrywki działają przez triggery bez OP.
- Katalog, wybór z ręki, przełączenie na losowanie i przerwanie rundy są dodatkowo sprawdzane po tagu gospodarza.
- Wygrana i rekord trafiają do osoby podającej poprawną odpowiedź. Rekord: najpierw mniej prób drużyny, następnie mniej pikseli. Rekordy są wspólne dla trybów; to minigra do wspólnej zabawy, nie zabezpieczony system turniejowy.
- Ustawienia i statystyki zapisują się w świecie. Nie wykonuj `/reload` w trakcie animacji; aktualizuj paczkę między rundami.

## Komendy

### Każdy gracz
```mcfunction
/trigger gti.menu
/trigger gti.pixel
/trigger gti.guess
/trigger gti.next
/trigger gti.stats
```

### Operator
```mcfunction
/function gti:setup
/function gti:start
/function gti:stop
/function gti:view
/function gti:remove
/function gti:host
/dialog show @s gti:menu
/dialog show @s gti:settings
```

## Miejsce na planszę / usuwanie

Ekran pojawia się około 22 bloki na północ, ze środkiem 11 bloków wyżej. Z panelem bocznym zajmuje około 26 bloków szerokości i 20 wysokości. Wybierz otwartą przestrzeń i graj w creative. `gti:view` teleportuje do punktu obserwacyjnego.

Cała plansza to encje — paczka **nie podmienia bloków, ekwipunku ani trybu gry**. Pozostań w pobliżu, aby chunki były załadowane. Przed przeniesieniem lub usunięciem paczki użyj `gti:remove`, będąc przy planszy; niezaładowane encje nie są usuwane selektorem.

## Testy

Wersja: **Minecraft Java 26.2, datapack 107.1**. Nie Bedrock i nie 1.21.2.

Zweryfikowano na oficjalnym serwerze vanilla, także z podłączonym pasywnym klientem protokołu 776: rejestr wszystkich ID, ładowanie 136 dialogów, wysyłanie menu i formularza z aktualnymi ustawieniami, zachowanie szablonów przycisków, katalog, wybór ID / z ręki / losowy, paczki 2 / 10 / 32, wskazany kafelek, automat po błędzie, timer, zgadywanie z rzeczywistego ekwipunku gracza, odpowiedniki, limit, 256 unikalnych odkryć, menu bez OP i sprzątanie encji. Klient testowy nie ma renderera — wizualne oględziny oprawy w normalnym kliencie pozostają do sprawdzenia w grze.

Inspiracja pomysłem: https://github.com/blockerlocker/guesstheitem
Niezależna implementacja, nie oficjalna aktualizacja tamtego repozytorium.
