execute unless score #state gti.var matches 2 run return run tellraw @s {"text":"No round is running. Open the menu: /trigger gti_menu","color":"gray"}
execute unless entity @e[tag=gti.cell,tag=!gti.open,limit=1] run return run tellraw @s {"text":"Every cell is revealed - hold the item and guess!","color":"yellow"}
tag @s add gti.player
execute store result storage gti:tmp batch int 1 run scoreboard players get #batch gti.var
execute at @e[tag=gti.anchor,limit=1] run function gti:reveal/batch with storage gti:tmp
function gti:hud/refresh
