execute store result storage gti:tmp batch int 1 run scoreboard players get #initial gti.var
execute at @e[tag=gti.anchor,limit=1] run function gti:reveal/batch with storage gti:tmp
