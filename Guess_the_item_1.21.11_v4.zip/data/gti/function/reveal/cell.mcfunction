execute unless score #state gti.var matches 2 run return 0
tag @s add gti.open
scoreboard players add #revealed gti.var 1
execute if score #free gti.var matches 0 run scoreboard players add #used gti.var 1
data modify storage gti:tmp id set value 0
execute store result storage gti:tmp id int 1 run scoreboard players get @s gti.id
data modify storage gti:tmp key set from storage gti:cfg art_key
function gti:art/place with storage gti:tmp
execute if score #free gti.var matches 0 run function gti:strip/refresh
execute if score #free gti.var matches 0 if score #limit gti.var matches 1.. if score #left gti.var matches ..0 run function gti:round/lose
execute if score #revealed gti.var matches 256 run function gti:round/complete
