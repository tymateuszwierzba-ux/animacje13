scoreboard players set #free gti.var 1
execute store result storage gti:tmp batch int 1 run scoreboard players get #two gti.var
execute at @e[tag=gti.anchor,limit=1] run function gti:reveal/batch with storage gti:tmp
scoreboard players set #free gti.var 0
function gti:strip/refresh
