execute if entity @s[tag=gti.open] run return 0
tag @s add gti.open
data modify storage gti:tmp id set value 0
execute store result storage gti:tmp id int 1 run scoreboard players get @s gti.id
data modify storage gti:tmp key set from storage gti:cfg art_key
function gti:art/place with storage gti:tmp
execute at @s run particle minecraft:block minecraft:bedrock ~ ~ ~ 0.35 0.35 0.2 0.02 5 force @a[tag=gti.player]
