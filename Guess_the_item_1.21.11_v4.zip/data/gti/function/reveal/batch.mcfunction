$execute as @e[tag=gti.cell,tag=!gti.open,sort=random,limit=$(batch)] at @s run function gti:reveal/cell
execute at @e[tag=gti.anchor,limit=1] run playsound minecraft:block.amethyst_block.chime master @a[tag=gti.player] ~ ~ ~ 0.45 1.4
execute at @e[tag=gti.anchor,limit=1] run particle minecraft:block minecraft:bedrock ~ ~10.5 ~1 9 9 0.1 0.05 40 force @a[tag=gti.player]
