execute positioned ~4.5 ~15 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 204
summon interaction ~4.5 ~15 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col12"]}
execute positioned ~4.5 ~15 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 204
summon block_display ~5 ~14.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col13"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~5.5 ~15 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 205
summon interaction ~5.5 ~15 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col13"]}
execute positioned ~5.5 ~15 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 205
summon block_display ~6 ~14.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col14"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~6.5 ~15 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 206
summon interaction ~6.5 ~15 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col14"]}
execute positioned ~6.5 ~15 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 206
summon block_display ~7 ~14.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col15"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~7.5 ~15 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 207
summon interaction ~7.5 ~15 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col15"]}
execute positioned ~7.5 ~15 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 207
summon block_display ~-8 ~15.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col0"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-7.5 ~16 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 208
summon interaction ~-7.5 ~16 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col0"]}
execute positioned ~-7.5 ~16 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 208
summon block_display ~-7 ~15.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col1"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-6.5 ~16 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 209
summon interaction ~-6.5 ~16 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col1"]}
execute positioned ~-6.5 ~16 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 209
summon block_display ~-6 ~15.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col2"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-5.5 ~16 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 210
summon interaction ~-5.5 ~16 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col2"]}
execute positioned ~-5.5 ~16 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 210
summon block_display ~-5 ~15.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col3"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-4.5 ~16 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 211
summon interaction ~-4.5 ~16 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col3"]}
execute positioned ~-4.5 ~16 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 211
summon block_display ~-4 ~15.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col4"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-3.5 ~16 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 212
summon interaction ~-3.5 ~16 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col4"]}
execute positioned ~-3.5 ~16 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 212
summon block_display ~-3 ~15.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col5"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-2.5 ~16 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 213
summon interaction ~-2.5 ~16 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col5"]}
execute positioned ~-2.5 ~16 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 213
summon block_display ~-2 ~15.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col6"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-1.5 ~16 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 214
summon interaction ~-1.5 ~16 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col6"]}
execute positioned ~-1.5 ~16 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 214
summon block_display ~-1 ~15.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col7"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-0.5 ~16 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 215
summon interaction ~-0.5 ~16 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col7"]}
execute positioned ~-0.5 ~16 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 215
summon block_display ~0 ~15.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col8"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~0.5 ~16 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 216
summon interaction ~0.5 ~16 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col8"]}
execute positioned ~0.5 ~16 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 216
summon block_display ~1 ~15.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col9"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~1.5 ~16 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 217
summon interaction ~1.5 ~16 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col9"]}
execute positioned ~1.5 ~16 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 217
summon block_display ~2 ~15.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col10"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~2.5 ~16 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 218
summon interaction ~2.5 ~16 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col10"]}
execute positioned ~2.5 ~16 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 218
summon block_display ~3 ~15.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col11"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~3.5 ~16 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 219
summon interaction ~3.5 ~16 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col11"]}
execute positioned ~3.5 ~16 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 219
summon block_display ~4 ~15.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col12"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~4.5 ~16 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 220
summon interaction ~4.5 ~16 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col12"]}
execute positioned ~4.5 ~16 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 220
summon block_display ~5 ~15.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col13"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~5.5 ~16 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 221
summon interaction ~5.5 ~16 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col13"]}
execute positioned ~5.5 ~16 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 221
summon block_display ~6 ~15.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col14"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~6.5 ~16 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 222
summon interaction ~6.5 ~16 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col14"]}
execute positioned ~6.5 ~16 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 222
summon block_display ~7 ~15.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col15"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~7.5 ~16 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 223
summon interaction ~7.5 ~16 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col15"]}
execute positioned ~7.5 ~16 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 223
summon block_display ~-8 ~16.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col0"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-7.5 ~17 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 224
summon interaction ~-7.5 ~17 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col0"]}
execute positioned ~-7.5 ~17 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 224
summon block_display ~-7 ~16.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col1"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-6.5 ~17 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 225
summon interaction ~-6.5 ~17 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col1"]}
execute positioned ~-6.5 ~17 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 225
summon block_display ~-6 ~16.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col2"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-5.5 ~17 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 226
summon interaction ~-5.5 ~17 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col2"]}
execute positioned ~-5.5 ~17 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 226
summon block_display ~-5 ~16.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col3"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-4.5 ~17 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 227
summon interaction ~-4.5 ~17 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col3"]}
execute positioned ~-4.5 ~17 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 227
summon block_display ~-4 ~16.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col4"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-3.5 ~17 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 228
summon interaction ~-3.5 ~17 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col4"]}
execute positioned ~-3.5 ~17 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 228
summon block_display ~-3 ~16.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col5"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-2.5 ~17 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 229
summon interaction ~-2.5 ~17 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col5"]}
execute positioned ~-2.5 ~17 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 229
summon block_display ~-2 ~16.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col6"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-1.5 ~17 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 230
summon interaction ~-1.5 ~17 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col6"]}
execute positioned ~-1.5 ~17 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 230
summon block_display ~-1 ~16.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col7"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-0.5 ~17 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 231
summon interaction ~-0.5 ~17 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col7"]}
execute positioned ~-0.5 ~17 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 231
summon block_display ~0 ~16.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col8"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~0.5 ~17 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 232
summon interaction ~0.5 ~17 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col8"]}
execute positioned ~0.5 ~17 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 232
summon block_display ~1 ~16.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col9"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~1.5 ~17 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 233
summon interaction ~1.5 ~17 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col9"]}
execute positioned ~1.5 ~17 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 233
summon block_display ~2 ~16.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col10"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~2.5 ~17 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 234
summon interaction ~2.5 ~17 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col10"]}
execute positioned ~2.5 ~17 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 234
summon block_display ~3 ~16.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col11"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~3.5 ~17 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 235
summon interaction ~3.5 ~17 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col11"]}
execute positioned ~3.5 ~17 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 235
summon block_display ~4 ~16.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col12"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~4.5 ~17 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 236
summon interaction ~4.5 ~17 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col12"]}
execute positioned ~4.5 ~17 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 236
summon block_display ~5 ~16.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col13"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~5.5 ~17 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 237
summon interaction ~5.5 ~17 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col13"]}
execute positioned ~5.5 ~17 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 237
summon block_display ~6 ~16.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col14"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~6.5 ~17 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 238
summon interaction ~6.5 ~17 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col14"]}
execute positioned ~6.5 ~17 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 238
summon block_display ~7 ~16.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col15"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~7.5 ~17 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 239
summon interaction ~7.5 ~17 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col15"]}
execute positioned ~7.5 ~17 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 239
summon block_display ~-8 ~17.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col0"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-7.5 ~18 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 240
summon interaction ~-7.5 ~18 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col0"]}
execute positioned ~-7.5 ~18 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 240
summon block_display ~-7 ~17.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col1"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-6.5 ~18 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 241
summon interaction ~-6.5 ~18 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col1"]}
execute positioned ~-6.5 ~18 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 241
summon block_display ~-6 ~17.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col2"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-5.5 ~18 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 242
summon interaction ~-5.5 ~18 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col2"]}
execute positioned ~-5.5 ~18 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 242
summon block_display ~-5 ~17.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col3"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-4.5 ~18 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 243
summon interaction ~-4.5 ~18 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col3"]}
execute positioned ~-4.5 ~18 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 243
summon block_display ~-4 ~17.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col4"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-3.5 ~18 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 244
summon interaction ~-3.5 ~18 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col4"]}
execute positioned ~-3.5 ~18 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 244
summon block_display ~-3 ~17.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col5"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-2.5 ~18 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 245
summon interaction ~-2.5 ~18 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col5"]}
execute positioned ~-2.5 ~18 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 245
summon block_display ~-2 ~17.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col6"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-1.5 ~18 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 246
summon interaction ~-1.5 ~18 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col6"]}
execute positioned ~-1.5 ~18 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 246
summon block_display ~-1 ~17.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col7"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-0.5 ~18 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 247
summon interaction ~-0.5 ~18 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col7"]}
execute positioned ~-0.5 ~18 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 247
summon block_display ~0 ~17.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col8"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~0.5 ~18 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 248
summon interaction ~0.5 ~18 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col8"]}
execute positioned ~0.5 ~18 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 248
summon block_display ~1 ~17.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col9"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~1.5 ~18 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 249
summon interaction ~1.5 ~18 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col9"]}
execute positioned ~1.5 ~18 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 249
summon block_display ~2 ~17.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col10"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~2.5 ~18 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 250
summon interaction ~2.5 ~18 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col10"]}
execute positioned ~2.5 ~18 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 250
summon block_display ~3 ~17.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col11"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~3.5 ~18 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 251
summon interaction ~3.5 ~18 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col11"]}
execute positioned ~3.5 ~18 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 251
summon block_display ~4 ~17.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col12"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~4.5 ~18 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 252
summon interaction ~4.5 ~18 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col12"]}
execute positioned ~4.5 ~18 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 252
summon block_display ~5 ~17.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col13"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~5.5 ~18 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 253
summon interaction ~5.5 ~18 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col13"]}
execute positioned ~5.5 ~18 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 253
summon block_display ~6 ~17.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col14"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~6.5 ~18 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 254
summon interaction ~6.5 ~18 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col14"]}
execute positioned ~6.5 ~18 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 254
summon block_display ~7 ~17.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col15"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~7.5 ~18 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 255
summon interaction ~7.5 ~18 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col15"]}
execute positioned ~7.5 ~18 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 255
summon block_display ~-8 ~2.5 ~0.71 {Tags:["gti.entity","gti.shutter","gti.col0"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,16f,0.3f],translation:[0f,17.4f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-7 ~2.5 ~0.71 {Tags:["gti.entity","gti.shutter","gti.col1"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,16f,0.3f],translation:[0f,17.4f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-6 ~2.5 ~0.71 {Tags:["gti.entity","gti.shutter","gti.col2"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,16f,0.3f],translation:[0f,17.4f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-5 ~2.5 ~0.71 {Tags:["gti.entity","gti.shutter","gti.col3"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,16f,0.3f],translation:[0f,17.4f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-4 ~2.5 ~0.71 {Tags:["gti.entity","gti.shutter","gti.col4"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,16f,0.3f],translation:[0f,17.4f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-3 ~2.5 ~0.71 {Tags:["gti.entity","gti.shutter","gti.col5"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,16f,0.3f],translation:[0f,17.4f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-2 ~2.5 ~0.71 {Tags:["gti.entity","gti.shutter","gti.col6"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,16f,0.3f],translation:[0f,17.4f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-1 ~2.5 ~0.71 {Tags:["gti.entity","gti.shutter","gti.col7"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,16f,0.3f],translation:[0f,17.4f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~0 ~2.5 ~0.71 {Tags:["gti.entity","gti.shutter","gti.col8"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,16f,0.3f],translation:[0f,17.4f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~1 ~2.5 ~0.71 {Tags:["gti.entity","gti.shutter","gti.col9"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,16f,0.3f],translation:[0f,17.4f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~2 ~2.5 ~0.71 {Tags:["gti.entity","gti.shutter","gti.col10"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,16f,0.3f],translation:[0f,17.4f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~3 ~2.5 ~0.71 {Tags:["gti.entity","gti.shutter","gti.col11"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,16f,0.3f],translation:[0f,17.4f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~4 ~2.5 ~0.71 {Tags:["gti.entity","gti.shutter","gti.col12"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,16f,0.3f],translation:[0f,17.4f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~5 ~2.5 ~0.71 {Tags:["gti.entity","gti.shutter","gti.col13"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,16f,0.3f],translation:[0f,17.4f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~6 ~2.5 ~0.71 {Tags:["gti.entity","gti.shutter","gti.col14"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,16f,0.3f],translation:[0f,17.4f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~7 ~2.5 ~0.71 {Tags:["gti.entity","gti.shutter","gti.col15"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,16f,0.3f],translation:[0f,17.4f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-8.7 ~20.77 ~0.2 {Tags:["gti.entity","gti.strip"],block_state:{Name:"minecraft:black_concrete"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[17.4f,1.66f,0.08f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-7.96 ~20.92 ~0.25 {Tags:["gti.entity","gti.strip"],block_state:{Name:"minecraft:black_concrete"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.42f,1.36f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-7.9 ~21.04 ~0.33 {Tags:["gti.entity","gti.strip","gti.pip"],block_state:{Name:"minecraft:structure_void"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.3f,1.12f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-7.75 ~21.6 ~0.38 run scoreboard players set @e[tag=gti.pip,sort=nearest,limit=1] gti.id 0
summon block_display ~-7.46 ~20.92 ~0.25 {Tags:["gti.entity","gti.strip"],block_state:{Name:"minecraft:black_concrete"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.42f,1.36f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-7.4 ~21.04 ~0.33 {Tags:["gti.entity","gti.strip","gti.pip"],block_state:{Name:"minecraft:structure_void"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.3f,1.12f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-7.25 ~21.6 ~0.38 run scoreboard players set @e[tag=gti.pip,sort=nearest,limit=1] gti.id 1
summon block_display ~-6.96 ~20.92 ~0.25 {Tags:["gti.entity","gti.strip"],block_state:{Name:"minecraft:black_concrete"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.42f,1.36f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-6.9 ~21.04 ~0.33 {Tags:["gti.entity","gti.strip","gti.pip"],block_state:{Name:"minecraft:structure_void"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.3f,1.12f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-6.75 ~21.6 ~0.38 run scoreboard players set @e[tag=gti.pip,sort=nearest,limit=1] gti.id 2
summon block_display ~-6.46 ~20.92 ~0.25 {Tags:["gti.entity","gti.strip"],block_state:{Name:"minecraft:black_concrete"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.42f,1.36f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-6.4 ~21.04 ~0.33 {Tags:["gti.entity","gti.strip","gti.pip"],block_state:{Name:"minecraft:structure_void"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.3f,1.12f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-6.25 ~21.6 ~0.38 run scoreboard players set @e[tag=gti.pip,sort=nearest,limit=1] gti.id 3
summon block_display ~-5.96 ~20.92 ~0.25 {Tags:["gti.entity","gti.strip"],block_state:{Name:"minecraft:black_concrete"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.42f,1.36f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-5.9 ~21.04 ~0.33 {Tags:["gti.entity","gti.strip","gti.pip"],block_state:{Name:"minecraft:structure_void"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.3f,1.12f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-5.75 ~21.6 ~0.38 run scoreboard players set @e[tag=gti.pip,sort=nearest,limit=1] gti.id 4
summon block_display ~-5.46 ~20.92 ~0.25 {Tags:["gti.entity","gti.strip"],block_state:{Name:"minecraft:black_concrete"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.42f,1.36f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-5.4 ~21.04 ~0.33 {Tags:["gti.entity","gti.strip","gti.pip"],block_state:{Name:"minecraft:structure_void"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.3f,1.12f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-5.25 ~21.6 ~0.38 run scoreboard players set @e[tag=gti.pip,sort=nearest,limit=1] gti.id 5
summon block_display ~-4.96 ~20.92 ~0.25 {Tags:["gti.entity","gti.strip"],block_state:{Name:"minecraft:black_concrete"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.42f,1.36f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-4.9 ~21.04 ~0.33 {Tags:["gti.entity","gti.strip","gti.pip"],block_state:{Name:"minecraft:structure_void"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.3f,1.12f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-4.75 ~21.6 ~0.38 run scoreboard players set @e[tag=gti.pip,sort=nearest,limit=1] gti.id 6
summon block_display ~-4.46 ~20.92 ~0.25 {Tags:["gti.entity","gti.strip"],block_state:{Name:"minecraft:black_concrete"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.42f,1.36f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-4.4 ~21.04 ~0.33 {Tags:["gti.entity","gti.strip","gti.pip"],block_state:{Name:"minecraft:structure_void"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.3f,1.12f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-4.25 ~21.6 ~0.38 run scoreboard players set @e[tag=gti.pip,sort=nearest,limit=1] gti.id 7
summon block_display ~-3.96 ~20.92 ~0.25 {Tags:["gti.entity","gti.strip"],block_state:{Name:"minecraft:black_concrete"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.42f,1.36f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-3.9 ~21.04 ~0.33 {Tags:["gti.entity","gti.strip","gti.pip"],block_state:{Name:"minecraft:structure_void"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.3f,1.12f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-3.75 ~21.6 ~0.38 run scoreboard players set @e[tag=gti.pip,sort=nearest,limit=1] gti.id 8
summon block_display ~-3.46 ~20.92 ~0.25 {Tags:["gti.entity","gti.strip"],block_state:{Name:"minecraft:black_concrete"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.42f,1.36f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-3.4 ~21.04 ~0.33 {Tags:["gti.entity","gti.strip","gti.pip"],block_state:{Name:"minecraft:structure_void"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.3f,1.12f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-3.25 ~21.6 ~0.38 run scoreboard players set @e[tag=gti.pip,sort=nearest,limit=1] gti.id 9
summon block_display ~-2.96 ~20.92 ~0.25 {Tags:["gti.entity","gti.strip"],block_state:{Name:"minecraft:black_concrete"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.42f,1.36f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-2.9 ~21.04 ~0.33 {Tags:["gti.entity","gti.strip","gti.pip"],block_state:{Name:"minecraft:structure_void"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.3f,1.12f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-2.75 ~21.6 ~0.38 run scoreboard players set @e[tag=gti.pip,sort=nearest,limit=1] gti.id 10
summon block_display ~-2.46 ~20.92 ~0.25 {Tags:["gti.entity","gti.strip"],block_state:{Name:"minecraft:black_concrete"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.42f,1.36f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
summon block_display ~-2.4 ~21.04 ~0.33 {Tags:["gti.entity","gti.strip","gti.pip"],block_state:{Name:"minecraft:structure_void"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[0.3f,1.12f,0.1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-2.25 ~21.6 ~0.38 run scoreboard players set @e[tag=gti.pip,sort=nearest,limit=1] gti.id 11
