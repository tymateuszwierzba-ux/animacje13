function gti:world/0
function gti:world/1
function gti:world/2
function gti:world/3
function gti:world/4
function gti:world/5
