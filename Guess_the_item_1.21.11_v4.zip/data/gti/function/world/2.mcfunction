execute positioned ~2.5 ~7 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 74
summon interaction ~2.5 ~7 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col10"]}
execute positioned ~2.5 ~7 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 74
summon block_display ~3 ~6.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col11"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~3.5 ~7 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 75
summon interaction ~3.5 ~7 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col11"]}
execute positioned ~3.5 ~7 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 75
summon block_display ~4 ~6.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col12"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~4.5 ~7 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 76
summon interaction ~4.5 ~7 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col12"]}
execute positioned ~4.5 ~7 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 76
summon block_display ~5 ~6.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col13"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~5.5 ~7 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 77
summon interaction ~5.5 ~7 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col13"]}
execute positioned ~5.5 ~7 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 77
summon block_display ~6 ~6.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col14"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~6.5 ~7 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 78
summon interaction ~6.5 ~7 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col14"]}
execute positioned ~6.5 ~7 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 78
summon block_display ~7 ~6.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col15"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~7.5 ~7 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 79
summon interaction ~7.5 ~7 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col15"]}
execute positioned ~7.5 ~7 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 79
summon block_display ~-8 ~7.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col0"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-7.5 ~8 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 80
summon interaction ~-7.5 ~8 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col0"]}
execute positioned ~-7.5 ~8 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 80
summon block_display ~-7 ~7.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col1"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-6.5 ~8 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 81
summon interaction ~-6.5 ~8 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col1"]}
execute positioned ~-6.5 ~8 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 81
summon block_display ~-6 ~7.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col2"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-5.5 ~8 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 82
summon interaction ~-5.5 ~8 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col2"]}
execute positioned ~-5.5 ~8 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 82
summon block_display ~-5 ~7.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col3"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-4.5 ~8 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 83
summon interaction ~-4.5 ~8 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col3"]}
execute positioned ~-4.5 ~8 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 83
summon block_display ~-4 ~7.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col4"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-3.5 ~8 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 84
summon interaction ~-3.5 ~8 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col4"]}
execute positioned ~-3.5 ~8 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 84
summon block_display ~-3 ~7.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col5"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-2.5 ~8 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 85
summon interaction ~-2.5 ~8 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col5"]}
execute positioned ~-2.5 ~8 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 85
summon block_display ~-2 ~7.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col6"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-1.5 ~8 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 86
summon interaction ~-1.5 ~8 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col6"]}
execute positioned ~-1.5 ~8 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 86
summon block_display ~-1 ~7.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col7"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-0.5 ~8 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 87
summon interaction ~-0.5 ~8 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col7"]}
execute positioned ~-0.5 ~8 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 87
summon block_display ~0 ~7.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col8"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~0.5 ~8 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 88
summon interaction ~0.5 ~8 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col8"]}
execute positioned ~0.5 ~8 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 88
summon block_display ~1 ~7.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col9"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~1.5 ~8 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 89
summon interaction ~1.5 ~8 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col9"]}
execute positioned ~1.5 ~8 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 89
summon block_display ~2 ~7.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col10"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~2.5 ~8 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 90
summon interaction ~2.5 ~8 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col10"]}
execute positioned ~2.5 ~8 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 90
summon block_display ~3 ~7.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col11"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~3.5 ~8 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 91
summon interaction ~3.5 ~8 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col11"]}
execute positioned ~3.5 ~8 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 91
summon block_display ~4 ~7.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col12"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~4.5 ~8 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 92
summon interaction ~4.5 ~8 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col12"]}
execute positioned ~4.5 ~8 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 92
summon block_display ~5 ~7.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col13"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~5.5 ~8 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 93
summon interaction ~5.5 ~8 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col13"]}
execute positioned ~5.5 ~8 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 93
summon block_display ~6 ~7.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col14"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~6.5 ~8 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 94
summon interaction ~6.5 ~8 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col14"]}
execute positioned ~6.5 ~8 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 94
summon block_display ~7 ~7.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col15"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~7.5 ~8 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 95
summon interaction ~7.5 ~8 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col15"]}
execute positioned ~7.5 ~8 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 95
summon block_display ~-8 ~8.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col0"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-7.5 ~9 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 96
summon interaction ~-7.5 ~9 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col0"]}
execute positioned ~-7.5 ~9 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 96
summon block_display ~-7 ~8.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col1"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-6.5 ~9 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 97
summon interaction ~-6.5 ~9 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col1"]}
execute positioned ~-6.5 ~9 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 97
summon block_display ~-6 ~8.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col2"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-5.5 ~9 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 98
summon interaction ~-5.5 ~9 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col2"]}
execute positioned ~-5.5 ~9 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 98
summon block_display ~-5 ~8.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col3"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-4.5 ~9 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 99
summon interaction ~-4.5 ~9 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col3"]}
execute positioned ~-4.5 ~9 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 99
summon block_display ~-4 ~8.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col4"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-3.5 ~9 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 100
summon interaction ~-3.5 ~9 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col4"]}
execute positioned ~-3.5 ~9 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 100
summon block_display ~-3 ~8.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col5"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-2.5 ~9 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 101
summon interaction ~-2.5 ~9 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col5"]}
execute positioned ~-2.5 ~9 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 101
summon block_display ~-2 ~8.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col6"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-1.5 ~9 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 102
summon interaction ~-1.5 ~9 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col6"]}
execute positioned ~-1.5 ~9 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 102
summon block_display ~-1 ~8.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col7"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-0.5 ~9 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 103
summon interaction ~-0.5 ~9 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col7"]}
execute positioned ~-0.5 ~9 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 103
summon block_display ~0 ~8.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col8"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~0.5 ~9 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 104
summon interaction ~0.5 ~9 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col8"]}
execute positioned ~0.5 ~9 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 104
summon block_display ~1 ~8.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col9"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~1.5 ~9 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 105
summon interaction ~1.5 ~9 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col9"]}
execute positioned ~1.5 ~9 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 105
summon block_display ~2 ~8.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col10"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~2.5 ~9 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 106
summon interaction ~2.5 ~9 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col10"]}
execute positioned ~2.5 ~9 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 106
summon block_display ~3 ~8.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col11"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~3.5 ~9 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 107
summon interaction ~3.5 ~9 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col11"]}
execute positioned ~3.5 ~9 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 107
summon block_display ~4 ~8.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col12"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~4.5 ~9 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 108
summon interaction ~4.5 ~9 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col12"]}
execute positioned ~4.5 ~9 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 108
summon block_display ~5 ~8.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col13"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~5.5 ~9 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 109
summon interaction ~5.5 ~9 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col13"]}
execute positioned ~5.5 ~9 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 109
summon block_display ~6 ~8.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col14"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~6.5 ~9 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 110
summon interaction ~6.5 ~9 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col14"]}
execute positioned ~6.5 ~9 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 110
summon block_display ~7 ~8.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col15"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~7.5 ~9 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 111
summon interaction ~7.5 ~9 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col15"]}
execute positioned ~7.5 ~9 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 111
summon block_display ~-8 ~9.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col0"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-7.5 ~10 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 112
summon interaction ~-7.5 ~10 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col0"]}
execute positioned ~-7.5 ~10 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 112
summon block_display ~-7 ~9.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col1"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-6.5 ~10 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 113
summon interaction ~-6.5 ~10 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col1"]}
execute positioned ~-6.5 ~10 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 113
summon block_display ~-6 ~9.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col2"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-5.5 ~10 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 114
summon interaction ~-5.5 ~10 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col2"]}
execute positioned ~-5.5 ~10 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 114
summon block_display ~-5 ~9.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col3"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-4.5 ~10 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 115
summon interaction ~-4.5 ~10 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col3"]}
execute positioned ~-4.5 ~10 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 115
summon block_display ~-4 ~9.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col4"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-3.5 ~10 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 116
summon interaction ~-3.5 ~10 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col4"]}
execute positioned ~-3.5 ~10 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 116
summon block_display ~-3 ~9.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col5"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-2.5 ~10 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 117
summon interaction ~-2.5 ~10 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col5"]}
execute positioned ~-2.5 ~10 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 117
summon block_display ~-2 ~9.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col6"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-1.5 ~10 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 118
summon interaction ~-1.5 ~10 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col6"]}
execute positioned ~-1.5 ~10 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 118
summon block_display ~-1 ~9.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col7"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-0.5 ~10 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 119
summon interaction ~-0.5 ~10 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col7"]}
execute positioned ~-0.5 ~10 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 119
summon block_display ~0 ~9.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col8"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~0.5 ~10 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 120
summon interaction ~0.5 ~10 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col8"]}
execute positioned ~0.5 ~10 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 120
summon block_display ~1 ~9.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col9"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~1.5 ~10 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 121
summon interaction ~1.5 ~10 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col9"]}
execute positioned ~1.5 ~10 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 121
summon block_display ~2 ~9.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col10"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~2.5 ~10 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 122
summon interaction ~2.5 ~10 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col10"]}
execute positioned ~2.5 ~10 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 122
summon block_display ~3 ~9.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col11"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~3.5 ~10 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 123
summon interaction ~3.5 ~10 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col11"]}
execute positioned ~3.5 ~10 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 123
summon block_display ~4 ~9.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col12"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~4.5 ~10 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 124
summon interaction ~4.5 ~10 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col12"]}
execute positioned ~4.5 ~10 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 124
summon block_display ~5 ~9.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col13"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~5.5 ~10 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 125
summon interaction ~5.5 ~10 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col13"]}
execute positioned ~5.5 ~10 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 125
summon block_display ~6 ~9.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col14"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~6.5 ~10 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 126
summon interaction ~6.5 ~10 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col14"]}
execute positioned ~6.5 ~10 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 126
summon block_display ~7 ~9.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col15"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~7.5 ~10 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 127
summon interaction ~7.5 ~10 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col15"]}
execute positioned ~7.5 ~10 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 127
summon block_display ~-8 ~10.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col0"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-7.5 ~11 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 128
summon interaction ~-7.5 ~11 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col0"]}
execute positioned ~-7.5 ~11 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 128
summon block_display ~-7 ~10.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col1"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-6.5 ~11 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 129
summon interaction ~-6.5 ~11 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col1"]}
execute positioned ~-6.5 ~11 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 129
summon block_display ~-6 ~10.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col2"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-5.5 ~11 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 130
summon interaction ~-5.5 ~11 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col2"]}
execute positioned ~-5.5 ~11 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 130
summon block_display ~-5 ~10.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col3"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-4.5 ~11 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 131
summon interaction ~-4.5 ~11 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col3"]}
execute positioned ~-4.5 ~11 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 131
summon block_display ~-4 ~10.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col4"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-3.5 ~11 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 132
summon interaction ~-3.5 ~11 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col4"]}
execute positioned ~-3.5 ~11 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 132
summon block_display ~-3 ~10.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col5"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-2.5 ~11 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 133
summon interaction ~-2.5 ~11 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col5"]}
execute positioned ~-2.5 ~11 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 133
summon block_display ~-2 ~10.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col6"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-1.5 ~11 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 134
summon interaction ~-1.5 ~11 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col6"]}
execute positioned ~-1.5 ~11 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 134
summon block_display ~-1 ~10.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col7"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-0.5 ~11 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 135
summon interaction ~-0.5 ~11 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col7"]}
execute positioned ~-0.5 ~11 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 135
summon block_display ~0 ~10.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col8"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~0.5 ~11 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 136
summon interaction ~0.5 ~11 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col8"]}
execute positioned ~0.5 ~11 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 136
summon block_display ~1 ~10.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col9"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~1.5 ~11 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 137
summon interaction ~1.5 ~11 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col9"]}
execute positioned ~1.5 ~11 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 137
summon block_display ~2 ~10.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col10"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~2.5 ~11 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 138
summon interaction ~2.5 ~11 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col10"]}
execute positioned ~2.5 ~11 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 138
summon block_display ~3 ~10.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col11"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
