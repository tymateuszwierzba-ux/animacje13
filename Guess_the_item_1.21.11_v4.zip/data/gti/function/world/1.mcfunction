execute positioned ~1.5 ~3 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 9
summon interaction ~1.5 ~3 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col9"]}
execute positioned ~1.5 ~3 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 9
summon block_display ~2 ~2.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col10"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~2.5 ~3 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 10
summon interaction ~2.5 ~3 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col10"]}
execute positioned ~2.5 ~3 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 10
summon block_display ~3 ~2.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col11"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~3.5 ~3 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 11
summon interaction ~3.5 ~3 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col11"]}
execute positioned ~3.5 ~3 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 11
summon block_display ~4 ~2.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col12"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~4.5 ~3 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 12
summon interaction ~4.5 ~3 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col12"]}
execute positioned ~4.5 ~3 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 12
summon block_display ~5 ~2.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col13"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~5.5 ~3 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 13
summon interaction ~5.5 ~3 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col13"]}
execute positioned ~5.5 ~3 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 13
summon block_display ~6 ~2.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col14"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~6.5 ~3 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 14
summon interaction ~6.5 ~3 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col14"]}
execute positioned ~6.5 ~3 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 14
summon block_display ~7 ~2.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col15"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~7.5 ~3 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 15
summon interaction ~7.5 ~3 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col15"]}
execute positioned ~7.5 ~3 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 15
summon block_display ~-8 ~3.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col0"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-7.5 ~4 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 16
summon interaction ~-7.5 ~4 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col0"]}
execute positioned ~-7.5 ~4 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 16
summon block_display ~-7 ~3.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col1"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-6.5 ~4 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 17
summon interaction ~-6.5 ~4 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col1"]}
execute positioned ~-6.5 ~4 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 17
summon block_display ~-6 ~3.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col2"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-5.5 ~4 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 18
summon interaction ~-5.5 ~4 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col2"]}
execute positioned ~-5.5 ~4 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 18
summon block_display ~-5 ~3.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col3"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-4.5 ~4 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 19
summon interaction ~-4.5 ~4 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col3"]}
execute positioned ~-4.5 ~4 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 19
summon block_display ~-4 ~3.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col4"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-3.5 ~4 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 20
summon interaction ~-3.5 ~4 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col4"]}
execute positioned ~-3.5 ~4 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 20
summon block_display ~-3 ~3.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col5"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-2.5 ~4 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 21
summon interaction ~-2.5 ~4 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col5"]}
execute positioned ~-2.5 ~4 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 21
summon block_display ~-2 ~3.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col6"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-1.5 ~4 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 22
summon interaction ~-1.5 ~4 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col6"]}
execute positioned ~-1.5 ~4 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 22
summon block_display ~-1 ~3.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col7"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-0.5 ~4 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 23
summon interaction ~-0.5 ~4 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col7"]}
execute positioned ~-0.5 ~4 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 23
summon block_display ~0 ~3.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col8"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~0.5 ~4 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 24
summon interaction ~0.5 ~4 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col8"]}
execute positioned ~0.5 ~4 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 24
summon block_display ~1 ~3.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col9"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~1.5 ~4 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 25
summon interaction ~1.5 ~4 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col9"]}
execute positioned ~1.5 ~4 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 25
summon block_display ~2 ~3.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col10"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~2.5 ~4 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 26
summon interaction ~2.5 ~4 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col10"]}
execute positioned ~2.5 ~4 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 26
summon block_display ~3 ~3.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col11"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~3.5 ~4 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 27
summon interaction ~3.5 ~4 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col11"]}
execute positioned ~3.5 ~4 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 27
summon block_display ~4 ~3.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col12"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~4.5 ~4 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 28
summon interaction ~4.5 ~4 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col12"]}
execute positioned ~4.5 ~4 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 28
summon block_display ~5 ~3.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col13"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~5.5 ~4 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 29
summon interaction ~5.5 ~4 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col13"]}
execute positioned ~5.5 ~4 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 29
summon block_display ~6 ~3.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col14"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~6.5 ~4 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 30
summon interaction ~6.5 ~4 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col14"]}
execute positioned ~6.5 ~4 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 30
summon block_display ~7 ~3.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col15"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~7.5 ~4 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 31
summon interaction ~7.5 ~4 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col15"]}
execute positioned ~7.5 ~4 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 31
summon block_display ~-8 ~4.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col0"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-7.5 ~5 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 32
summon interaction ~-7.5 ~5 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col0"]}
execute positioned ~-7.5 ~5 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 32
summon block_display ~-7 ~4.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col1"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-6.5 ~5 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 33
summon interaction ~-6.5 ~5 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col1"]}
execute positioned ~-6.5 ~5 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 33
summon block_display ~-6 ~4.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col2"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-5.5 ~5 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 34
summon interaction ~-5.5 ~5 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col2"]}
execute positioned ~-5.5 ~5 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 34
summon block_display ~-5 ~4.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col3"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-4.5 ~5 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 35
summon interaction ~-4.5 ~5 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col3"]}
execute positioned ~-4.5 ~5 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 35
summon block_display ~-4 ~4.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col4"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-3.5 ~5 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 36
summon interaction ~-3.5 ~5 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col4"]}
execute positioned ~-3.5 ~5 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 36
summon block_display ~-3 ~4.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col5"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-2.5 ~5 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 37
summon interaction ~-2.5 ~5 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col5"]}
execute positioned ~-2.5 ~5 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 37
summon block_display ~-2 ~4.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col6"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-1.5 ~5 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 38
summon interaction ~-1.5 ~5 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col6"]}
execute positioned ~-1.5 ~5 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 38
summon block_display ~-1 ~4.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col7"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-0.5 ~5 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 39
summon interaction ~-0.5 ~5 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col7"]}
execute positioned ~-0.5 ~5 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 39
summon block_display ~0 ~4.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col8"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~0.5 ~5 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 40
summon interaction ~0.5 ~5 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col8"]}
execute positioned ~0.5 ~5 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 40
summon block_display ~1 ~4.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col9"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~1.5 ~5 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 41
summon interaction ~1.5 ~5 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col9"]}
execute positioned ~1.5 ~5 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 41
summon block_display ~2 ~4.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col10"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~2.5 ~5 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 42
summon interaction ~2.5 ~5 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col10"]}
execute positioned ~2.5 ~5 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 42
summon block_display ~3 ~4.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col11"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~3.5 ~5 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 43
summon interaction ~3.5 ~5 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col11"]}
execute positioned ~3.5 ~5 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 43
summon block_display ~4 ~4.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col12"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~4.5 ~5 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 44
summon interaction ~4.5 ~5 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col12"]}
execute positioned ~4.5 ~5 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 44
summon block_display ~5 ~4.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col13"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~5.5 ~5 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 45
summon interaction ~5.5 ~5 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col13"]}
execute positioned ~5.5 ~5 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 45
summon block_display ~6 ~4.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col14"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~6.5 ~5 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 46
summon interaction ~6.5 ~5 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col14"]}
execute positioned ~6.5 ~5 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 46
summon block_display ~7 ~4.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col15"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~7.5 ~5 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 47
summon interaction ~7.5 ~5 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col15"]}
execute positioned ~7.5 ~5 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 47
summon block_display ~-8 ~5.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col0"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-7.5 ~6 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 48
summon interaction ~-7.5 ~6 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col0"]}
execute positioned ~-7.5 ~6 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 48
summon block_display ~-7 ~5.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col1"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-6.5 ~6 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 49
summon interaction ~-6.5 ~6 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col1"]}
execute positioned ~-6.5 ~6 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 49
summon block_display ~-6 ~5.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col2"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-5.5 ~6 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 50
summon interaction ~-5.5 ~6 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col2"]}
execute positioned ~-5.5 ~6 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 50
summon block_display ~-5 ~5.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col3"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-4.5 ~6 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 51
summon interaction ~-4.5 ~6 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col3"]}
execute positioned ~-4.5 ~6 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 51
summon block_display ~-4 ~5.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col4"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-3.5 ~6 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 52
summon interaction ~-3.5 ~6 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col4"]}
execute positioned ~-3.5 ~6 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 52
summon block_display ~-3 ~5.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col5"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-2.5 ~6 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 53
summon interaction ~-2.5 ~6 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col5"]}
execute positioned ~-2.5 ~6 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 53
summon block_display ~-2 ~5.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col6"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-1.5 ~6 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 54
summon interaction ~-1.5 ~6 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col6"]}
execute positioned ~-1.5 ~6 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 54
summon block_display ~-1 ~5.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col7"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-0.5 ~6 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 55
summon interaction ~-0.5 ~6 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col7"]}
execute positioned ~-0.5 ~6 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 55
summon block_display ~0 ~5.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col8"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~0.5 ~6 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 56
summon interaction ~0.5 ~6 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col8"]}
execute positioned ~0.5 ~6 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 56
summon block_display ~1 ~5.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col9"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~1.5 ~6 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 57
summon interaction ~1.5 ~6 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col9"]}
execute positioned ~1.5 ~6 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 57
summon block_display ~2 ~5.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col10"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~2.5 ~6 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 58
summon interaction ~2.5 ~6 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col10"]}
execute positioned ~2.5 ~6 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 58
summon block_display ~3 ~5.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col11"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~3.5 ~6 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 59
summon interaction ~3.5 ~6 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col11"]}
execute positioned ~3.5 ~6 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 59
summon block_display ~4 ~5.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col12"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~4.5 ~6 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 60
summon interaction ~4.5 ~6 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col12"]}
execute positioned ~4.5 ~6 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 60
summon block_display ~5 ~5.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col13"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~5.5 ~6 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 61
summon interaction ~5.5 ~6 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col13"]}
execute positioned ~5.5 ~6 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 61
summon block_display ~6 ~5.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col14"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~6.5 ~6 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 62
summon interaction ~6.5 ~6 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col14"]}
execute positioned ~6.5 ~6 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 62
summon block_display ~7 ~5.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col15"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~7.5 ~6 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 63
summon interaction ~7.5 ~6 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col15"]}
execute positioned ~7.5 ~6 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 63
summon block_display ~-8 ~6.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col0"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-7.5 ~7 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 64
summon interaction ~-7.5 ~7 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col0"]}
execute positioned ~-7.5 ~7 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 64
summon block_display ~-7 ~6.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col1"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-6.5 ~7 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 65
summon interaction ~-6.5 ~7 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col1"]}
execute positioned ~-6.5 ~7 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 65
summon block_display ~-6 ~6.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col2"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-5.5 ~7 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 66
summon interaction ~-5.5 ~7 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col2"]}
execute positioned ~-5.5 ~7 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 66
summon block_display ~-5 ~6.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col3"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-4.5 ~7 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 67
summon interaction ~-4.5 ~7 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col3"]}
execute positioned ~-4.5 ~7 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 67
summon block_display ~-4 ~6.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col4"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-3.5 ~7 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 68
summon interaction ~-3.5 ~7 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col4"]}
execute positioned ~-3.5 ~7 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 68
summon block_display ~-3 ~6.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col5"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-2.5 ~7 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 69
summon interaction ~-2.5 ~7 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col5"]}
execute positioned ~-2.5 ~7 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 69
summon block_display ~-2 ~6.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col6"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-1.5 ~7 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 70
summon interaction ~-1.5 ~7 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col6"]}
execute positioned ~-1.5 ~7 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 70
summon block_display ~-1 ~6.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col7"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-0.5 ~7 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 71
summon interaction ~-0.5 ~7 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col7"]}
execute positioned ~-0.5 ~7 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 71
summon block_display ~0 ~6.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col8"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~0.5 ~7 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 72
summon interaction ~0.5 ~7 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col8"]}
execute positioned ~0.5 ~7 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 72
summon block_display ~1 ~6.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col9"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~1.5 ~7 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 73
summon interaction ~1.5 ~7 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col9"]}
execute positioned ~1.5 ~7 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 73
summon block_display ~2 ~6.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col10"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
