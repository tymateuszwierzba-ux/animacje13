execute positioned ~3.5 ~11 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 139
summon interaction ~3.5 ~11 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col11"]}
execute positioned ~3.5 ~11 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 139
summon block_display ~4 ~10.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col12"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~4.5 ~11 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 140
summon interaction ~4.5 ~11 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col12"]}
execute positioned ~4.5 ~11 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 140
summon block_display ~5 ~10.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col13"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~5.5 ~11 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 141
summon interaction ~5.5 ~11 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col13"]}
execute positioned ~5.5 ~11 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 141
summon block_display ~6 ~10.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col14"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~6.5 ~11 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 142
summon interaction ~6.5 ~11 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col14"]}
execute positioned ~6.5 ~11 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 142
summon block_display ~7 ~10.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col15"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~7.5 ~11 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 143
summon interaction ~7.5 ~11 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col15"]}
execute positioned ~7.5 ~11 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 143
summon block_display ~-8 ~11.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col0"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-7.5 ~12 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 144
summon interaction ~-7.5 ~12 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col0"]}
execute positioned ~-7.5 ~12 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 144
summon block_display ~-7 ~11.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col1"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-6.5 ~12 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 145
summon interaction ~-6.5 ~12 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col1"]}
execute positioned ~-6.5 ~12 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 145
summon block_display ~-6 ~11.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col2"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-5.5 ~12 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 146
summon interaction ~-5.5 ~12 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col2"]}
execute positioned ~-5.5 ~12 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 146
summon block_display ~-5 ~11.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col3"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-4.5 ~12 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 147
summon interaction ~-4.5 ~12 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col3"]}
execute positioned ~-4.5 ~12 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 147
summon block_display ~-4 ~11.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col4"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-3.5 ~12 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 148
summon interaction ~-3.5 ~12 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col4"]}
execute positioned ~-3.5 ~12 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 148
summon block_display ~-3 ~11.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col5"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-2.5 ~12 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 149
summon interaction ~-2.5 ~12 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col5"]}
execute positioned ~-2.5 ~12 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 149
summon block_display ~-2 ~11.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col6"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-1.5 ~12 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 150
summon interaction ~-1.5 ~12 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col6"]}
execute positioned ~-1.5 ~12 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 150
summon block_display ~-1 ~11.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col7"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-0.5 ~12 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 151
summon interaction ~-0.5 ~12 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col7"]}
execute positioned ~-0.5 ~12 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 151
summon block_display ~0 ~11.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col8"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~0.5 ~12 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 152
summon interaction ~0.5 ~12 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col8"]}
execute positioned ~0.5 ~12 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 152
summon block_display ~1 ~11.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col9"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~1.5 ~12 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 153
summon interaction ~1.5 ~12 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col9"]}
execute positioned ~1.5 ~12 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 153
summon block_display ~2 ~11.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col10"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~2.5 ~12 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 154
summon interaction ~2.5 ~12 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col10"]}
execute positioned ~2.5 ~12 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 154
summon block_display ~3 ~11.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col11"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~3.5 ~12 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 155
summon interaction ~3.5 ~12 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col11"]}
execute positioned ~3.5 ~12 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 155
summon block_display ~4 ~11.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col12"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~4.5 ~12 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 156
summon interaction ~4.5 ~12 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col12"]}
execute positioned ~4.5 ~12 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 156
summon block_display ~5 ~11.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col13"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~5.5 ~12 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 157
summon interaction ~5.5 ~12 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col13"]}
execute positioned ~5.5 ~12 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 157
summon block_display ~6 ~11.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col14"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~6.5 ~12 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 158
summon interaction ~6.5 ~12 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col14"]}
execute positioned ~6.5 ~12 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 158
summon block_display ~7 ~11.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col15"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~7.5 ~12 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 159
summon interaction ~7.5 ~12 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col15"]}
execute positioned ~7.5 ~12 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 159
summon block_display ~-8 ~12.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col0"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-7.5 ~13 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 160
summon interaction ~-7.5 ~13 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col0"]}
execute positioned ~-7.5 ~13 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 160
summon block_display ~-7 ~12.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col1"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-6.5 ~13 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 161
summon interaction ~-6.5 ~13 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col1"]}
execute positioned ~-6.5 ~13 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 161
summon block_display ~-6 ~12.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col2"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-5.5 ~13 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 162
summon interaction ~-5.5 ~13 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col2"]}
execute positioned ~-5.5 ~13 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 162
summon block_display ~-5 ~12.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col3"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-4.5 ~13 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 163
summon interaction ~-4.5 ~13 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col3"]}
execute positioned ~-4.5 ~13 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 163
summon block_display ~-4 ~12.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col4"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-3.5 ~13 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 164
summon interaction ~-3.5 ~13 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col4"]}
execute positioned ~-3.5 ~13 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 164
summon block_display ~-3 ~12.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col5"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-2.5 ~13 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 165
summon interaction ~-2.5 ~13 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col5"]}
execute positioned ~-2.5 ~13 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 165
summon block_display ~-2 ~12.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col6"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-1.5 ~13 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 166
summon interaction ~-1.5 ~13 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col6"]}
execute positioned ~-1.5 ~13 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 166
summon block_display ~-1 ~12.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col7"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-0.5 ~13 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 167
summon interaction ~-0.5 ~13 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col7"]}
execute positioned ~-0.5 ~13 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 167
summon block_display ~0 ~12.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col8"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~0.5 ~13 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 168
summon interaction ~0.5 ~13 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col8"]}
execute positioned ~0.5 ~13 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 168
summon block_display ~1 ~12.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col9"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~1.5 ~13 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 169
summon interaction ~1.5 ~13 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col9"]}
execute positioned ~1.5 ~13 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 169
summon block_display ~2 ~12.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col10"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~2.5 ~13 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 170
summon interaction ~2.5 ~13 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col10"]}
execute positioned ~2.5 ~13 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 170
summon block_display ~3 ~12.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col11"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~3.5 ~13 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 171
summon interaction ~3.5 ~13 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col11"]}
execute positioned ~3.5 ~13 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 171
summon block_display ~4 ~12.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col12"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~4.5 ~13 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 172
summon interaction ~4.5 ~13 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col12"]}
execute positioned ~4.5 ~13 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 172
summon block_display ~5 ~12.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col13"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~5.5 ~13 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 173
summon interaction ~5.5 ~13 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col13"]}
execute positioned ~5.5 ~13 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 173
summon block_display ~6 ~12.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col14"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~6.5 ~13 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 174
summon interaction ~6.5 ~13 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col14"]}
execute positioned ~6.5 ~13 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 174
summon block_display ~7 ~12.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col15"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~7.5 ~13 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 175
summon interaction ~7.5 ~13 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col15"]}
execute positioned ~7.5 ~13 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 175
summon block_display ~-8 ~13.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col0"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-7.5 ~14 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 176
summon interaction ~-7.5 ~14 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col0"]}
execute positioned ~-7.5 ~14 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 176
summon block_display ~-7 ~13.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col1"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-6.5 ~14 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 177
summon interaction ~-6.5 ~14 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col1"]}
execute positioned ~-6.5 ~14 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 177
summon block_display ~-6 ~13.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col2"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-5.5 ~14 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 178
summon interaction ~-5.5 ~14 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col2"]}
execute positioned ~-5.5 ~14 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 178
summon block_display ~-5 ~13.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col3"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-4.5 ~14 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 179
summon interaction ~-4.5 ~14 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col3"]}
execute positioned ~-4.5 ~14 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 179
summon block_display ~-4 ~13.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col4"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-3.5 ~14 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 180
summon interaction ~-3.5 ~14 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col4"]}
execute positioned ~-3.5 ~14 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 180
summon block_display ~-3 ~13.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col5"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-2.5 ~14 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 181
summon interaction ~-2.5 ~14 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col5"]}
execute positioned ~-2.5 ~14 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 181
summon block_display ~-2 ~13.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col6"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-1.5 ~14 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 182
summon interaction ~-1.5 ~14 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col6"]}
execute positioned ~-1.5 ~14 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 182
summon block_display ~-1 ~13.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col7"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-0.5 ~14 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 183
summon interaction ~-0.5 ~14 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col7"]}
execute positioned ~-0.5 ~14 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 183
summon block_display ~0 ~13.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col8"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~0.5 ~14 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 184
summon interaction ~0.5 ~14 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col8"]}
execute positioned ~0.5 ~14 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 184
summon block_display ~1 ~13.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col9"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~1.5 ~14 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 185
summon interaction ~1.5 ~14 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col9"]}
execute positioned ~1.5 ~14 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 185
summon block_display ~2 ~13.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col10"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~2.5 ~14 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 186
summon interaction ~2.5 ~14 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col10"]}
execute positioned ~2.5 ~14 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 186
summon block_display ~3 ~13.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col11"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~3.5 ~14 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 187
summon interaction ~3.5 ~14 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col11"]}
execute positioned ~3.5 ~14 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 187
summon block_display ~4 ~13.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col12"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~4.5 ~14 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 188
summon interaction ~4.5 ~14 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col12"]}
execute positioned ~4.5 ~14 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 188
summon block_display ~5 ~13.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col13"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~5.5 ~14 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 189
summon interaction ~5.5 ~14 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col13"]}
execute positioned ~5.5 ~14 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 189
summon block_display ~6 ~13.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col14"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~6.5 ~14 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 190
summon interaction ~6.5 ~14 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col14"]}
execute positioned ~6.5 ~14 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 190
summon block_display ~7 ~13.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col15"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~7.5 ~14 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 191
summon interaction ~7.5 ~14 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col15"]}
execute positioned ~7.5 ~14 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 191
summon block_display ~-8 ~14.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col0"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-7.5 ~15 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 192
summon interaction ~-7.5 ~15 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col0"]}
execute positioned ~-7.5 ~15 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 192
summon block_display ~-7 ~14.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col1"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-6.5 ~15 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 193
summon interaction ~-6.5 ~15 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col1"]}
execute positioned ~-6.5 ~15 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 193
summon block_display ~-6 ~14.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col2"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-5.5 ~15 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 194
summon interaction ~-5.5 ~15 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col2"]}
execute positioned ~-5.5 ~15 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 194
summon block_display ~-5 ~14.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col3"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-4.5 ~15 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 195
summon interaction ~-4.5 ~15 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col3"]}
execute positioned ~-4.5 ~15 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 195
summon block_display ~-4 ~14.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col4"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-3.5 ~15 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 196
summon interaction ~-3.5 ~15 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col4"]}
execute positioned ~-3.5 ~15 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 196
summon block_display ~-3 ~14.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col5"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-2.5 ~15 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 197
summon interaction ~-2.5 ~15 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col5"]}
execute positioned ~-2.5 ~15 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 197
summon block_display ~-2 ~14.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col6"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-1.5 ~15 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 198
summon interaction ~-1.5 ~15 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col6"]}
execute positioned ~-1.5 ~15 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 198
summon block_display ~-1 ~14.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col7"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~-0.5 ~15 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 199
summon interaction ~-0.5 ~15 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col7"]}
execute positioned ~-0.5 ~15 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 199
summon block_display ~0 ~14.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col8"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~0.5 ~15 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 200
summon interaction ~0.5 ~15 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col8"]}
execute positioned ~0.5 ~15 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 200
summon block_display ~1 ~14.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col9"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~1.5 ~15 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 201
summon interaction ~1.5 ~15 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col9"]}
execute positioned ~1.5 ~15 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 201
summon block_display ~2 ~14.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col10"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~2.5 ~15 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 202
summon interaction ~2.5 ~15 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col10"]}
execute positioned ~2.5 ~15 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 202
summon block_display ~3 ~14.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col11"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
execute positioned ~3.5 ~15 ~0 run scoreboard players set @e[tag=gti.cell,sort=nearest,limit=1] gti.id 203
summon interaction ~3.5 ~15 ~0.62 {width:0.98f,height:0.98f,response:1b,Tags:["gti.entity","gti.click","gti.col11"]}
execute positioned ~3.5 ~15 ~0.62 run scoreboard players set @e[tag=gti.click,sort=nearest,limit=1] gti.id 203
summon block_display ~4 ~14.5 ~-0.5 {Tags:["gti.entity","gti.cell","gti.col12"],block_state:{Name:"minecraft:bedrock"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
