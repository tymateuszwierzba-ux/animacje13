dialog show @s gti:rules
