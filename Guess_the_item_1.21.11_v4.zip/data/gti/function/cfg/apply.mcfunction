$data modify storage gti:tmp limit set value $(limit)
$data modify storage gti:tmp batch set value $(batch)
$data modify storage gti:tmp initial set value $(initial)
$data modify storage gti:tmp timer set value $(timer)
$data modify storage gti:tmp hints set value $(hints)
$data modify storage gti:tmp mode set value "$(mode)"
function gti:cfg/store with storage gti:tmp
$tellraw @s [{"text":"Settings saved. ","color":"#8BE28B"},{"text":"max attempts: ","color":"gray"},{"text":"$(limit)","color":"#F6CF84"},{"text":"  cells/click: ","color":"gray"},{"text":"$(batch)","color":"#61EDE5"},{"text":"  mode: ","color":"gray"},{"text":"$(mode)","color":"#B295FF"}]
dialog show @s gti:settings
