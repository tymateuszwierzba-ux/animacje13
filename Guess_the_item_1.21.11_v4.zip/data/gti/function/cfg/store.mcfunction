$data modify storage gti:cfg mode_str set value "$(mode)"
$scoreboard players set #limit gti.var $(limit)
$scoreboard players set #batch gti.var $(batch)
$scoreboard players set #initial gti.var $(initial)
$scoreboard players set #timer_sec gti.var $(timer)
$scoreboard players set #hints_on gti.var $(hints)
scoreboard players set #mode gti.var 0
execute if data storage gti:cfg {mode_str:"peek"} run scoreboard players set #mode gti.var 1
execute if data storage gti:cfg {mode_str:"auto"} run scoreboard players set #mode gti.var 2
$data modify storage gti:cfg settings.limit set value $(limit)
$data modify storage gti:cfg settings.batch set value $(batch)
$data modify storage gti:cfg settings.initial set value $(initial)
$data modify storage gti:cfg settings.timer set value $(timer)
$data modify storage gti:cfg settings.hints set value $(hints)
$data modify storage gti:cfg settings.mode set value "$(mode)"
function gti:strip/refresh
function gti:hud/refresh
