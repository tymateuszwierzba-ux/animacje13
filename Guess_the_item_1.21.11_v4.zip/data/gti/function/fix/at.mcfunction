function gti:remove
execute align xyz positioned ~ ~ ~ run function gti:world/build
scoreboard players set #state gti.var 0
scoreboard players set #result gti.var 2
scoreboard players set #anim gti.var 0
scoreboard players set #picked gti.var 0
scoreboard players set #shown gti.var 0
scoreboard players set #g_intro gti.var 0
scoreboard players set #g_fin gti.var 0
scoreboard players set #did_seal gti.var 0
scoreboard players set #did_restore gti.var 0
scoreboard players set #did_pick gti.var 0
scoreboard players set #did_open gti.var 0
scoreboard players set #did_go gti.var 0
scoreboard players set #did_confetti gti.var 0
scoreboard players set #did_fire gti.var 0
scoreboard players set #did_end gti.var 0
scoreboard players set #did_end2 gti.var 0
scoreboard players set #did_end3 gti.var 0
scoreboard players set #used gti.var 0
scoreboard players set #revealed gti.var 0
scoreboard players set #hint_stage gti.var 0
tag @a remove gti.player
tag @a remove gti.host
tag @s add gti.player
tag @s add gti.host
function gti:round/reset
function gti:fx/restore
function gti:fx/curtain_open
function gti:strip/refresh
function gti:hud/refresh
data modify storage gti:cfg status set value "PRESS START"
data modify storage gti:cfg hint set value "NO HINT YET"
tellraw @s [{"text":"Board repaired. ","color":"#8BE28B"},{"text":"Press START ROUND in the menu.","color":"gray"}]
dialog show @s gti:menu
