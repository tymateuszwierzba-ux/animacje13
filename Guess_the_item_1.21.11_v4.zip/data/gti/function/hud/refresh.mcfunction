execute store result storage gti:ui round int 1 run scoreboard players get #round gti.var
execute store result storage gti:ui used int 1 run scoreboard players get #used gti.var
execute store result storage gti:ui found int 1 run scoreboard players get #revealed gti.var
execute if score #limit gti.var matches 1.. run scoreboard players operation #left gti.var = #limit gti.var
execute if score #limit gti.var matches 1.. run scoreboard players operation #left gti.var -= #used gti.var
execute if score #limit gti.var matches 1.. if score #left gti.var matches ..0 run scoreboard players set #left gti.var 0
execute if score #limit gti.var matches 0 run data modify storage gti:ui left set value "∞"
execute if score #limit gti.var matches 1.. store result storage gti:ui left int 1 run scoreboard players get #left gti.var
scoreboard players operation #sec gti.var = #time gti.var
scoreboard players operation #sec gti.var /= #twenty gti.var
scoreboard players operation #mm gti.var = #sec gti.var
scoreboard players operation #mm gti.var /= #sixty gti.var
scoreboard players operation #ss gti.var = #sec gti.var
scoreboard players operation #ss gti.var %= #sixty gti.var
data modify storage gti:ui mm0 set value ""
data modify storage gti:ui ss0 set value ""
execute if score #mm gti.var matches ..9 run data modify storage gti:ui mm0 set value "0"
execute if score #ss gti.var matches ..9 run data modify storage gti:ui ss0 set value "0"
execute store result storage gti:ui mm int 1 run scoreboard players get #mm gti.var
execute store result storage gti:ui ss int 1 run scoreboard players get #ss gti.var
data modify storage gti:ui hint set from storage gti:cfg hint
data modify storage gti:ui status set from storage gti:cfg status
function gti:hud/apply with storage gti:ui
