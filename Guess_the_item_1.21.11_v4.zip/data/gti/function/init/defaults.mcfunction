scoreboard players set #limit gti.var 16
scoreboard players set #batch gti.var 3
scoreboard players set #initial gti.var 4
scoreboard players set #mode gti.var 1
scoreboard players set #hints_on gti.var 1
scoreboard players set #timer_sec gti.var 0
data modify storage gti:cfg settings set value {limit:16,batch:3,initial:4,mode:"peek",timer:0,hints:1b}
data modify storage gti:cfg hint set value "NO HINT YET"
data modify storage gti:cfg status set value "PRESS START"
data modify storage gti:cfg answer set value "minecraft:diamond"
data modify storage gti:cfg art_key set value "minecraft_diamond"
data modify storage gti:cfg mode_str set value "peek"
data modify storage gti:cfg cat_names set value ["BLOCKS","EQUIPMENT","FOOD","MOBS","MATERIALS","OTHER"]
