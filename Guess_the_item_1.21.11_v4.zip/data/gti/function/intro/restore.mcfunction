function gti:fx/restore
scoreboard players set #did_restore gti.var 1
