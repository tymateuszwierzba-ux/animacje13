execute if score #state gti.var matches 2.. run return 0
execute if score #picked gti.var matches 0 run function gti:intro/pick
scoreboard players set #did_go gti.var 1
scoreboard players set #state gti.var 2
scoreboard players set #time gti.var 0
scoreboard players set #auto gti.var 0
data modify storage gti:cfg status set value "GO"
scoreboard players set #free gti.var 1
execute if score #initial gti.var matches 1.. run function gti:reveal/initial
scoreboard players set #free gti.var 0
function gti:strip/refresh
function gti:hud/refresh
function gti:timer/begin
title @a[tag=gti.player] times 3 30 8
title @a[tag=gti.player] subtitle {"text":"Click cells to crack the bedrock","color":"gray"}
title @a[tag=gti.player] title {"text":"GUESS IT!","color":"#8BE28B","bold":true}
execute as @a[tag=gti.player] at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 0.7 1.5
