scoreboard players add #anim gti.var 1
execute if score #anim gti.var matches 1 run function gti:intro/seal
execute if score #anim gti.var matches 10 run function gti:fx/restore
execute if score #anim gti.var matches 18 run function gti:intro/pick
execute if score #anim gti.var matches 26 run function gti:intro/open
execute if score #anim gti.var matches 54 run function gti:intro/go
