scoreboard players add #anim gti.var 1
execute if score #anim gti.var matches 1.. if score #did_seal gti.var matches 0 run function gti:intro/seal
execute if score #anim gti.var matches 10.. if score #did_restore gti.var matches 0 run function gti:intro/restore
execute if score #anim gti.var matches 18.. if score #did_pick gti.var matches 0 run function gti:intro/pick
execute if score #anim gti.var matches 26.. if score #did_open gti.var matches 0 run function gti:intro/open
execute if score #anim gti.var matches 54.. if score #did_go gti.var matches 0 run function gti:intro/go
