execute if score #source gti.var matches 1 run function gti:data/use_fixed
execute unless score #source gti.var matches 1 run function gti:data/random_answer
data modify storage gti:cfg status set value "ANSWER LOCKED"
function gti:hud/refresh
