function gti:data/random_lock
