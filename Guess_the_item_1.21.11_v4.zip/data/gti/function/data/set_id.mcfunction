$data modify storage gti:tmp id set value "$(id)"
$execute unless data storage gti:items by_id."$(id)" run data modify storage gti:tmp id set value "minecraft:$(id)"
function gti:data/set_fixed with storage gti:tmp
