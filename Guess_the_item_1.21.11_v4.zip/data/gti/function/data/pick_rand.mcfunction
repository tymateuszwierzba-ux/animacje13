$data modify storage gti:ctx id set from storage gti:items ids[$(index)]
