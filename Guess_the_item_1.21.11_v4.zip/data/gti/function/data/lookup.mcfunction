$data modify storage gti:cfg meta set from storage gti:items by_id."$(id)"
data modify storage gti:cfg art_key set from storage gti:cfg meta.ak
data modify storage gti:cfg answer_key set from storage gti:cfg meta.key
execute store result score #eq_answer gti.var run data get storage gti:cfg meta.eq
execute store result score #hint_cat gti.var run data get storage gti:cfg meta.cat
