$data modify storage gti:tmp id set from storage gti:cat $(cat)[$(index)]
