data modify storage gti:ctx id set from storage gti:cfg answer
function gti:data/lookup with storage gti:ctx
