function gti:data/random_index
function gti:data/pick_rand with storage gti:tmp
data modify storage gti:tmp id set from storage gti:ctx id
function gti:data/set_fixed with storage gti:tmp
