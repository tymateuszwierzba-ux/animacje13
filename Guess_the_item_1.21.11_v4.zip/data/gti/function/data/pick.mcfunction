scoreboard players operation #pick gti.var = @s gti_pick
scoreboard players remove #pick gti.var 1
scoreboard players operation #cat gti.var = #pick gti.var
scoreboard players operation #cat gti.var /= #tenk gti.var
scoreboard players operation #idx gti.var = #pick gti.var
scoreboard players operation #idx gti.var %= #tenk gti.var
execute store result storage gti:tmp index int 1 run scoreboard players get #idx gti.var
data modify storage gti:tmp cat set value "all"
execute if score #cat gti.var matches 1 run data modify storage gti:tmp cat set value "blocks"
execute if score #cat gti.var matches 2 run data modify storage gti:tmp cat set value "equipment"
execute if score #cat gti.var matches 3 run data modify storage gti:tmp cat set value "food"
execute if score #cat gti.var matches 4 run data modify storage gti:tmp cat set value "mobs"
execute if score #cat gti.var matches 5 run data modify storage gti:tmp cat set value "materials"
execute if score #cat gti.var matches 6 run data modify storage gti:tmp cat set value "other"
function gti:data/pick_cat with storage gti:tmp
function gti:data/set_fixed with storage gti:tmp
