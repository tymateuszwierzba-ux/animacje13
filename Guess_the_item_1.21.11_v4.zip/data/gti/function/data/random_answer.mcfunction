function gti:data/random_index
function gti:data/pick_rand with storage gti:tmp
data modify storage gti:cfg answer set from storage gti:ctx id
function gti:data/lookup with storage gti:ctx
scoreboard players set #source gti.var 0
