$execute store success score #found gti.var run data get storage gti:items by_id."$(id)"
$execute if score #found gti.var matches 0 run return run tellraw @s [{"text":"Unknown item id: ","color":"red"},{"text":"$(id)","color":"#FF8996"}]
execute if score #state gti.var matches 1..3 run return run tellraw @s {"text":"Finish the running round first.","color":"yellow"}
$data modify storage gti:cfg answer set value "$(id)"
scoreboard players set #source gti.var 1
function gti:data/use_fixed
function gti:round/reset
data modify storage gti:cfg status set value "ANSWER LOCKED"
function gti:hud/refresh
$tellraw @s [{"text":"Answer locked: ","color":"gray"},{"text":"$(id)","color":"#61EDE5"}]
dialog show @s gti:host
