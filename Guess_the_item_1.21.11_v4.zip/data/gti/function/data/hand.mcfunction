execute unless items entity @s weapon.mainhand #gti:answers run return run tellraw @s {"text":"Hold an item from the catalogue in your main hand.","color":"yellow"}
data modify storage gti:tmp id set from entity @s SelectedItem.id
function gti:data/set_fixed with storage gti:tmp
