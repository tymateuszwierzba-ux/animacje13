function gti:data/palette
data modify storage gti:items ids set value []
function gti:data/art/0
function gti:data/art/1
function gti:data/art/2
function gti:data/art/3
function gti:data/art/4
function gti:data/art/5
function gti:data/art/6
function gti:data/art/7
function gti:data/art/8
function gti:data/art/9
function gti:data/art/10
function gti:data/ids/0
function gti:data/ids/1
function gti:data/ids/2
function gti:data/ids/3
function gti:data/meta/0
function gti:data/meta/1
function gti:data/meta/2
function gti:data/meta/3
function gti:data/meta/4
function gti:data/meta/5
function gti:data/meta/6
function gti:data/equiv
function gti:data/cats
scoreboard players set #data_count gti.var 1504
scoreboard players set #maxpix gti.var 256
