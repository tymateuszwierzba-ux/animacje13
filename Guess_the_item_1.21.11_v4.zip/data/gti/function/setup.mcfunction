execute unless entity @s[type=player] run return run tellraw @a {"text":"Run setup as a player.","color":"red"}
execute unless dimension minecraft:overworld run return run tellraw @s {"text":"Build the board in the Overworld.","color":"red"}
function gti:remove
execute align xyz positioned ~ ~ ~-30 run function gti:world/build
tp @s ~ ~ ~ facing entity @e[tag=gti.look,limit=1]
tag @a remove gti.host
tag @s add gti.host
tag @s add gti.player
scoreboard players set #state gti.var 0
scoreboard players set #result gti.var 2
scoreboard players set #round gti.var 0
scoreboard players set #used gti.var 0
scoreboard players set #revealed gti.var 0
scoreboard players set #hint_stage gti.var 0
scoreboard players set #anim gti.var 0
scoreboard players set #picked gti.var 0
scoreboard players set #shown gti.var 0
scoreboard players set #g_intro gti.var 0
scoreboard players set #g_fin gti.var 0
scoreboard players set #did_seal gti.var 0
scoreboard players set #did_restore gti.var 0
scoreboard players set #did_pick gti.var 0
scoreboard players set #did_open gti.var 0
scoreboard players set #did_go gti.var 0
scoreboard players set #did_confetti gti.var 0
scoreboard players set #did_fire gti.var 0
scoreboard players set #did_end gti.var 0
scoreboard players set #did_end2 gti.var 0
scoreboard players set #did_end3 gti.var 0
data modify storage gti:cfg status set value "PRESS START"
data modify storage gti:cfg hint set value "NO HINT YET"
function gti:strip/refresh
function gti:hud/refresh
function gti:fx/curtain_open
tellraw @s [{"text":"Board ready. ","color":"#8BE28B"},{"text":"/function gti:start","color":"#61EDE5","click_event":{"action":"run_command","command":"function gti:start"}},{"text":" or open the menu.","color":"gray"}]
dialog show @s gti:menu
