execute unless entity @e[tag=gti.anchor,limit=1] run return run tellraw @s {"text":"No board here - run /function gti:setup first.","color":"red"}
execute at @e[tag=gti.anchor,limit=1] run function gti:fix/at
