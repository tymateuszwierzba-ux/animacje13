dialog show @s gti:catalogue/index
