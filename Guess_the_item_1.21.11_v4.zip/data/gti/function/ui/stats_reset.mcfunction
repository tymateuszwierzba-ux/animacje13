scoreboard players set @s gti.wins 0
scoreboard players set @s gti.best 0
scoreboard players set @s gti.streak 0
scoreboard players set @s gti.best_streak 0
scoreboard players set @s gti.rounds 0
scoreboard players set @s gti.tries 0
tellraw @s {"text":"Your stats were reset.","color":"#8BE28B"}
dialog show @s gti:stats
