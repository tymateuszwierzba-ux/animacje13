dialog show @s gti:summary
