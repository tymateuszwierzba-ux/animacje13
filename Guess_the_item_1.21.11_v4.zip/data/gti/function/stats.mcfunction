dialog show @s gti:stats
