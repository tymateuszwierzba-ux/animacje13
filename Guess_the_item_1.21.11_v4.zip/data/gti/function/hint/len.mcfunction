data modify storage gti:ui len set from storage gti:cfg meta.len
data modify storage gti:ui first set from storage gti:cfg meta.first
function gti:hint/fmt_len with storage gti:ui
