$data modify storage gti:ui cat_name set from storage gti:cfg cat_names[$(cat)]
function gti:hint/fmt_cat2 with storage gti:ui
