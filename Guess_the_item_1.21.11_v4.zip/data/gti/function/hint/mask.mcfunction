data modify storage gti:ui mask set from storage gti:cfg meta.mask
function gti:hint/fmt_mask with storage gti:ui
