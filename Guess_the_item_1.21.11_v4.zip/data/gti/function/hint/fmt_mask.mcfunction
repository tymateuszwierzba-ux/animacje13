$data modify storage gti:cfg hint set value "PATTERN $(mask)"
