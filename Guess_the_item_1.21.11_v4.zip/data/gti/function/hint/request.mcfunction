execute unless score #state gti.var matches 2 run return run tellraw @s {"text":"No round is running.","color":"gray"}
execute if score #hints_on gti.var matches 0 run return run tellraw @s {"text":"Hints are disabled in the settings.","color":"yellow"}
execute if score #hint_stage gti.var matches 3 run return run tellraw @s {"text":"All three hints are already used.","color":"yellow"}
scoreboard players add #hint_stage gti.var 1
scoreboard players add #used gti.var 2
execute if score #hint_stage gti.var matches 1 run function gti:hint/cat
execute if score #hint_stage gti.var matches 2 run function gti:hint/len
execute if score #hint_stage gti.var matches 3 run function gti:hint/mask
function gti:strip/refresh
function gti:hud/refresh
execute at @e[tag=gti.anchor,limit=1] run playsound minecraft:block.amethyst_block.resonate master @a[tag=gti.player] ~ ~ ~ 0.6 1.6
execute if score #limit gti.var matches 1.. if score #left gti.var matches ..0 run function gti:round/lose
