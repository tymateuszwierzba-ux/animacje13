execute store result storage gti:ui cat int 1 run scoreboard players get #hint_cat gti.var
function gti:hint/fmt_cat with storage gti:ui
