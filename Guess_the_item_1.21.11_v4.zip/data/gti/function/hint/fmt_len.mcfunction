$data modify storage gti:cfg hint set value "LENGTH $(len)  •  FIRST LETTER $(first)"
