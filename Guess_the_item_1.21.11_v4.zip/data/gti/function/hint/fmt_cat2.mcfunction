$data modify storage gti:cfg hint set value "CATEGORY  ·  $(cat_name)"
