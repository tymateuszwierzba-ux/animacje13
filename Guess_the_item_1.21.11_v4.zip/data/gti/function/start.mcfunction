execute unless entity @e[tag=gti.anchor,limit=1] run return run tellraw @s {"text":"Build the board first: /function gti:setup","color":"red"}
tag @s add gti.player
tag @s add gti.host
execute if score #state gti.var matches 1.. run function gti:round/abort
function gti:round/reset
scoreboard players set #state gti.var 1
scoreboard players set #anim gti.var 0
scoreboard players set #picked gti.var 0
scoreboard players set #shown gti.var 0
scoreboard players set #g_intro gti.var 0
scoreboard players set #g_fin gti.var 0
scoreboard players set #did_seal gti.var 0
scoreboard players set #did_restore gti.var 0
scoreboard players set #did_pick gti.var 0
scoreboard players set #did_open gti.var 0
scoreboard players set #did_go gti.var 0
scoreboard players set #did_confetti gti.var 0
scoreboard players set #did_fire gti.var 0
scoreboard players set #did_end gti.var 0
scoreboard players set #did_end2 gti.var 0
scoreboard players set #did_end3 gti.var 0
scoreboard players add #round gti.var 1
scoreboard players set #guesses gti.var 0
scoreboard players set @a[tag=gti.player] gti.tries 0
data modify storage gti:cfg status set value "SEALING THE BOARD"
data modify storage gti:cfg hint set value "NO HINT YET"
function gti:strip/refresh
function gti:hud/refresh
title @a[tag=gti.player] times 4 40 8
title @a[tag=gti.player] subtitle {"text":"Bedrock shield is closing","color":"gray"}
title @a[tag=gti.player] title {"text":"GET READY","color":"#45E9E0","bold":true}
execute as @a[tag=gti.player] at @s run playsound minecraft:block.stone.place master @s ~ ~ ~ 0.7 0.6
