execute if score #state gti.var matches 2..3 run return run tellraw @s {"text":"A round is already running.","color":"yellow"}
execute unless entity @e[tag=gti.anchor,limit=1] run return run tellraw @s {"text":"Build the board first: /function gti:setup","color":"red"}
function gti:round/reset
scoreboard players set #state gti.var 1
scoreboard players set #anim gti.var 0
scoreboard players add #round gti.var 1
scoreboard players set #guesses gti.var 0
scoreboard players set @a[tag=gti.player] gti.tries 0
data modify storage gti:cfg status set value "SEALING THE BOARD"
data modify storage gti:cfg hint set value "NO HINT YET"
function gti:strip/refresh
function gti:hud/refresh
title @a[tag=gti.player] times 4 40 8
title @a[tag=gti.player] subtitle {"text":"Bedrock shield is closing","color":"gray"}
title @a[tag=gti.player] title {"text":"GET READY","color":"#45E9E0","bold":true}
execute as @a[tag=gti.player] at @s run playsound minecraft:block.stone.place master @s ~ ~ ~ 0.7 0.6
