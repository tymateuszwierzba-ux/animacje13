execute if score #state gti.var matches 1 run function gti:intro/tick
execute if score #state gti.var matches 2 run function gti:round/tick
execute if score #state gti.var matches 3 run function gti:finale/tick
execute if score #clock gti.var matches 0 run function gti:hud/refresh
execute if score #clock gti.var matches 0 if score #state gti.var matches 2 run function gti:timer/refresh
execute if score #clock gti.var matches 10 if score #state gti.var matches 0 run function gti:fx/idle
