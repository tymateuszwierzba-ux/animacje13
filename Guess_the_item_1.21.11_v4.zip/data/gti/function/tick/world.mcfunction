execute if score #state gti.var matches 1 run function gti:intro/tick
execute if score #state gti.var matches 2 run function gti:round/tick
execute if score #state gti.var matches 3 run function gti:finale/tick
execute if score #state gti.var matches 1 run scoreboard players add #g_intro gti.var 1
execute unless score #state gti.var matches 1 run scoreboard players set #g_intro gti.var 0
execute if score #state gti.var matches 1 if score #g_intro gti.var matches 110.. run function gti:intro/go
execute if score #state gti.var matches 3 run scoreboard players add #g_fin gti.var 1
execute unless score #state gti.var matches 3 run scoreboard players set #g_fin gti.var 0
execute if score #state gti.var matches 3 if score #g_fin gti.var matches 240.. run function gti:finale/end3
execute if score #clock gti.var matches 0 run function gti:hud/refresh
execute if score #clock gti.var matches 0 if score #state gti.var matches 2 run function gti:timer/refresh
execute if score #clock gti.var matches 10 if score #state gti.var matches 0 run function gti:fx/idle
