execute as @a[tag=gti.player] at @s run playsound minecraft:entity.villager.no master @s ~ ~ ~ 0.6 0.8
data modify storage gti:cfg status set value "ANSWER REVEALED"
