function gti:fx/confetti
execute as @a[tag=gti.player] at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 0.8 1.05
execute as @a[tag=gti.player] at @s run playsound minecraft:entity.firework_rocket.twinkle master @s ~ ~ ~ 0.8 1.1
data modify storage gti:cfg status set value "SOLVED"
