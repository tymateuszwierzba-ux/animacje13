scoreboard players set #state gti.var 0
function gti:round/reset
function gti:fx/curtain_open
function gti:strip/refresh
function gti:hud/refresh
