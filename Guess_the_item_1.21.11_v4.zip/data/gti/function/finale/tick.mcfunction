scoreboard players add #anim gti.var 1
execute if score #anim gti.var matches 2 as @e[tag=gti.cell,tag=gti.col0] run function gti:reveal/final
execute if score #anim gti.var matches 4 as @e[tag=gti.cell,tag=gti.col1] run function gti:reveal/final
execute if score #anim gti.var matches 6 as @e[tag=gti.cell,tag=gti.col2] run function gti:reveal/final
execute if score #anim gti.var matches 8 as @e[tag=gti.cell,tag=gti.col3] run function gti:reveal/final
execute if score #anim gti.var matches 10 as @e[tag=gti.cell,tag=gti.col4] run function gti:reveal/final
execute if score #anim gti.var matches 12 as @e[tag=gti.cell,tag=gti.col5] run function gti:reveal/final
execute if score #anim gti.var matches 14 as @e[tag=gti.cell,tag=gti.col6] run function gti:reveal/final
execute if score #anim gti.var matches 16 as @e[tag=gti.cell,tag=gti.col7] run function gti:reveal/final
execute if score #anim gti.var matches 18 as @e[tag=gti.cell,tag=gti.col8] run function gti:reveal/final
execute if score #anim gti.var matches 20 as @e[tag=gti.cell,tag=gti.col9] run function gti:reveal/final
execute if score #anim gti.var matches 22 as @e[tag=gti.cell,tag=gti.col10] run function gti:reveal/final
execute if score #anim gti.var matches 24 as @e[tag=gti.cell,tag=gti.col11] run function gti:reveal/final
execute if score #anim gti.var matches 26 as @e[tag=gti.cell,tag=gti.col12] run function gti:reveal/final
execute if score #anim gti.var matches 28 as @e[tag=gti.cell,tag=gti.col13] run function gti:reveal/final
execute if score #anim gti.var matches 30 as @e[tag=gti.cell,tag=gti.col14] run function gti:reveal/final
execute if score #anim gti.var matches 32 as @e[tag=gti.cell,tag=gti.col15] run function gti:reveal/final
execute if score #anim gti.var matches 40 run function gti:fx/confetti
execute if score #anim gti.var matches 46 if score #result gti.var matches 1 run function gti:fx/fireworks
execute if score #anim gti.var matches 64 if score #result gti.var matches 1 run function gti:finale/summary
execute if score #anim gti.var matches 64 if score #result gti.var matches 0 run function gti:finale/summary
execute if score #anim gti.var matches 120 run function gti:finale/end
execute if score #anim gti.var matches 128 run function gti:finale/end2
execute if score #anim gti.var matches 138 run function gti:finale/end3
