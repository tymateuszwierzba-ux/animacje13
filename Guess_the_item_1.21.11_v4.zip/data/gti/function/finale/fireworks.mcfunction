function gti:fx/fireworks
scoreboard players set #did_fire gti.var 1
