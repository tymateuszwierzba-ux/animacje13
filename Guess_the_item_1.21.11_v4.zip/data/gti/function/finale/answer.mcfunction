data modify storage gti:tmp key set from storage gti:cfg answer_key
function gti:fx/show_answer with storage gti:tmp
