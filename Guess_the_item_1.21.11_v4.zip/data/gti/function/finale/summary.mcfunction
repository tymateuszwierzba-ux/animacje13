execute if score #shown gti.var matches 1 run return 0
scoreboard players set #shown gti.var 1
function gti:finale/answer
execute as @a[tag=gti.host] run dialog show @s gti:summary
tellraw @a[tag=gti.player] [{"text":"Round over ","color":"#8FA8C8"},{"text":"• ","color":"dark_gray"},{"text":"attempts used: ","color":"gray"},{"score":{"name":"#used","objective":"gti.var"},"color":"#FF8996"},{"text":"  •  guesses: ","color":"gray"},{"score":{"name":"#guesses","objective":"gti.var"},"color":"#F6CF84"}]
