function gti:fx/confetti
scoreboard players set #did_confetti gti.var 1
