function gti:fx/restore
data modify storage gti:cfg status set value "PRESS START"
function gti:hud/refresh
