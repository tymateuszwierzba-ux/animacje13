function gti:finale/curtain
execute as @a[tag=gti.player] at @s run playsound minecraft:block.deepslate_bricks.place master @s ~ ~ ~ 0.7 0.8
