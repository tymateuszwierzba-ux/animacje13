scoreboard players add #clock gti.var 1
execute if score #clock gti.var matches 20.. run scoreboard players set #clock gti.var 0
execute as @a[scores={gti_next=1..}] at @s run function gti:start
scoreboard players set @a[scores={gti_next=1..}] gti_next 0
scoreboard players enable @a gti_next
execute as @a[scores={gti_reveal=1..}] at @s run function gti:reveal/request
scoreboard players set @a[scores={gti_reveal=1..}] gti_reveal 0
scoreboard players enable @a gti_reveal
execute as @a[scores={gti_guess=1..}] at @s run function gti:guess/request
scoreboard players set @a[scores={gti_guess=1..}] gti_guess 0
scoreboard players enable @a gti_guess
execute as @a[scores={gti_hint=1..}] at @s run function gti:hint/request
scoreboard players set @a[scores={gti_hint=1..}] gti_hint 0
scoreboard players enable @a gti_hint
execute as @a[scores={gti_menu=1..}] at @s run function gti:ui/menu
scoreboard players set @a[scores={gti_menu=1..}] gti_menu 0
scoreboard players enable @a gti_menu
execute as @a[scores={gti_host=1..}] at @s run function gti:ui/host
scoreboard players set @a[scores={gti_host=1..}] gti_host 0
scoreboard players enable @a gti_host
execute as @a[scores={gti_settings=1..}] at @s run function gti:ui/settings
scoreboard players set @a[scores={gti_settings=1..}] gti_settings 0
scoreboard players enable @a gti_settings
execute as @a[scores={gti_stats=1..}] at @s run function gti:ui/stats
scoreboard players set @a[scores={gti_stats=1..}] gti_stats 0
scoreboard players enable @a gti_stats
execute as @a[scores={gti_browse=1..}] at @s run function gti:ui/browse
scoreboard players set @a[scores={gti_browse=1..}] gti_browse 0
scoreboard players enable @a gti_browse
execute as @a[scores={gti_summary=1..}] at @s run function gti:ui/summary
scoreboard players set @a[scores={gti_summary=1..}] gti_summary 0
scoreboard players enable @a gti_summary
execute as @a[scores={gti_rules=1..}] at @s run function gti:ui/rules
scoreboard players set @a[scores={gti_rules=1..}] gti_rules 0
scoreboard players enable @a gti_rules
execute as @a[scores={gti_stop=1..}] at @s run function gti:stop
scoreboard players set @a[scores={gti_stop=1..}] gti_stop 0
scoreboard players enable @a gti_stop
execute as @a[scores={gti_hand=1..}] at @s run function gti:data/hand
scoreboard players set @a[scores={gti_hand=1..}] gti_hand 0
scoreboard players enable @a gti_hand
execute as @a[scores={gti_random=1..}] at @s run function gti:data/random_lock
scoreboard players set @a[scores={gti_random=1..}] gti_random 0
scoreboard players enable @a gti_random
execute as @a[scores={gti_pick=1..}] at @s run function gti:data/pick
scoreboard players set @a[scores={gti_pick=1..}] gti_pick 0
scoreboard players enable @a gti_pick
execute as @a[scores={gti_easy=1..}] at @s run function gti:preset/chill
scoreboard players set @a[scores={gti_easy=1..}] gti_easy 0
scoreboard players enable @a gti_easy
execute as @a[scores={gti_normal=1..}] at @s run function gti:preset/normal
scoreboard players set @a[scores={gti_normal=1..}] gti_normal 0
scoreboard players enable @a gti_normal
execute as @a[scores={gti_hard=1..}] at @s run function gti:preset/hard
scoreboard players set @a[scores={gti_hard=1..}] gti_hard 0
scoreboard players enable @a gti_hard
execute as @a[scores={gti_default=1..}] at @s run function gti:preset/default
scoreboard players set @a[scores={gti_default=1..}] gti_default 0
scoreboard players enable @a gti_default
execute as @e[tag=gti.click] at @s if data entity @s interaction run function gti:click
execute as @e[tag=gti.click] at @s if data entity @s attack run function gti:click/attack
execute as @e[tag=gti.control] at @s if data entity @s interaction run function gti:control
scoreboard players add @e[tag=gti.fx] gti.age 1
kill @e[tag=gti.fx,scores={gti.age=10..}]
execute in minecraft:overworld at @e[tag=gti.anchor,limit=1] run function gti:tick/world
