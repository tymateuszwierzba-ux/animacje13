$execute store result storage gti:tmp n int 1 run data get storage gti:art $(key)[$(id)]
function gti:art/lookup with storage gti:tmp
$data merge entity @e[tag=gti.cell,scores={gti.id=$(id)},limit=1] {block_state:{Name:"$(block)"}}
$execute as @e[tag=gti.cell,scores={gti.id=$(id)},limit=1] run data merge entity @s {start_interpolation:0,interpolation_duration:5,transformation:{scale:[0.9f,0.9f,0.9f],translation:[0f,0f,0.14f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
$execute at @e[tag=gti.cell,scores={gti.id=$(id)},limit=1] run summon block_display ~ ~ ~ {Tags:["gti.entity","gti.fx","gti.flash"],block_state:{Name:"minecraft:white_concrete"},brightness:{sky:15,block:15},view_range:4f,transformation:{scale:[1.3f,1.3f,0.2f],translation:[0f,0f,0.2f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
$execute at @e[tag=gti.cell,scores={gti.id=$(id)},limit=1] run data merge entity @e[tag=gti.flash,sort=nearest,limit=1] {start_interpolation:0,interpolation_duration:6,transformation:{scale:[0.02f,0.02f,0.02f],translation:[0f,0f,0.2f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
