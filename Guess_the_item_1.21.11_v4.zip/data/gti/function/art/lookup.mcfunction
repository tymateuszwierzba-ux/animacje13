$data modify storage gti:tmp block set from storage gti:art palette[$(n)]
