data modify storage gti:tmp limit set value 8
data modify storage gti:tmp batch set value 1
data modify storage gti:tmp initial set value 0
data modify storage gti:tmp timer set value 0
data modify storage gti:tmp hints set value 0
data modify storage gti:tmp mode set value "manual"
function gti:cfg/store with storage gti:tmp
tellraw @s {"text":"Preset HARD applied.","color":"#8BE28B"}
dialog show @s gti:settings
