function gti:init/defaults
function gti:strip/refresh
function gti:hud/refresh
tellraw @s {"text":"Defaults restored.","color":"#8BE28B"}
