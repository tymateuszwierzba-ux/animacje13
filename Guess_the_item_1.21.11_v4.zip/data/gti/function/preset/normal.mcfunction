data modify storage gti:tmp limit set value 16
data modify storage gti:tmp batch set value 3
data modify storage gti:tmp initial set value 4
data modify storage gti:tmp timer set value 0
data modify storage gti:tmp hints set value 1
data modify storage gti:tmp mode set value "peek"
function gti:cfg/store with storage gti:tmp
tellraw @s {"text":"Preset NORMAL applied.","color":"#8BE28B"}
dialog show @s gti:settings
