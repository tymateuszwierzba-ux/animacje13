execute if entity @s[tag=gti.control.reveal] on target run function gti:reveal/request
execute if entity @s[tag=gti.control.guess] on target run function gti:guess/request
execute if entity @s[tag=gti.control.hint] on target run function gti:hint/request
execute if entity @s[tag=gti.control.menu] on target run function gti:ui/menu
execute if entity @s[tag=gti.control.menu] on target run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.6 1.2
data remove entity @s interaction
data remove entity @s attack
