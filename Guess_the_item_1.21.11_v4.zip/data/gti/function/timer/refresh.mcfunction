execute unless score #timer_sec gti.var matches 1.. run bossbar set gti:timer visible false
execute if score #timer_sec gti.var matches 1.. run bossbar set gti:timer max 100
execute if score #timer_sec gti.var matches 1.. store result bossbar gti:timer value run function gti:timer/value
