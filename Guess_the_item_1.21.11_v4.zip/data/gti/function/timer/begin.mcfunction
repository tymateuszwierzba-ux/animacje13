scoreboard players operation #timer_end gti.var = #timer_sec gti.var
scoreboard players operation #timer_end gti.var *= #twenty gti.var
execute if score #timer_sec gti.var matches 1.. run bossbar set gti:timer visible true
execute if score #timer_sec gti.var matches 1.. run bossbar set gti:timer players @a[tag=gti.player]
execute if score #timer_sec gti.var matches 0 run function gti:timer/hide
