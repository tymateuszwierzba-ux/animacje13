scoreboard players operation #timer_left gti.var = #timer_end gti.var
scoreboard players operation #timer_left gti.var -= #time gti.var
scoreboard players operation #timer_left gti.var *= #hundred gti.var
scoreboard players operation #timer_left gti.var /= #timer_end gti.var
execute if score #timer_left gti.var matches ..-1 run scoreboard players set #timer_left gti.var 0
return run scoreboard players get #timer_left gti.var
