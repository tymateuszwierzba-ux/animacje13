bossbar set gti:timer visible false
