$execute if data storage gti:ctx {answer:"$(guess)"} run scoreboard players set #same gti.var 1
