execute unless score #state gti.var matches 2 run return 0
scoreboard players add @s gti.wins 1
scoreboard players add @s gti.rounds 1
scoreboard players add @s gti.streak 1
execute if score @s gti.streak > @s gti.best_streak run scoreboard players operation @s gti.best_streak = @s gti.streak
scoreboard players operation #best_now gti.var = #used gti.var
scoreboard players add #best_now gti.var 1
scoreboard players set #new_best gti.var 0
execute unless score @s gti.best matches 1.. run scoreboard players set #new_best gti.var 1
execute if score #new_best gti.var matches 0 if score #best_now gti.var < @s gti.best run scoreboard players set #new_best gti.var 1
execute if score #new_best gti.var matches 1 run scoreboard players operation @s gti.best = #best_now gti.var
execute if score #new_best gti.var matches 1 run tellraw @s {"text":"★ NEW PERSONAL BEST ★","color":"gold","bold":true}
scoreboard players set #result gti.var 1
scoreboard players set #state gti.var 3
scoreboard players set #anim gti.var 0
scoreboard players set #shown gti.var 0
function gti:strip/refresh
function gti:hud/refresh
function gti:finale/win
function gti:timer/hide
