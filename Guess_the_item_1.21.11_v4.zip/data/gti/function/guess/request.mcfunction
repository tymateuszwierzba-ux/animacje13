execute unless score #state gti.var matches 2 run return run tellraw @s {"text":"No round is running.","color":"gray"}
execute unless items entity @s weapon.mainhand #gti:answers run return run tellraw @s {"text":"Hold the item you want to guess in your main hand.","color":"yellow"}
tag @s add gti.player
scoreboard players add @s gti.tries 1
scoreboard players add #guesses gti.var 1
data modify storage gti:ctx answer set from storage gti:cfg answer
data modify storage gti:ctx guess set from entity @s SelectedItem.id
scoreboard players set #same gti.var 0
function gti:guess/check with storage gti:ctx
execute if score #same gti.var matches 0 run function gti:guess/equiv with storage gti:ctx
execute if score #same gti.var matches 1 run function gti:guess/win
execute if score #same gti.var matches 0 run function gti:guess/wrong
