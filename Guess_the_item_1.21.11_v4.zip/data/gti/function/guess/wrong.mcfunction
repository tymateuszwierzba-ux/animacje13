execute unless score #state gti.var matches 2 run return 0
scoreboard players add #wrong gti.var 1
scoreboard players set @s gti.streak 0
scoreboard players add #used gti.var 3
title @s times 2 24 8
title @s subtitle {"text":"-3 attempts • try again","color":"gray"}
title @s title {"text":"NOT THIS ITEM","color":"#FF8996","bold":true}
execute at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.8 0.55
execute at @e[tag=gti.anchor,limit=1] run particle minecraft:smoke ~ ~10.5 ~1.2 8 8 0.2 0.02 40 force @a[tag=gti.player]
function gti:strip/refresh
function gti:hud/refresh
execute if score #mode gti.var matches 1 run function gti:reveal/peek
execute if score #limit gti.var matches 1.. if score #left gti.var matches ..0 run function gti:round/lose
