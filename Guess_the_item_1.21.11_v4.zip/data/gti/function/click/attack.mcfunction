execute unless score #state gti.var matches 2 on attacker run tellraw @s {"text":"No round is running - press START ROUND in the menu.","color":"gray"}
execute unless score #state gti.var matches 2 run return run data remove entity @s attack
execute on attacker run tag @s add gti.player
execute on attacker run scoreboard players add @s gti.tries 1
execute store result storage gti:tmp batch int 1 run scoreboard players get #batch gti.var
execute at @s run function gti:reveal/batch with storage gti:tmp
data remove entity @s attack
function gti:hud/refresh
