dialog show @s gti:settings
