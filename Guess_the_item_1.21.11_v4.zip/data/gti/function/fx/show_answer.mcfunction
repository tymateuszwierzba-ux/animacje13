$data modify entity @e[tag=gti.hud.hint,limit=1] text set value [{"text":"ANSWER  ","color":"#8FA8C8","bold":true},{"translate":"$(key)","color":"#F6CF84","bold":true}]
