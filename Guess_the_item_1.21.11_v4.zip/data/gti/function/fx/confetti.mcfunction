execute at @e[tag=gti.anchor,limit=1] run particle minecraft:totem_of_undying ~ ~10 ~1.6 8 8 0.5 0.4 60 force @a[tag=gti.player]
execute at @e[tag=gti.anchor,limit=1] run particle minecraft:firework ~ ~10 ~1.6 9 9 0.5 0.15 30 force @a[tag=gti.player]
