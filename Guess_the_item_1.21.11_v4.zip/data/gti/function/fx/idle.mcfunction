execute at @e[tag=gti.anchor,limit=1] run particle minecraft:end_rod ~ ~10.5 ~1.4 9 9 0.1 0.02 12 force @a[tag=gti.player]
execute at @e[tag=gti.anchor,limit=1] run particle minecraft:glow ~ ~10.5 ~1.6 9 9 0.1 0.01 6 force @a[tag=gti.player]
