execute as @e[tag=gti.cell] run tag @s remove gti.open
execute as @e[tag=gti.cell] run data merge entity @s {block_state:{Name:"minecraft:bedrock"},start_interpolation:0,interpolation_duration:0,transformation:{scale:[1f,1f,1f],translation:[0f,0f,0f],left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f]}}
kill @e[tag=gti.fx]
