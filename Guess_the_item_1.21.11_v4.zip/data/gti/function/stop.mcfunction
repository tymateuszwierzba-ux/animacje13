execute unless score #state gti.var matches 1..3 run return run tellraw @s {"text":"Nothing is running.","color":"gray"}
function gti:round/abort
tellraw @s {"text":"Round stopped.","color":"gray"}
