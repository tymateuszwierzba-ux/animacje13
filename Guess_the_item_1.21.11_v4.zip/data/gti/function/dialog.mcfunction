dialog show @s gti:menu
