execute unless entity @e[tag=gti.anchor,limit=1] run return run tellraw @s {"text":"Build the board first: /function gti:setup","color":"red"}
execute at @e[tag=gti.anchor,limit=1] run tp @s ~0.5 ~ ~30 180 -17
