scoreboard players set #zero gti.var 0
scoreboard players set #one gti.var 1
scoreboard players set #two gti.var 2
scoreboard players set #three gti.var 3
scoreboard players set #eight gti.var 8
scoreboard players set #ten gti.var 10
scoreboard players set #sixteen gti.var 16
scoreboard players set #twenty gti.var 20
scoreboard players set #thirty gti.var 30
scoreboard players set #sixty gti.var 60
scoreboard players set #hundred gti.var 100
scoreboard players set #tenk gti.var 10000
scoreboard players set #maxpix gti.var 256
execute unless score #v4 gti.var matches 1 run function gti:init/defaults
scoreboard players set #v4 gti.var 1
scoreboard players set #state gti.var 0
scoreboard players set #result gti.var 2
scoreboard players set #round gti.var 0
scoreboard players set #revealed gti.var 0
scoreboard players set #used gti.var 0
scoreboard players set #time gti.var 0
scoreboard players set #clock gti.var 0
scoreboard players set #anim gti.var 0
scoreboard players set #free gti.var 0
scoreboard players set #guesses gti.var 0
scoreboard players set #hint_stage gti.var 0
scoreboard players set #same gti.var 0
scoreboard players set #auto gti.var 0
scoreboard players set #team_best gti.var 2147483000
execute unless score #data_count gti.var matches 1504 run function gti:data/init
function gti:strip/refresh
function gti:hud/refresh
