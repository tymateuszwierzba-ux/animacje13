scoreboard players set #auto gti.var 0
execute store result storage gti:tmp batch int 1 run scoreboard players get #batch gti.var
execute at @e[tag=gti.anchor,limit=1] run function gti:reveal/batch with storage gti:tmp
function gti:hud/refresh
