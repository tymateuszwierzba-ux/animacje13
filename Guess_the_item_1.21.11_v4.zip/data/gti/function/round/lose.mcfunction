execute unless score #state gti.var matches 2 run return 0
scoreboard players set #result gti.var 0
scoreboard players set #state gti.var 3
scoreboard players set #anim gti.var 0
scoreboard players set #shown gti.var 0
scoreboard players set @a[tag=gti.player] gti.streak 0
scoreboard players add @a[tag=gti.player] gti.rounds 1
title @a[tag=gti.player] times 4 60 12
title @a[tag=gti.player] subtitle {"text":"The bedrock hides nothing anymore","color":"gray"}
title @a[tag=gti.player] title {"text":"OUT OF ATTEMPTS","color":"#FF8996","bold":true}
execute as @a[tag=gti.player] at @s run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 0.7 0.7
function gti:strip/refresh
function gti:hud/refresh
function gti:finale/lose
function gti:timer/hide
