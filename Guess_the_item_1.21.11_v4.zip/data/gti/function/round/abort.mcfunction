scoreboard players set #state gti.var 0
scoreboard players set #result gti.var 2
function gti:round/reset
function gti:fx/curtain_open
function gti:fx/restore
data modify storage gti:cfg status set value "STOPPED"
function gti:hud/refresh
bossbar set gti:timer visible false
