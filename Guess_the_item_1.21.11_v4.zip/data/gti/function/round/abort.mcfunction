scoreboard players set #state gti.var 0
scoreboard players set #result gti.var 2
scoreboard players set #anim gti.var 0
scoreboard players set #picked gti.var 0
scoreboard players set #shown gti.var 0
scoreboard players set #g_intro gti.var 0
scoreboard players set #g_fin gti.var 0
scoreboard players set #did_seal gti.var 0
scoreboard players set #did_restore gti.var 0
scoreboard players set #did_pick gti.var 0
scoreboard players set #did_open gti.var 0
scoreboard players set #did_go gti.var 0
scoreboard players set #did_confetti gti.var 0
scoreboard players set #did_fire gti.var 0
scoreboard players set #did_end gti.var 0
scoreboard players set #did_end2 gti.var 0
scoreboard players set #did_end3 gti.var 0
function gti:round/reset
function gti:fx/curtain_open
function gti:fx/restore
data modify storage gti:cfg status set value "STOPPED"
function gti:hud/refresh
bossbar set gti:timer visible false
