data modify storage gti:cfg status set value "ALL CELLS REVEALED - GUESS NOW"
function gti:hud/refresh
title @a[tag=gti.player] actionbar [{"text":"ALL CELLS REVEALED","color":"#8BE28B","bold":true},{"text":"  hold the item and press GUESS","color":"gray"}]
