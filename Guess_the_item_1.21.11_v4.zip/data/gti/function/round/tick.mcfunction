scoreboard players add #time gti.var 1
scoreboard players add #auto gti.var 1
execute if score #timer_sec gti.var matches 1.. if score #time gti.var >= #timer_end gti.var run function gti:round/lose
execute if score #mode gti.var matches 2 if score #auto gti.var matches 140.. run function gti:round/auto
