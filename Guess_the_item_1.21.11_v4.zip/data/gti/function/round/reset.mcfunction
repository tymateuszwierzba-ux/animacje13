scoreboard players set #used gti.var 0
scoreboard players set #revealed gti.var 0
scoreboard players set #time gti.var 0
scoreboard players set #auto gti.var 0
scoreboard players set #hint_stage gti.var 0
scoreboard players set #same gti.var 0
scoreboard players set #free gti.var 0
scoreboard players set #result gti.var 2
data modify storage gti:cfg hint set value "NO HINT YET"
execute as @e[tag=gti.cell] run tag @s remove gti.open
function gti:strip/refresh
