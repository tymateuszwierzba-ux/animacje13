dialog show @s gti:host
