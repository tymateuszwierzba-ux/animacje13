execute unless score #state gti.var matches 2 run return run data remove entity @s interaction
execute on target run tag @s add gti.player
execute on target run scoreboard players add @s gti.tries 1
execute store result storage gti:tmp batch int 1 run scoreboard players get #batch gti.var
execute at @s run function gti:reveal/batch with storage gti:tmp
data remove entity @s interaction
function gti:hud/refresh
