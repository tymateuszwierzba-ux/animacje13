data modify storage gti:cat blocks append value "minecraft:yellow_wool"
data modify storage gti:cat blocks append value "minecraft:zombie_head"
