data modify storage gti:items ids set value []
function gti:data/items/0
function gti:data/items/1
function gti:data/items/2
function gti:data/items/3
function gti:data/items/4
function gti:data/meta/0
function gti:data/meta/1
function gti:data/meta/2
function gti:data/meta/3
function gti:data/meta/4
scoreboard players set #data_count gti.var 1504
scoreboard players set #maxpix gti.var 256
