scoreboard players set #zero gti.var 0
scoreboard players set #one gti.var 1
scoreboard players set #two gti.var 2
scoreboard players set #three gti.var 3
scoreboard players set #eight gti.var 8
scoreboard players set #ten gti.var 10
scoreboard players set #sixteen gti.var 16
scoreboard players set #twenty gti.var 20
scoreboard players set #thirty gti.var 30
scoreboard players set #thirtytwo gti.var 32
scoreboard players set #sixty gti.var 60
scoreboard players set #hundred gti.var 100
scoreboard players set #tenk gti.var 10000
scoreboard players set #maxpix gti.var 256
function gti:strip/refresh
function gti:hud/refresh
