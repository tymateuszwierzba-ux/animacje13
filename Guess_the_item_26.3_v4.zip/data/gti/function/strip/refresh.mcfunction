scoreboard players operation #left gti.var = #limit gti.var
scoreboard players operation #left gti.var -= #used gti.var
execute if score #left gti.var matches ..0 run scoreboard players set #left gti.var 0
function gti:strip/hide
execute unless score #limit gti.var matches 1.. run return 0
scoreboard players operation #pad gti.var = #thirtytwo gti.var
scoreboard players operation #pad gti.var -= #limit gti.var
scoreboard players operation #pad gti.var /= #two gti.var
scoreboard players operation #pad_end gti.var = #pad gti.var
scoreboard players operation #pad_end gti.var += #limit gti.var
scoreboard players operation #left_end gti.var = #pad gti.var
scoreboard players operation #left_end gti.var += #left gti.var
scoreboard players set #tone gti.var 0
scoreboard players operation #tmp gti.var = #left gti.var
scoreboard players operation #tmp gti.var *= #three gti.var
scoreboard players operation #tmp gti.var /= #limit gti.var
execute if score #tmp gti.var matches 1.. run scoreboard players set #tone gti.var 1
execute if score #tmp gti.var matches 2.. run scoreboard players set #tone gti.var 2
execute if score #tmp gti.var matches 3.. run scoreboard players set #tone gti.var 3
execute if score #tone gti.var matches 0 run function gti:strip/tone0
execute if score #tone gti.var matches 1 run function gti:strip/tone1
execute if score #tone gti.var matches 2 run function gti:strip/tone2
execute if score #tone gti.var matches 3 run function gti:strip/tone3
