# GUESS THE ITEM 4.0
### BLOCK BOARD • BEDROCK SHIELD • MAX-ATTEMPT STRIP • Minecraft Java 26.3

Guess the hidden item from the pixels you carve out of a **bedrock wall**. The board is
built from real blocks: every cell is a bedrock block, and revealing a cell swaps it for
the matching coloured block until the item icon is complete.
**1657 items**, 6 categories, dialog GUI, hints, attempt limit and stats.
No mods, no resource pack, no plugins.

## Install

1. Drop the ZIP (do not unpack) into:
   - single player: `.minecraft/saves/WORLD/datapacks/`
   - server: `WORLD/datapacks/`
2. In the Overworld, on flat open ground, run as operator:
   ```mcfunction
   /reload
   /function gti:setup
   ```
3. The wall is built 30 blocks north of you and the camera turns to face it.
4. Open the menu and press **START ROUND**.

`/function gti:remove` removes the board and every effect, `/function gti:view` re-centres
the camera, `/function gti:start` starts a round without clicking, and `/function gti:fix`
rebuilds the wall in place and clears any leftover round state (use it if a round ever
looks stuck - START ROUND now also restarts a stuck round on its own).

## Controls

| Action | How |
|---|---|
| Crack a cell | left or right click the bedrock wall |
| Reveal cells at random | **REVEAL** on the wall console or `/trigger gti_reveal set 1` |
| Guess | hold the item in your main hand and press **GUESS** or `/trigger gti_guess set 1` |
| Hint (3 levels) | **HINT** or `/trigger gti_hint set 1` |
| Menu / dialogs | **MENU**, `/function gti:menu` or `/trigger gti_menu set 1` |
| New round | **START ROUND** or `/trigger gti_next set 1` |
| Stop | `/function gti:stop` |

Dialog ids use the namespace form (`gti:menu`, `gti:host`, ...), trigger objectives use
underscores (`gti_menu`, `gti_next`, ...), so there is no dot/colon mix-up.

## The LIMIT strip

Above the wall sits a hotbar-like strip: the **maximum attempt counter**.

- it only appears when you set a limit (settings slider `Max attempts`, 0 = unlimited) and
  shows exactly as many sockets as that limit (up to 32), centred over the wall,
- every revealed cell uses one pip, a wrong guess uses three, a hint uses two,
- pips stay lime, then turn yellow, orange and red as the budget drains,
- when the last pip is used the round ends and the answer is revealed.

## GUI

| Dialog | Contents |
|---|---|
| `gti:menu` | start, reveal, guess, hint, stats, host panel, catalogue, rules |
| `gti:host` | start/stop, settings, catalogue, held item, random answer, typed id, presets, stats |
| `gti:settings` | max attempts, cells per click, free cells, time limit, reveal mode, hints |
| `gti:rules` | short rules and scoring |
| `gti:stats` | personal stats and reset |
| `gti:item_id` | type any item id as the answer |
| `gti:catalogue/index` + `gti:catalogue/<category>/<page>` | every item id, 24 per page |
| `gti:summary` | end-of-round summary |

## Scoring

- revealed cell: **1 attempt**, wrong guess: **3 attempts**, hint: **2 attempts**,
- the answer may also be a variant of the item (copper vs waxed copper, stone bricks vs
  infested stone bricks) - 67 equivalence groups are included,
- unlimited mode (limit 0) still tracks attempts for the personal best,
- personal best = fewest attempts in a solved round; ties are broken by fewer revealed cells.

## Categories

| Category | Items |
|---|---|
| Blocks And Building | 1134 |
| Weapons, Tools, Armor | 95 |
| Food And Plants | 52 |
| Mobs And Spawn Eggs | 94 |
| Materials And Ingredients | 79 |
| Other Items | 203 |

## Files

```
pack.mcmeta                   pack format 121.0
pack.png                      generated icon
README_EN.md                  this file
ITEM_LIST.txt                 every id and English name
data/gti/function/            logic, animations, art data, world build
data/gti/dialog/              dialogs (menu, host, settings, catalogue, ...)
data/gti/tags/item/           answers + equivalence tags
data/minecraft/tags/function  load + tick
```

## Notes

- Build the board in the **Overworld**; the pack refuses other dimensions.
- `/function gti:setup` needs operator rights. Players without OP can use the wall console
  and the `/trigger gti_*` objectives.
- The board is meant for a flat area with about 30 blocks of free space in front of the wall.
