scoreboard objectives add gti.menu trigger
scoreboard objectives add gti.play trigger
scoreboard objectives add gti.pixel trigger
scoreboard objectives add gti.guess trigger
scoreboard objectives add gti.hint trigger
scoreboard objectives add gti.next trigger
scoreboard objectives add gti.stats trigger
scoreboard objectives add gti.settings trigger
scoreboard objectives add gti.browser trigger
scoreboard objectives add gti.hand trigger
scoreboard objectives add gti.random trigger
scoreboard objectives add gti.stop trigger
scoreboard objectives add gti.hostmenu trigger
scoreboard objectives add gti.pick trigger
scoreboard objectives add gti.pause trigger
scoreboard objectives add gti.summary trigger
scoreboard objectives add gti.var dummy
scoreboard objectives add gti.id dummy
scoreboard objectives add gti.age dummy
scoreboard objectives add gti.wins dummy
scoreboard objectives add gti.best dummy
scoreboard objectives add gti.tries dummy
scoreboard objectives add gti.clicks dummy
scoreboard objectives add gti.rounds dummy
scoreboard objectives add gti.streak dummy
scoreboard objectives add gti.best_streak dummy
bossbar add gti:budget {"text":"BUDŻET RUNDY","color":"green"}
bossbar add gti:timer {"text":"NASTĘPNE ODKRYCIE","color":"purple"}
execute unless score #init gti.var matches 1 run function gti:internal/init
scoreboard players set #init gti.var 1
execute unless score #data_count gti.var matches 1536 run function gti:data/init
execute unless score #fx_ready gti.var matches 1 run function gti:visual/setup
scoreboard players set #fx_ready gti.var 1
execute unless score #cat_ready gti.var matches 1 run function gti:ui/cat_init
scoreboard players set #cat_ready gti.var 1
tellraw @a [{"text":"[Guess the Item] ","color":"#45E9E0","bold":true},{"text":"v3 • 26.2 • 1536 przedmiotów","color":"gray"}]
tellraw @a [{"text":"/function gti:setup","color":"#61EDE5","click_event":{"action":"suggest_command","command":"/function gti:setup"}},{"text":"   •   ","color":"dark_gray"},{"text":"/trigger gti.menu","color":"#F47BC6","click_event":{"action":"run_command","command":"trigger gti.menu set 1"}},{"text":"  (menu bez OP)","color":"gray"}]
